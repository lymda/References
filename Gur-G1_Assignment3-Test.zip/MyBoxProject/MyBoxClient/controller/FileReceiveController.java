package controller;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import client.MyBoxMain;
import entity.Reply;
import entity.Request;
import enums.Command;
import enums.Result;

/**
 * The Class FileReceiveController manage the request to the server to received file.
 */
public class FileReceiveController {

    /**
     * Sent request to the server to receive file.
     *
     * @param curUser the user that sent the request
     * @param fileName the file name
     */
    public static void recieveFileFromServer(String curUser, String fileName) {

	Request req = new Request(Command.SEND_FILE_TO_CLIENT, curUser,
		fileName);	

	try {
	    MyBoxMain.client.sendToServer(req);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

    /**
     * Manage the reply of the server.
     *
     * @param reply the reply returned from the server.
     * @param desktop is for opening the file.
     * @param path in user computer.
     * @return the result is the file Object.
     */
    public static Result recieveReplyFileFromServer(Reply reply,
	    Desktop desktop, String path) {

	FileOutputStream fos = null;
	entity.File file = (entity.File) reply.getResult();
	String userPath = "";
	try {

	    userPath = path + "\\" + file.getFileName();
	    System.out.println(file.getFileName());

	    fos = new FileOutputStream(userPath);
	    fos.write(file.getMyByteArray());
	    fos.close();

	    desktop.open(new File(userPath));

	} catch (IOException ex) {
	    ex.printStackTrace();
	    System.err.println("Client error. Connection closed.");
	}

	System.out.println("Message received: " + userPath + " from "
		+ MyBoxMain.client);
	System.out.println(file.getFileName() + " in lentgh of"
		+ file.getSize());

	return Result.OK;
    }
}
