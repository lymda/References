package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class ShowFileDetalisController manage requests to the sever for showing a file details.
 */
public class ShowFileDetalisController {
    
    /**
     * sent request to the server to get the file details.
     *
     * @param fileName the file name we want the details
     */
    public static void getFileDetails(String fileName) {
	Request r = new Request(Command.SHOW_FILE_DETAILS, fileName);
	try {
	    MyBoxMain.client.sendToServer(r);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }
}
