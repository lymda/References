package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class AuthorizedFileController manage the request to view the 'authorized file'.
 */
public class AuthorizedFileController {
	
	/**
	 * sent request to the server to load the authorized files.
	 *
	 * @param username the user name that sent the request
	 */
	static public void GetFiles(String username){
		Request req = new Request(Command.GETAUTHORIZEDFILES, username);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
