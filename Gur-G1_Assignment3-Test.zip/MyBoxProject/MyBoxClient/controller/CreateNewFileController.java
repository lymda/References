package controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class CreateNewFileController manage the requests of creating new file.
 */
public class CreateNewFileController {

    /**
     * Sent request to server to add new file.
     *
     * @param file entity with the file data
     */
    static public void sentReq(entity.File file) {
	try {

	    File newFile = new File(file.getPath()); // put here the full path.

	    byte[] myByteArray = new byte[(int) newFile.length()];
	    FileInputStream fis = new FileInputStream(newFile);
	    BufferedInputStream bis = new BufferedInputStream(fis);

	    file.initialArray(myByteArray.length);
	    file.setSize(myByteArray.length);

	    bis.read(file.getMyByteArray(), 0, myByteArray.length);

	    Request requset = new Request(Command.NEWFILE, file.getFileOwner(),
		    file); // CHANGE currentUser to the real user.

	    fis.close();
	    bis.close();
	    MyBoxMain.client.sendToServer(requset);
	    System.out.println("File sent");

	} catch (Exception e) {
	    System.out.println("Error send (Files)msg) to Server");
	}

    }

}
