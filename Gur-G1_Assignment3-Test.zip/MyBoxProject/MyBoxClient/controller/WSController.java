package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class WSController manage the requests to the server that are related to create a workspace.
 */
public class WSController {
	
	/**
	 * sent request to the server to check if the user already have a workspace.
	 *
	 * @param username the user name
	 */
	static public void CheckWS(String username){
		Request req = new Request(Command.CHECKWS, username);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to create a workspace for the user.
	 *
	 * @param username the user name
	 */
	static public void CreateWS(String username){
		Request req = new Request(Command.CREATEWS, username);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent to the server the path of the location of the users files.
	 *
	 * @param username the user name
	 * @param path the path of the location of the users files
	 */
	static public void Createpath(String username, String path){
		Request req = new Request(Command.CREATEPATH, username, path);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
