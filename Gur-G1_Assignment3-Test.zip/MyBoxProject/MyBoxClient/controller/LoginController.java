package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class LoginController manage requests of login.
 */
public class LoginController {
	
	/**
	 * set request to the server for login.
	 *
	 * @param username the name of the user who want to login
	 * @param pass the password of the user
	 */
	static public void LoginTest(String username, String pass){
		Request req = new Request(Command.LOGIN, username , pass);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
