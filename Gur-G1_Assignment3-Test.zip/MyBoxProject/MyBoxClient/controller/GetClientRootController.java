package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class GetClientRootController manage the requests to the server to receive the path  of the files directory of the user in his computer.
 */
public class GetClientRootController {
    
    /**
     * sent the request to receive the root
     *
     * @param usrName the user name
     * 
     */
    public static void getRoot(String usrName) {
	Request req = new Request(Command.GET_ROOT_CLIENT_PATH, usrName);
	try {
	    MyBoxMain.client.sendToServer(req);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }
}
