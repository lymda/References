package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Folder;
import entity.Request;
import enums.Command;

/**
 * The Class DeleteFolderController manage the requests of delete folder.
 */
public class DeleteFolderController {
	
	/**
	 * Sent request to server to delete the folder.
	 *
	 * @param folder entity with the folder data
	 */
	static public void sentReq(Folder folder) {
	    Request requset = new Request(Command.DELETEFOLDER, folder); 
	    try {
			MyBoxMain.client.sendToServer(requset);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
