package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import entity.Requests;
import enums.Command;

/**
 * The Class GroupController manage the requests to the server that related to groups.
 */
public class GroupController {
	
	/**
	 * sent request to the server to create new group
	 *
	 * @param groupName the name of the froup we request to create
	 */
	public static void CreateNewGroup(String groupName)
	{
		Request req=new Request(Command.NEWGROUP,groupName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to rets the users in a group.
	 *
	 * @param groupName the group name we want to know his members
	 */
	public static void GetUsersInGroup(String groupName)
	{
		Request req=new Request(Command.USERSINGROUP,groupName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to gets the users that not in  a group.
	 *
	 * @param groupName the group name
	 */
	public static void GetUsersNotInGroup(String groupName)
	{
		Request req=new Request(Command.USERSNOTINGROUP,groupName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to gets the all the groups.
	 */
	public static void GetAllGroups()
	{
		Request req=new Request(Command.ALLGROUPS,null);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to adds user to a group.
	 *
	 * @param userName the user name we want to add
	 * @param groupName the group name 
	 */
	public static void AddUserToGroup(String userName, String groupName)
	{
		Request req=new Request(Command.ADDUSERTOGROUP,null,userName,groupName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MessageController.SendMessage(userName, "You have been added to group: "+groupName);
	}
	
	/**
	 * Sent request to the server to remove user from a group.
	 *
	 * @param userName the user name we want to remove
	 * @param groupName the group name 
	 */
	public static void RemoveUserFromGroup(String userName, String groupName)
	{
		Request req=new Request(Command.REMOVEUSERFROMGROUP,null,userName,groupName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MessageController.SendMessage(userName, "You have been removed from group: "+groupName);
	}
	
	/**
	 * Sent request to the server to gets the groups that the user is not in.
	 *
	 * @param userName the user name
	 */
	public static void GetGroupsUserIsNotIn(String userName)
	{
		Request req=new Request(Command.LOADGROUPSUSERNOTIN,userName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to gets the groups that related to a user.
	 *
	 * @param userName the user name
	 */
	public static void GetGroupsUserIn(String userName)
	{
		Request req=new Request(Command.LOADGROUPSUSERIN,userName);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sent request to the server to add request (entity) to the data base.
	 *
	 * @param userName the user name
	 * @param groupName the name of the group that related to the request
	 * @param type the type of the request (join or leave)
	 */
	public static void Request(String userName, String groupName, String type)
	{
		Request req;
		Requests r=new Requests(userName,groupName,type);
		req=new Request(Command.ADDREQUEST,userName,r);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
