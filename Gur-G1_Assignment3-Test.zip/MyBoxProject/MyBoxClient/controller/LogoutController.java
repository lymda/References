package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class LogoutController manage requests of logout..
 */
public class LogoutController {
	
	/**
	 * set request to the server for logout.
	 *
	 * @param username the name of the user who want to logout.
	 */
	static public void LogoutTest(String username){
		Request req = new Request(Command.LOGOUT, username);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
