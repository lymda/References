package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.FileDetails;
import entity.FileGroup;
import entity.Request;
import enums.Command;

/**
 * The Class FileController manage requests that related to file.
 */
public class FileController {

	/**
	 * Sent request to the server to Check if file exist.
	 *
	 * @param fileName the file name
	 * @param currUser the user that sent the request
	 */
	public static void checkFileExistence(String fileName, String currUser) {

		Request req = new Request(Command.CHECK_FILE_EXISTENCE, currUser,
				fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to change file status.
	 *
	 * @param fileName the file name
	 * @param status identify if the file is deleted or not
	 */
	public static void changeFileStatus(String fileName, int status) {

		Request req = new Request(Command.CHANGEFILESTATUS, fileName,status);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to edits the file details.
	 *
	 * @param details the updated  details of the file.
	 * @param currUser the user that sent the request
	 */
	public static void editFileDetails(FileDetails details, String currUser) {

		Request req = new Request(Command.EDIT_FILE_DETAILS, currUser, details);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Sent request to the server to delete file from folder.
	 *
	 * @param fileName the file name
	 * @param folderID the id of the folder that related to the file
	 */
	public static void deleteFileFromFolder(String fileName,int folderID) {

		Request req = new Request(Command.DELETEFILEFROMFOLDER, fileName,folderID);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Sent request to the server to adds the file to folder.
	 *
	 * @param fileName the file name
	 * @param folderID the folder id of the file
	 */
	public static void addFiletoFolder(String fileName,int folderID) {

		Request req = new Request(Command.ADDFILETOFOLDER, fileName,folderID);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Sent request to the server to checks if the user is the file owner.
	 *
	 * @param currUser the user that we want to check
	 * @param fileName the file name
	 */
	public static void isFileOwner(String currUser, String fileName) {

		Request req = new Request(Command.CHECK_FILE_OWNER, currUser, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to get the file permission.
	 *
	 * @param fileName the file name 
	 */
	public static void getFilePermission(String fileName) {

		Request req = new Request(Command.GET_FILE_PERMISSION, null, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to gets the groups that related to a file.
	 *
	 * @param fileName the file name
	 */
	public static void getGroupsFileIn(String fileName) {

		Request req = new Request(Command.GET_GROUPS_FILE_IN, null, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to gets the groups that not related to the file.
	 *
	 * @param fileName the file name
	 */
	public static void getGroupsFileNotIn(String fileName) {

		Request req = new Request(Command.GET_GROUPS_FILE_NOT_IN, null, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to change file permission.
	 *
	 * @param fileName the file name
	 * @param permission the updated permission of the file.
	 */
	public static void changeFilePermission(String fileName,String permission) {
		Request req = new Request(Command.CHANGE_FILE_PERMISSION, fileName, permission);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to add file to a group.
	 *
	 * @param fileName the file name
	 * @param groupName the group name
	 * @param permission the file permission that we want to give to the group.
	 */
	public static void addFileToGroup(String fileName, String groupName, String permission) {
		FileGroup fg=new FileGroup(groupName,fileName,permission);
		Request req = new Request(Command.ADDFILETOGROUP, null, fg);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to removes file from a group.
	 *
	 * @param fileName the file name that we want to remove
	 * @param groupName the name of the group we want to remove the file from it
	 */
	public static void removeFileFromGroup(String fileName, String groupName) {
		FileGroup fg=new FileGroup(groupName,fileName,null);
		Request req = new Request(Command.REMOVE_FILE_FROM_GROUP, null, fg);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to change file permission for group.
	 *
	 * @param fileName the file name
	 * @param groupName the group name
	 * @param permission the  updated  file permission of the group
	 */
	public static void changeFilePermissionForGroup(String fileName, String groupName, String permission) {
		FileGroup fg=new FileGroup(groupName,fileName,permission);
		Request req = new Request(Command.CHANGE_FILE_PERMISSION_FOR_GROUP, null, fg);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to get the users  that authorized for a file.
	 *
	 * @param fileName the file name
	 * 
	 */
	public static void getUsersAuthorizedForFIle(String fileName) {
		Request req = new Request(Command.GET_USERS_AUTHORIZED_FOR_FILE, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to get the owner of a file.
	 *
	 * @param fileName the file name that we want to know his owner
	 * 
	 */
	public static void getFileOwner(String fileName) {
		Request req = new Request(Command.GET_FILE_OWNER, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to delete file permanently.
	 *
	 * @param fileName the name of the file we want to delete permanently
	 */
	public static void deleteFilePermenantly(String fileName) {
		Request req = new Request(Command.DELETEFILEPERMENANTLY, fileName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to gets the deleted filed of user.
	 *
	 * @param userName the user name we want to know his deleted files
	 * 
	 */
	public static void getDeletedFiledForUser(String userName) {
		Request req = new Request(Command.GETDELETEDFILESOFUSERS, userName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to gets the groups that are not related to user.
	 *
	 * @param userName the user name
	 * 
	 */
	public static void getGroupsUserIsNotIn(String userName) {
		Request req = new Request(Command.LOADGROUPSUSERNOTIN, userName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Sent request to the server to gets the groups related to user.
	 *
	 * @param userName the user name
	 */
	public static void getGroupsUserIsIn(String userName) {
		Request req = new Request(Command.LOADGROUPSUSERIN, userName);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	} 
	
	/**
	 * Sent request to the server to Removes the file from all the groups it related to.
	 *
	 * @param filename the file name
	 */
	public static void removeFileFromALLgroups(String filename) {
		Request req = new Request(Command.DELETEFILEFROMALLGROUPS, filename);

		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	} 

}
