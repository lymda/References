package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import entity.Requests;
import enums.Command;

/**
 * The Class RequestsController manage the requests of the admin to get all the requests.
 */
public class RequestsController {

	/**
	 * sent request to the server to gets  all  the requests from users.
	 */
	public static void GetAllRequests()
	{
		Request req=new Request(Command.GETALLREQUESTS,null);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to delete request.
	 *
	 * @param request the request the admin want to delete
	 */
	public static void deleteRequest(Requests request)
	{
		Request req=new Request(Command.DELETEREQUEST,null,request);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
