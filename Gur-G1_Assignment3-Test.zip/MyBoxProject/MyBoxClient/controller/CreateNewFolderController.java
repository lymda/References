package controller;

import java.io.IOException;
import client.MyBoxMain;
import entity.Folder;
import entity.Request;
import enums.Command;

/**
 * The Class CreateNewFileController manage the requests of creating new folder.
 */
public class CreateNewFolderController {
	 
 	/**
 	 * Sent request to server to add new folder.
 	 *
 	 * @param folderName the folder name
 	 * @param parentID the ID of the parent of this folder
 	 */
 	static public void sentReq(String folderName, int parentID) {

			    Folder folder = new Folder(folderName,parentID); // put here the full path.

			    Request requset = new Request(Command.NEWFOLDER, folder); // CHANGE currentUser to the real user.
			    try {
					MyBoxMain.client.sendToServer(requset);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    System.out.println("File sent");

		    }
}
