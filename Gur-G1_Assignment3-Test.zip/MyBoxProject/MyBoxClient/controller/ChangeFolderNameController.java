package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Folder;
import entity.Request;
import enums.Command;

/**
 * The Class ChangeFolderNameController manage the requests for changing folder name.
 */
public class ChangeFolderNameController {
	
	/**
	 * Sent request to the server to change folder name .
	 *
	 * @param folder entity with the folder data
	 * @param newName the new name of the folder
	 */
	static public void sentReq(Folder folder, String newName) {
	    Request requset = new Request(Command.CHANGEFOLDERNAME, newName, folder); 
	    try {
			MyBoxMain.client.sendToServer(requset);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
