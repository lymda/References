package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;



/**
 * The Class LoadFilesFolderForWorkspaceController manage all the requests for loading the folders and the files that are in the user workspace.
 */
public class LoadFilesFolderForWorkspaceController {
	
	/**
	 * Sent request to the server to load the files and the folder that are in the user workspace.
	 *
	 * @param username the user name that want to load the files and the folders
	 */
	static public void sentReq(String username){
		Request r=new Request(Command.LOADFILESFOLDERSFORWORKSPACE, username);
		try {
			MyBoxMain.client.sendToServer(r);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
