package controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class FileSendController manage the request for sending files to the server.
 */
public class FileSendController {

    /**
     * Send a request to the server for sending file to server.
     *
     * @param fileName the file name
     */
    public static void sendFileToServer(String fileName) { //change fileName to path with file's name.

	String LocalFile = "source.docx"; //LocalFile is the file name ONLY.
	entity.File msg = new entity.File("simon", "c:/temp/", LocalFile,    //Use the first entity.File constructor .
		"bla bla", "private", 0);

	try {

	    File newFile = new File("c:/temp/" + LocalFile);      //put here the full path.

	    byte[] myByteArray = new byte[(int) newFile.length()];
	    FileInputStream fis = new FileInputStream(newFile);
	    BufferedInputStream bis = new BufferedInputStream(fis);

	    msg.initialArray(myByteArray.length);
	    msg.setSize(myByteArray.length);

	    bis.read(msg.getMyByteArray(), 0, myByteArray.length);

	    Request requset = new Request(Command.RECIEVE_FILE_FROM_CLIENT,
		   "currentUser", msg);          		 //CHANGE currentUser to the real user.
	    MyBoxMain.client.sendToServer(requset);

	    fis.close();
	    bis.close();
	    System.out.println("File sent");

	} catch (Exception e) {
	    System.out.println("Error send (Files)msg) to Server");
	}

    }

}
