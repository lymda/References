package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Message;
import entity.Request;
import enums.Command;

/**
 * The Class MessageController manage all the request to the server that related to massages.
 */
public class MessageController {
	
	/**
	 * set request to the server for sending a message.
	 *
	 * @param user the user we want to send him a massage
	 * @param message the message we want to send
	 */
	public static void SendMessage(String user,String message)
	{
		Message m=new Message(user,message);
		Request req=new Request(Command.SENDMESSAGE,user,m);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to send message to users that are related to a file.
	 *
	 * @param fileName the file name
	 * @param message the message we want to send
	 */
	public static void SendMessageToUsersRelvantForFile(String fileName,String message)
	{
		Request req=new Request(Command.SEND_MESSAGE_TO_USER_RELATED_TO_FILE,fileName,message);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to send message to all users that are in agroup.
	 *
	 * @param groupName the group name
	 * @param message the message that will be sent to the users
	 */
	public static void SendMessageToGroup(String groupName,String message)
	{
		Request req=new Request(Command.SEND_MESSAGE_TO_GROUP,groupName,message);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to get the all messages that are related to a user.
	 *
	 * @param user the user name
	 */
	public static void GetAllMessagesForUser(String user)
	{
		Request req=new Request(Command.GETMESSAGESFORUSER,user);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * sent request to the server to delete messages that are related to a user.
	 *
	 * @param user the user name
	 */
	public static void deleteMessagesForUser(String user)
	{
		Request req=new Request(Command.DELETE_MESSAGES_FOR_USER,user);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
