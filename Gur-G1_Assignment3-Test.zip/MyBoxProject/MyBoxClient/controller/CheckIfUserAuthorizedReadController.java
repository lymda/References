package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class CheckIfUserAuthorizedReadController manage the requests for checking the file  permission  of the user .
 */
public class CheckIfUserAuthorizedReadController {

    /**
     * Sent request to the server to check if the user authorized to read the file.
     *
     * @param cuurUser  the user name that sent the request
     * @param fileName the file name
     * @param permission the permission we want to check (read or update)
     */
    public static void sentReq(String cuurUser,String fileName, String permission) {

	Request req = new Request(Command.CHECK_READ_AUTHORIZATION, cuurUser,fileName,permission);
	try {
	    MyBoxMain.client.sendToServer(req);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

}
