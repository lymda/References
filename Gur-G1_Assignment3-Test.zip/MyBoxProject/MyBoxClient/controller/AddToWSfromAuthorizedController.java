package controller;

import java.io.IOException;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class AddToWSfromAuthorizedController manage the request to add files to the user workspace.
 */
public class AddToWSfromAuthorizedController {
	
	/**
	 * sent  request to the server to add files to workspace
	 *
	 * @param username the user name that sent the request
	 * @param file entity with the file data 
	 */
	static public void AddFile(String username, int file){
		Request req = new Request(Command.ADDFROMAUTHORIZED, username , file);
		try {
			MyBoxMain.client.sendToServer(req);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
