package controller;

import java.io.IOException;
import java.util.ArrayList;

import client.MyBoxMain;
import entity.Request;
import enums.Command;

/**
 * The Class LoadFilesFolderForWorkspaceController manage all the requests for loading the folders and the files that are in a folder.
 */
public class LoadFilesFoldersForFolderController {
	
	/**
	 * Sent request to the server to load the files and the folder that are in a folder
	 *
	 * @param buttonName the name of the folder 
	 * @param arr queue of a folders ID 
	 */
	static public void sentReq(String buttonName, ArrayList<Integer> arr){
		Request r=new Request(Command.LOADFILESFOLDERSFORFOLDER, buttonName, arr);
		try {
			MyBoxMain.client.sendToServer(r);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
