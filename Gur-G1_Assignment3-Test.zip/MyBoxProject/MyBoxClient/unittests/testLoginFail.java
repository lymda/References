package unittests;
import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import client.MyBoxMain;
import boundary.LoginGUI;
import controller.LoginController;
import entity.Reply;
import enums.Result;

public class testLoginFail extends TestCase {

	private String CorrectPassword = "123";
	private String WrongPassword = "abc";
	private String CorrectUserName = "MalkiGrossman";
	private String WrongUserName = "Malki";
	private String EmptyUserName = "";
	
	LoginGUI gui;
	
	public void setUp(){
				
		MyBoxMain.connectClient("127.0.0.1");
		gui = MyBoxMain.box.getLogin();
		gui.hide();
	}

	public void testWrongUser() {

		String ex = "WRONGUSER";
		String res;
		
		LoginController.LoginTest(WrongUserName, CorrectPassword);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		res = gui.getResultfromDB();
		
//		System.out.println(gui.getResultfromDB());
// 		System.out.println(ex.equalsIgnoreCase(res));
		
 		assertTrue(ex.equalsIgnoreCase(res));
	}
	
	public void testWrongPass() {

		String ex = "WRONGPASS";
		String res;
		
		LoginController.LoginTest(CorrectUserName, WrongPassword);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		res = gui.getResultfromDB();
		
 		assertTrue(ex.equalsIgnoreCase(res));
	}
	
	public void testNoUser() {

		String ex = "WRONGUSER";
		String res;
		
		LoginController.LoginTest(EmptyUserName, CorrectPassword);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		res = gui.getResultfromDB();
		
 		assertTrue(ex.equalsIgnoreCase(res));
	}
}
