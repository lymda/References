package unittests;
import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.Test;

import client.MyBoxMain;
import boundary.LoginGUI;
import controller.LoginController;
import entity.Reply;
import enums.Result;

public class testLoginSuccess extends TestCase {

	private String CorrectPassword = "123";
	private String WrongPassword = "abc";
	private String CorrectUserName = "MalkiGrossman";
	private String WrongUserName = "Malki";
	private String EmptyUserName = "";
	
	LoginGUI gui;
	
	public void setUp(){
				
		MyBoxMain.connectClient("127.0.0.1");
		gui = MyBoxMain.box.getLogin();
		gui.hide();
	}

	public void testSuccessLogin() {

		String ex = "ISUSER";
		String res;
		
		LoginController.LoginTest(CorrectUserName, CorrectPassword);
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		res = gui.getResultfromDB();
		
 		assertTrue(ex.equalsIgnoreCase(res));
	}
}
