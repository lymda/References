package boundary;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.FileController;
import controller.MessageController;
import entity.FileGroup;
import entity.Reply;
import enums.Command;

/**
 * The Class ChangeFileInGroupGUI designed for the admin to change permissions for groups and relevant files.
 */
public class ChangeFileInGroupGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The main panel for this window. */
	private JPanel mainpanelbg;

	/** The labelbg is the background picture. */
	private JLabel labelbackground;

	/** The file name text field. */
	private JTextField fileNameTextField;

	/** The lbl file name. */
	private JLabel lblFileName;

	/** The btn load file permission. */
	private JButton btnLoadFilePermission;

	/** The groups file in combo box. */
	private JComboBox groupsFileInComboBox;

	/** The lbl groups file in. */
	private JLabel lblGroupsFileIn;

	/** The lbl groups file not. */
	private JLabel lblGroupsFileNot;

	/** The groups file not in combo box. */
	private JComboBox groupsFileNotInComboBox;

	/** The file group array. */
	private ArrayList<FileGroup> fileGroupArray;

	/** The lbl permission for selected. */
	private JLabel lblPermissionForSelected;

	/** The group permission combo box. */
	private JComboBox groupPermissionComboBox;

	/** The Current file per. */
	private String CurFilePer;

	/** The btn add file to. */
	private JButton btnAddFileTo;

	/** The permission for group apply button. */
	private JButton permissionForGroupApplyButton;

	/** The btn remove group. */
	private JButton btnRemoveGroup;

	/** The file owner. */
	private String fileOwner;

	/**
	 * Instantiates a new change file in group gui.
	 */
	public ChangeFileInGroupGUI() {
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize.
	 */
	private void initialize(){
		frame=new JFrame();
		frame.setTitle("MyBox - File In Group Edit");
		frame.setBounds(100, 20, 646, 370);
		frame.setResizable(false);
		mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);

		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource("images/wall1gur.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});
		buttonBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonBack.setBounds(528, 291, 89, 23);
		mainpanelbg.add(buttonBack);

		btnLoadFilePermission = new JButton("Load File Permission");
		btnLoadFilePermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoadFilePermission.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(fileNameTextField.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Please fill in file name", "File name is empty", JOptionPane.ERROR_MESSAGE);
					groupsFileInComboBox.setEnabled(false);
					groupPermissionComboBox.setEnabled(false);
					groupsFileNotInComboBox.setEnabled(false);
					permissionForGroupApplyButton.setEnabled(false);
					btnAddFileTo.setEnabled(false);
					btnRemoveGroup.setEnabled(false);
				}
				else
					FileController.checkFileExistence(fileNameTextField.getText(), null);
			}
		});
		btnLoadFilePermission.setBounds(263, 85, 227, 23);
		mainpanelbg.add(btnLoadFilePermission);

		groupsFileInComboBox = new JComboBox();
		groupsFileInComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				for(int i=0;i<fileGroupArray.size();i++)
					if(fileGroupArray.get(i).getGroupName().equals(groupsFileInComboBox.getSelectedItem()))
					{
						ArrayList<String> permissions = new ArrayList<String>();
						permissions.add("read");
						permissions.add("update");
						Object[] str=permissions.toArray();
						groupPermissionComboBox.removeAllItems();
						for(Object str1 : str) {
							groupPermissionComboBox.addItem(str1);
						}
						groupPermissionComboBox.setSelectedItem(fileGroupArray.get(i).getPermission());
						break;
					}

			}
		});

		btnAddFileTo = new JButton("Add");
		btnAddFileTo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(groupsFileNotInComboBox.getSelectedItem()==null)
					JOptionPane.showMessageDialog(null, "No group to add", "No group", JOptionPane.ERROR_MESSAGE);
				else
				{
					FileController.addFileToGroup(fileNameTextField.getText(), groupsFileNotInComboBox.getSelectedItem().toString(),"read");
					FileController.getFilePermission(fileNameTextField.getText());
					MessageController.SendMessageToGroup(groupsFileNotInComboBox.getSelectedItem().toString(), "File '"+fileNameTextField.getText()+"' has been added to group '"+groupsFileNotInComboBox.getSelectedItem().toString()+"' with permission 'read'");
					MessageController.SendMessage(fileOwner, "File '"+fileNameTextField.getText()+"' has been added to group '"+groupsFileNotInComboBox.getSelectedItem().toString()+"' with permission 'read'");

					JOptionPane.showMessageDialog(null, "File added to group and messages has been sent to relvant users", "Done", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnAddFileTo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddFileTo.setBounds(503, 227, 114, 23);
		mainpanelbg.add(btnAddFileTo);
		groupsFileInComboBox.setBounds(263, 119, 227, 23);
		mainpanelbg.add(groupsFileInComboBox);

		groupsFileNotInComboBox = new JComboBox();
		groupsFileNotInComboBox.setBounds(263, 226, 227, 23);
		mainpanelbg.add(groupsFileNotInComboBox);

		groupPermissionComboBox = new JComboBox();
		groupPermissionComboBox.setBounds(263, 160, 227, 23);
		mainpanelbg.add(groupPermissionComboBox);

		permissionForGroupApplyButton = new JButton("Apply");
		permissionForGroupApplyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(groupPermissionComboBox.getSelectedItem()==null)
					JOptionPane.showMessageDialog(null, "No group to choose", "No group", JOptionPane.ERROR_MESSAGE);
				else
				{
					for(int i=0;i<fileGroupArray.size();i++)
						if(fileGroupArray.get(i).getGroupName().equals(groupsFileInComboBox.getSelectedItem().toString()))
							if(fileGroupArray.get(i).getPermission().equals(groupPermissionComboBox.getSelectedItem().toString()))
								JOptionPane.showMessageDialog(null, "No changes made in permission for this group", "No change", JOptionPane.ERROR_MESSAGE);
							else
							{
								FileController.changeFilePermissionForGroup(fileNameTextField.getText(), groupsFileInComboBox.getSelectedItem().toString(), groupPermissionComboBox.getSelectedItem().toString());
								MessageController.SendMessageToGroup(groupsFileInComboBox.getSelectedItem().toString(), "File '"+fileNameTextField.getText()+"' permission in group '"+groupsFileInComboBox.getSelectedItem().toString()+"' changed to '"+groupPermissionComboBox.getSelectedItem().toString()+"'");
								MessageController.SendMessage(fileOwner, "File '"+fileNameTextField.getText()+"' permission in group '"+groupsFileInComboBox.getSelectedItem().toString()+"' changed to '"+groupPermissionComboBox.getSelectedItem().toString()+"'");
								FileController.getFilePermission(fileNameTextField.getText());
								JOptionPane.showMessageDialog(null, "Group permission changed and messages sent to relevant users.", "Done", JOptionPane.PLAIN_MESSAGE);
							}
				}
			}
		});
		permissionForGroupApplyButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		permissionForGroupApplyButton.setBounds(503, 160, 114, 23);
		mainpanelbg.add(permissionForGroupApplyButton);

		btnRemoveGroup = new JButton("Remove");
		btnRemoveGroup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(groupsFileInComboBox.getSelectedItem()==null)
					JOptionPane.showMessageDialog(null, "No group to remove", "No group", JOptionPane.ERROR_MESSAGE);
				else
				{
					MessageController.SendMessageToGroup(groupsFileInComboBox.getSelectedItem().toString(), "File '"+fileNameTextField.getText()+"' has been removed from group '"+groupsFileInComboBox.getSelectedItem().toString()+"'");
					MessageController.SendMessage(fileOwner, "File '"+fileNameTextField.getText()+"' has been removed from group '"+groupsFileInComboBox.getSelectedItem().toString()+"'");
					FileController.removeFileFromGroup(fileNameTextField.getText(),groupsFileInComboBox.getSelectedItem().toString());
					FileController.getFilePermission(fileNameTextField.getText());
					JOptionPane.showMessageDialog(null, "File has been removed from group and messages sent to relevant users.", "Done", JOptionPane.PLAIN_MESSAGE);
				}
			}
		});
		btnRemoveGroup.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnRemoveGroup.setBounds(503, 119, 114, 23);
		mainpanelbg.add(btnRemoveGroup);

		lblGroupsFileIn = new JLabel("Groups File In:");
		lblGroupsFileIn.setForeground(new Color(0, 51, 0));
		lblGroupsFileIn.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGroupsFileIn.setBounds(25, 119, 218, 23);
		mainpanelbg.add(lblGroupsFileIn);

		JLabel lblPendingRequests = new JLabel("File In Group Edit");
		lblPendingRequests.setFont(new Font("Copperplate Gothic Bold", Font.BOLD | Font.ITALIC, 18));
		lblPendingRequests.setBounds(15, 6, 251, 35);
		mainpanelbg.add(lblPendingRequests);

		lblGroupsFileNot = new JLabel("Groups File Not In:");
		lblGroupsFileNot.setForeground(new Color(0, 51, 102));
		lblGroupsFileNot.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGroupsFileNot.setBounds(25, 230, 218, 23);
		mainpanelbg.add(lblGroupsFileNot);

		lblFileName = new JLabel("File Name:");
		lblFileName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblFileName.setBounds(25, 57, 218, 23);
		mainpanelbg.add(lblFileName);

		lblPermissionForSelected = new JLabel("Permission For Group:");
		lblPermissionForSelected.setForeground(new Color(0, 51, 0));
		lblPermissionForSelected.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPermissionForSelected.setBounds(25, 160, 218, 23);
		mainpanelbg.add(lblPermissionForSelected);

		fileNameTextField = new JTextField();
		fileNameTextField.setBounds(263, 57, 227, 23);
		mainpanelbg.add(fileNameTextField);
		fileNameTextField.setColumns(10);

		groupsFileInComboBox.setEnabled(false);
		groupPermissionComboBox.setEnabled(false);
		groupsFileNotInComboBox.setEnabled(false);
		permissionForGroupApplyButton.setEnabled(false);
		btnAddFileTo.setEnabled(false);
		btnRemoveGroup.setEnabled(false);

		labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 640, 376);
		labelbackground.setIcon(new ImageIcon(img));
		mainpanelbg.add(labelbackground);	
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep=(Reply)r;
		if(rep.getCommand().equals(Command.CHECK_FILE_EXISTENCE))
		{
			if(rep.getResult().equals(true))
			{
				FileController.getFileOwner(fileNameTextField.getText());
				FileController.getFilePermission(fileNameTextField.getText());
			}
			else
			{
				JOptionPane.showMessageDialog(null, "File name dosent exists", "File name error", JOptionPane.ERROR_MESSAGE);
				groupsFileInComboBox.setEnabled(false);
				groupPermissionComboBox.setEnabled(false);
				groupsFileNotInComboBox.setEnabled(false);
				permissionForGroupApplyButton.setEnabled(false);
				btnAddFileTo.setEnabled(false);
				btnRemoveGroup.setEnabled(false);
			}
		}
		else if(rep.getCommand().equals(Command.GET_FILE_PERMISSION))
		{
			CurFilePer=(String)rep.getResult();
			if(CurFilePer.equals("private") || CurFilePer.equals("public"))
			{
				JOptionPane.showMessageDialog(null, "This file permission is not group", "File permission error", JOptionPane.ERROR_MESSAGE);
				groupsFileInComboBox.setEnabled(false);
				groupPermissionComboBox.setEnabled(false);
				groupsFileNotInComboBox.setEnabled(false);
				permissionForGroupApplyButton.setEnabled(false);
				btnAddFileTo.setEnabled(false);
				btnRemoveGroup.setEnabled(false);
			}
			else
			{
				FileController.getGroupsFileIn(fileNameTextField.getText());
				FileController.getGroupsFileNotIn(fileNameTextField.getText());
				groupsFileInComboBox.setEnabled(true);
				groupPermissionComboBox.setEnabled(true);
				groupsFileNotInComboBox.setEnabled(true);
				permissionForGroupApplyButton.setEnabled(true);
				btnAddFileTo.setEnabled(true);
				btnRemoveGroup.setEnabled(true);
			}
		}
		else if(rep.getCommand().equals(Command.GET_GROUPS_FILE_IN))
		{
			fileGroupArray=(ArrayList<FileGroup>)rep.getResult();
			Object[] fileGroupArrayStr=fileGroupArray.toArray();
			groupsFileInComboBox.removeAllItems();
			for(int i=0;i<fileGroupArray.size();i++) {
				groupsFileInComboBox.addItem(fileGroupArray.get(i).getGroupName());
			}
		}
		else if(rep.getCommand().equals(Command.GET_GROUPS_FILE_NOT_IN))
		{
			ArrayList<String> groupsArraylist=(ArrayList<String>)rep.getResult();
			Object[] groupsArr=groupsArraylist.toArray();
			groupsFileNotInComboBox.removeAllItems();
			for(Object str1 : groupsArr) {
				groupsFileNotInComboBox.addItem(str1);
			}
		}
		else if(rep.getCommand().equals(Command.GET_FILE_OWNER))
		{
			fileOwner=(String)rep.getResult();
		}
		mainpanelbg.revalidate();
		mainpanelbg.repaint();
	}
}
