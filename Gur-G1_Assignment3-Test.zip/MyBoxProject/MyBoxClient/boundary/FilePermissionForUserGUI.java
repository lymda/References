package boundary;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import controller.FileController;
import entity.Reply;
import enums.Command;
import java.awt.SystemColor;

/**
 * The Class FilePermissionForUserGUI designed for the user to make changes with file permissions.
 */
public class FilePermissionForUserGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The bg. */
	private JPanel mainpanelbg;

	/** The labelbg. */
	private JLabel labelbackground;

	/** The btn load file permission. */
	private JButton btnLoadFilePermission;

	/** The file name. */
	private String fileName;

	/** The file owner. */
	private String fileOwner;

	/** The Cur file per. */
	private String CurFilePer;

	/** The permission list. */
	private ArrayList<String> permissionlist = new ArrayList<String>();

	/** The new permission. */
	private String newPermission = "";

	/** The combo box file permission. */
	JComboBox comboBoxFilePermission;

	/** The lbl permission. */
	JLabel lblPermission;

	/** The combo box your groups. */
	JComboBox comboBoxyourGroups;

	/** The combo boxpermissions1. */
	JComboBox comboBoxpermissions1;

	/** The combo box other groups. */
	JComboBox comboBoxotherGroups;

	/** The combo boxpermissions2. */
	JComboBox comboBoxpermissions2;

	/**
	 * The Enum arr for helo identify each case for each new or old permission.
	 */
	private enum arr { privateTOprivate, privateTOpublic, privateTOgroup, publicTOpublic, 
		publicTOprivate, publicTOgroup, groupTOgroup, groupTOprivate, groupTOpublic};

		/** The new permission. */
		String newPer;

		//	private int remove_all_flag_to_grouppermission = 0;
		//	private int remove_all_flag_to_publicpermission = 0;

		/**
		 * Instantiates a new file permission for user gui.
		 *
		 * @param name the name
		 * @param user the user
		 */
		public FilePermissionForUserGUI(String name, String user) {

			this.fileName = name;
			this.fileOwner = user;
			initialize();
			this.initGUI(frame);
		}

		/**
		 * Initialize.
		 */
		private void initialize(){

			frame = new JFrame();
			frame.setTitle("MyBox - File Permissions");
			frame.setBounds(100, 20, 641, 370);
			frame.setResizable(false);
			mainpanelbg = new JPanel();
			frame.setContentPane(mainpanelbg);

			Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
			frame.setIconImage(img0);
			Image img = new ImageIcon(this.getClass().getResource("images/wall1gur.jpg")).getImage();
			mainpanelbg.setLayout(null);

			JButton buttonApplyPer = new JButton("Apply");				// Apply per button, cases for new Per private/public
			buttonApplyPer.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					if (newPer.equalsIgnoreCase(arr.privateTOprivate.toString()))
					{
						JOptionPane.showMessageDialog(null, "Permission for file is still 'Private'.");
						//						goBack();
					}
					else if (newPer.equalsIgnoreCase(arr.publicTOprivate.toString()))
					{
						FileController.changeFilePermission(fileName, "private");	
						JOptionPane.showMessageDialog(null, "Permission for this file: 'Private'. All data has been updated.");
						//					goBack();
					}
					else if (newPer.equalsIgnoreCase(arr.groupTOprivate.toString()))
					{
						FileController.removeFileFromALLgroups(fileName);
						FileController.changeFilePermission(fileName, "private");
						JOptionPane.showMessageDialog(null, "Permission for this file: 'Private'. All data has been updated.");
						//					goBack();
					}
					else if(newPer.equalsIgnoreCase(arr.publicTOpublic.toString()))
					{
						JOptionPane.showMessageDialog(null, "Permission for file is still 'Public'.");
						//					goBack();
					}
					else if(newPer.equalsIgnoreCase(arr.privateTOpublic.toString()))
					{
						FileController.changeFilePermission(fileName, "public");
						JOptionPane.showMessageDialog(null, "Permission for this file: 'Public'. All data has been updated.");
						//					goBack();
					}
					else if(newPer.equalsIgnoreCase(arr.groupTOpublic.toString()))
					{
						FileController.removeFileFromALLgroups(fileName);
						FileController.changeFilePermission(fileName, "public");
						JOptionPane.showMessageDialog(null, "Permission for this file: 'Public'. All data has been updated.");
						//					goBack();
					}
					else goBack();
					buttonApplyPer.setEnabled(false);
					comboBoxFilePermission.setEnabled(false);

				}
			});

			JButton buttonApplyothergroups = new JButton("Apply");				// GROUP - OTHER GROUPS PERMISSION HAS BEEN CHOOSEN
			JButton buttonApplymygroups = new JButton("Apply");					// GROUP - MY GROUPS PERMISSION HAS BEEN CHOOSEN



			JButton btnBack = new JButton("Back");
			btnBack.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					goBack();
				}
			});

			JLabel lblFileName = new JLabel("File name:");
			lblFileName.setForeground(Color.BLACK);
			lblFileName.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lblFileName.setBounds(283, 45, 169, 23);
			mainpanelbg.add(lblFileName);
			btnBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
			btnBack.setEnabled(true);
			btnBack.setBounds(503, 292, 89, 23);
			mainpanelbg.add(btnBack);

			JLabel labelinstruction2 = new JLabel("For Group Permission click \"Apply\" for each selection.");
			labelinstruction2.setForeground(Color.BLACK);
			labelinstruction2.setFont(new Font("Tahoma", Font.PLAIN, 14));
			labelinstruction2.setBounds(15, 293, 329, 23);
			mainpanelbg.add(labelinstruction2);

			JLabel labelinstruction = new JLabel("For Private / Public Permission just click \"Apply\".");
			labelinstruction.setForeground(Color.BLACK);
			labelinstruction.setFont(new Font("Tahoma", Font.PLAIN, 14));
			labelinstruction.setBounds(15, 273, 312, 23);
			mainpanelbg.add(labelinstruction);

			JLabel labelfilename = new JLabel();
			labelfilename.setForeground(new Color(102, 0, 0));
			labelfilename.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelfilename.setBounds(380, 45, 243, 23);
			mainpanelbg.add(labelfilename);
			labelfilename.setText(fileName);



			buttonApplymygroups.addActionListener(new ActionListener() {		// GROUP - MY GROUPS PERMISSION HAS BEEN CHOOSEN
				public void actionPerformed(ActionEvent arg0) {
					String mygroup = (String) comboBoxyourGroups.getSelectedItem();
					String permission = (String) comboBoxpermissions1.getSelectedItem();

					if (mygroup == null)
					{
						JOptionPane.showMessageDialog(null, "No group selection");
					}
					else if ((CurFilePer.equalsIgnoreCase("private")) || (CurFilePer.equalsIgnoreCase("public")))
					{
						if (!permission.equalsIgnoreCase("none"))
						{
							FileController.changeFilePermission(fileName, "group");
							FileController.addFileToGroup(fileName, mygroup, permission);
							JOptionPane.showMessageDialog(null, "Permission for this file: 'Group'. All data has been updated.");
						}
					}
					else if (CurFilePer.equalsIgnoreCase("group"))
					{
						if (permission.equalsIgnoreCase("none"))
						{
							FileController.removeFileFromGroup(fileName, mygroup);
							JOptionPane.showMessageDialog(null, "Permission for this group has been removed.");
						}
						else if ((permission.equalsIgnoreCase("read")) || (permission.equalsIgnoreCase("update")))
						{
							FileController.addFileToGroup(fileName, mygroup, permission);
							JOptionPane.showMessageDialog(null, "Permission for this file: 'Group'. All data has been updated.");
						}
					}

					comboBoxyourGroups.setEnabled(false);
					comboBoxpermissions1.setEnabled(false);
					comboBoxotherGroups.setEnabled(false);
					comboBoxpermissions2.setEnabled(false);
					buttonApplymygroups.setEnabled(false);
					buttonApplyothergroups.setEnabled(false);
					comboBoxFilePermission.setEnabled(false);


				}
			});

			buttonApplymygroups.setFont(new Font("Tahoma", Font.PLAIN, 16));
			buttonApplymygroups.setBounds(413, 153, 89, 23);
			mainpanelbg.add(buttonApplymygroups);

			buttonApplyothergroups.setFont(new Font("Tahoma", Font.PLAIN, 16));
			buttonApplyothergroups.setBounds(413, 224, 89, 23);
			mainpanelbg.add(buttonApplyothergroups);

			buttonApplyothergroups.addActionListener(new ActionListener() {		// GROUP - OTHER GROUPS PERMISSION HAS BEEN CHOOSEN
				public void actionPerformed(ActionEvent e) {
					String othergroup = (String) comboBoxotherGroups.getSelectedItem();
					String permission = (String) comboBoxpermissions2.getSelectedItem();

					if (othergroup == null)
					{
						JOptionPane.showMessageDialog(null, "No group selection");

					}
					else if ((CurFilePer.equalsIgnoreCase("private")) || (CurFilePer.equalsIgnoreCase("public")))
					{
						if (!permission.equalsIgnoreCase("none"))
						{
							FileController.changeFilePermission(fileName, "group");
							FileController.addFileToGroup(fileName, othergroup, permission);
							JOptionPane.showMessageDialog(null, "Permission for this file: 'Group'. All data has been updated.");
						}
					}
					else if (CurFilePer.equalsIgnoreCase("group"))
					{
						if (permission.equalsIgnoreCase("none"))
						{
							FileController.removeFileFromGroup(fileName, othergroup);
							JOptionPane.showMessageDialog(null, "Permission for this group has been removed.");
						}
						else if (permission.equalsIgnoreCase("read"))
						{
							FileController.addFileToGroup(fileName, othergroup, permission);
							JOptionPane.showMessageDialog(null, "Permission for this file: 'Group'. All data has been updated.");
						}
					}

					comboBoxyourGroups.setEnabled(false);
					comboBoxpermissions1.setEnabled(false);
					comboBoxotherGroups.setEnabled(false);
					comboBoxpermissions2.setEnabled(false);
					buttonApplymygroups.setEnabled(false);
					buttonApplyothergroups.setEnabled(false);
					comboBoxFilePermission.setEnabled(false);

				}
			});

			buttonApplyPer.setFont(new Font("Tahoma", Font.PLAIN, 18));
			buttonApplyPer.setBounds(413, 83, 89, 23);
			buttonApplyPer.setEnabled(false);
			mainpanelbg.add(buttonApplyPer);

			btnLoadFilePermission = new JButton("Load Current File Permission");			// load details button
			btnLoadFilePermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
			btnLoadFilePermission.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					FileController.getFilePermission(fileName);
					lblPermission.setText(CurFilePer);
					comboBoxFilePermission.setEnabled(true);
					FileController.getGroupsUserIsIn(fileOwner);
					FileController.getGroupsUserIsNotIn(fileOwner);
				}
			});

			comboBoxFilePermission = new JComboBox();
			comboBoxFilePermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
			comboBoxFilePermission.setBounds(243, 79, 155, 31);
			comboBoxFilePermission.addItem("Public");
			comboBoxFilePermission.addItem("Private");
			comboBoxFilePermission.addItem("Group");
			comboBoxFilePermission.setEditable(false);
			comboBoxFilePermission.setEnabled(false);

			comboBoxFilePermission.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {

					if (comboBoxFilePermission.getSelectedItem() == "Public")
					{
						newPermission = "public";	
						comboBoxotherGroups.setEnabled(false);
						comboBoxpermissions2.setEnabled(false);
						comboBoxyourGroups.setEnabled(false);
						comboBoxpermissions1.setEnabled(false);
						buttonApplymygroups.setEnabled(false);
						buttonApplyothergroups.setEnabled(false);

						if (CurFilePer.equalsIgnoreCase("public")) newPer = arr.publicTOpublic.toString();
						if (CurFilePer.equalsIgnoreCase("private")) newPer = arr.privateTOpublic.toString();
						if (CurFilePer.equalsIgnoreCase("group")) newPer = arr.groupTOpublic.toString();

						buttonApplyPer.setEnabled(true);

					}
					else if (comboBoxFilePermission.getSelectedItem() == "Private")
					{
						newPermission = "private";  
						comboBoxyourGroups.setEnabled(false);
						comboBoxpermissions1.setEnabled(false);
						comboBoxotherGroups.setEnabled(false);
						comboBoxpermissions2.setEnabled(false);
						buttonApplymygroups.setEnabled(false);
						buttonApplyothergroups.setEnabled(false);

						if (CurFilePer.equalsIgnoreCase("public")) newPer = arr.publicTOprivate.toString();
						if (CurFilePer.equalsIgnoreCase("private")) newPer = arr.privateTOprivate.toString();
						if (CurFilePer.equalsIgnoreCase("group")) newPer = arr.groupTOprivate.toString();

						buttonApplyPer.setEnabled(true);

					}
					else if (comboBoxFilePermission.getSelectedItem() == "Group")
					{
						newPermission = "group";
						comboBoxotherGroups.setEnabled(true);
						comboBoxpermissions2.setEnabled(true);
						comboBoxyourGroups.setEnabled(true);
						comboBoxpermissions1.setEnabled(true);
						buttonApplymygroups.setEnabled(true);
						buttonApplyothergroups.setEnabled(true);
						FileController.getGroupsUserIsIn(fileOwner);
						FileController.getGroupsUserIsNotIn(fileOwner);

						if (CurFilePer.equalsIgnoreCase("public")) newPer = arr.publicTOgroup.toString();
						if (CurFilePer.equalsIgnoreCase("private")) newPer = arr.privateTOgroup.toString();
						if (CurFilePer.equalsIgnoreCase("group")) newPer = arr.groupTOgroup.toString();

						buttonApplyPer.setEnabled(false);
					}
				}
			});

			comboBoxpermissions2 = new JComboBox();
			comboBoxpermissions2.setBounds(248, 224, 150, 23);
			mainpanelbg.add(comboBoxpermissions2);
			comboBoxpermissions2.addItem("read");
			comboBoxpermissions2.addItem("none");


			JLabel labelpermissions2 = new JLabel("Permission:");
			labelpermissions2.setForeground(new Color(0, 51, 0));
			labelpermissions2.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelpermissions2.setBounds(248, 193, 131, 23);
			mainpanelbg.add(labelpermissions2);

			comboBoxotherGroups = new JComboBox();
			comboBoxotherGroups.setBounds(15, 224, 187, 23);
			mainpanelbg.add(comboBoxotherGroups);

			JLabel labelotherGroup = new JLabel("Other Groups:");
			labelotherGroup.setForeground(new Color(0, 51, 0));
			labelotherGroup.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelotherGroup.setBounds(15, 193, 233, 23);
			mainpanelbg.add(labelotherGroup);

			comboBoxpermissions1 = new JComboBox();
			comboBoxpermissions1.setBounds(248, 154, 150, 23);
			mainpanelbg.add(comboBoxpermissions1);
			comboBoxpermissions1.addItem("read");		
			comboBoxpermissions1.addItem("update");
			comboBoxpermissions1.addItem("none");

			JLabel labelpermissions1 = new JLabel("Permission:");
			labelpermissions1.setForeground(new Color(0, 51, 0));
			labelpermissions1.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelpermissions1.setBounds(248, 126, 131, 23);
			mainpanelbg.add(labelpermissions1);

			comboBoxyourGroups = new JComboBox();
			comboBoxyourGroups.setBounds(15, 154, 187, 23);
			mainpanelbg.add(comboBoxyourGroups);

			JLabel labelyourGroups = new JLabel("Your Groups:");
			labelyourGroups.setForeground(new Color(0, 51, 0));
			labelyourGroups.setFont(new Font("Tahoma", Font.PLAIN, 18));
			labelyourGroups.setBounds(15, 126, 218, 23);
			mainpanelbg.add(labelyourGroups);
			mainpanelbg.add(comboBoxFilePermission);

			JLabel lblNewPermission = new JLabel("New Permission:");
			lblNewPermission.setForeground(new Color(0, 51, 0));
			lblNewPermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lblNewPermission.setBounds(15, 83, 218, 23);
			mainpanelbg.add(lblNewPermission);

			lblPermission = new JLabel();
			lblPermission.setForeground(Color.RED);
			lblPermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lblPermission.setBounds(184, 45, 104, 23);
			mainpanelbg.add(lblPermission);


			JLabel lblCuurent = new JLabel("Current Permission:");
			lblCuurent.setForeground(Color.BLACK);
			lblCuurent.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lblCuurent.setBounds(15, 45, 169, 23);
			mainpanelbg.add(lblCuurent);
			btnLoadFilePermission.setBounds(313, 21, 279, 23);
			mainpanelbg.add(btnLoadFilePermission);

			JLabel lblmain = new JLabel("Set your file permissions:");
			lblmain.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 18));
			lblmain.setBounds(15, 16, 324, 35);
			mainpanelbg.add(lblmain);

			labelbackground = new JLabel("");					// bg label
			labelbackground.setBounds(0, 0, 733, 344);
			labelbackground.setIcon(new ImageIcon(img));
			mainpanelbg.add(labelbackground);	

			comboBoxyourGroups.setEnabled(false);
			comboBoxpermissions1.setEnabled(false);
			comboBoxotherGroups.setEnabled(false);
			comboBoxpermissions2.setEnabled(false);
			buttonApplymygroups.setEnabled(false);
			buttonApplyothergroups.setEnabled(false);

		}


		// *****************************************GET_REPLY********************************************

		/**
		 * @see boundary.AbstractGUI#getReply(java.lang.Object)
		 */
		@Override
		public void getReply(Object r) {

			Reply rep = (Reply) r;

			if (rep.getCommand().equals(Command.GET_FILE_PERMISSION))
			{
				CurFilePer = (String)rep.getResult();
				lblPermission.setText(CurFilePer);
				comboBoxFilePermission.setEnabled(true);
			}
			else if (rep.getCommand().equals(Command.LOADGROUPSUSERNOTIN))	// group not in
			{
				ArrayList<String> groupsnotin = (ArrayList<String>) rep.getResult();
				comboBoxotherGroups.removeAllItems();

				for (int i=0; i<groupsnotin.size(); i++)	
				{
					comboBoxotherGroups.addItem(groupsnotin.get(i));
				}
			}
			else if (rep.getCommand().equals(Command.LOADGROUPSUSERIN))		// group in
			{
				ArrayList<String> groupsin = (ArrayList<String>) rep.getResult();
				comboBoxyourGroups.removeAllItems();

				for (int i=0; i<groupsin.size(); i++)	
				{
					comboBoxyourGroups.addItem(groupsin.get(i));
				}
			}
		}
}
