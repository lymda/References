package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import controller.LoginController;
import entity.Reply;
import enums.Result;

/**
 * The Class LoginGUI designed for the user to log in to myBox system.
 */
public class LoginGUI extends AbstractGUI {
	
	public String resultfromDB;
	
	public String getResultfromDB() {
		return resultfromDB;
	}

	public void setResultfromDB(String resultfromDB) {
		this.resultfromDB = resultfromDB;
	}

	public String username;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String password;
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	/** The frame. */
	private JFrame frame;

	/** The text fieldusername. */
	private JTextField textFielduser;

	/** The text fieldpassword. */
	private JTextField textFieldpass;

	/** The cur user. */
	public String curUser;
	//	private ArrayList<String> arr = new ArrayList<String>();

	/**
	 * Instantiates a new login gui.
	 */
	public LoginGUI() {
		try {
			JFrame.setDefaultLookAndFeelDecorated(true);
			UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (Exception e) { }

		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 20, 381, 454);
		frame.getContentPane().setLayout(null);
		frame.setTitle("MyBox - Login");
		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();


		JButton buttonlogin = new JButton("Login");
		buttonlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				username = textFielduser.getText();
				password = textFieldpass.getText();

				curUser=username;									// roll to next GUI screens

				if (username.equals("") || password.equals("")) {
					JOptionPane.showMessageDialog(null,"Please Enter User Name and password.");
				}
				LoginController.LoginTest(username, password); 		// CALL CONTROL
			}
		});

		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon(LoginGUI.class.getResource("/boundary/images/loginlogo.png")));
		logo.setBounds(26, 13, 187, 156);
		frame.getContentPane().add(logo);
		buttonlogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
		buttonlogin.setBounds(114, 369, 115, 29);
		frame.getContentPane().add(buttonlogin);

		JButton btncancel = new JButton("Exit");
		btncancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int op = JOptionPane.showConfirmDialog(frame,"Are you sure you want to EXIT?", "Exit Confirm",
						JOptionPane.YES_NO_OPTION);
				if (op == 0)
					System.exit(0);

			}
		});
		btncancel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btncancel.setBounds(244, 369, 115, 29);
		frame.getContentPane().add(btncancel);

		textFieldpass = new JPasswordField();
		textFieldpass.setFont(new Font("Tahoma", Font.PLAIN, 22));
		textFieldpass.setColumns(10);
		textFieldpass.setBounds(151, 259, 200, 34);
		frame.getContentPane().add(textFieldpass);

		textFielduser = new JTextField();
		textFielduser.setFont(new Font("Tahoma", Font.PLAIN, 22));
		textFielduser.setBounds(151, 199, 200, 34);
		frame.getContentPane().add(textFielduser);
		textFielduser.setColumns(10);

		JLabel labelpass = new JLabel("Password");
		labelpass.setFont(new Font("Copperplate Gothic Bold", Font.PLAIN, 20));
		labelpass.setBounds(12, 249, 137, 50);
		frame.getContentPane().add(labelpass);

		JLabel lblUserName = new JLabel("User Name");
		lblUserName
		.setFont(new Font("Copperplate Gothic Bold", Font.PLAIN, 20));
		lblUserName.setBounds(12, 189, 137, 50);
		frame.getContentPane().add(lblUserName);

		JLabel lblbackground = new JLabel("");
		lblbackground.setBounds(-87, 0, 557, 468);
		frame.getContentPane().add(lblbackground);
		lblbackground.setIcon(new ImageIcon(img));

	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {

		Reply rep = (Reply) r;
		Result res = (Result) rep.getResult();

		if (res == Result.WRONGUSER) {
			resultfromDB = "WRONGUSER";
//			JOptionPane.showMessageDialog(null, "Invalid User Name.");
		}
		if (res == Result.WRONGPASS) {
			resultfromDB ="WRONGPASS";
//			JOptionPane.showMessageDialog(null, "Invalid Password.");
		}
		else if (res == Result.ALREADYLOGIN) {
			resultfromDB = "ALREADYLOGIN";
//			JOptionPane.showMessageDialog(null, "This user is already Logged.");
		}
		else if (res == Result.ISUSER)
		{
			resultfromDB = "ISUSER";
//			hide();
//			resultfromDB = Result.ISUSER.toString();
//			MainWorkSpaceGUI usergui = new MainWorkSpaceGUI(curUser);
		}
		else if (res == Result.ISADMIN)
		{
			resultfromDB = "ISADMIN";
//			hide();
//			resultfromDB = Result.ISADMIN.toString();
//			AdminMainWorkSpaceGUI admingui = new AdminMainWorkSpaceGUI(curUser);
		}
		/*
		else if (rep.getResult() instanceof ArrayList<?>){
			arr=(ArrayList<String>) rep.getResult();
		}
		 */

		//		else if (usr instanceof User) {
		//			 User user = (User) r;
		//			 ClientController.setCurrentUser(user);
		//			 boolean x = user.isAdmin();
		//		
		//			 if (x == false)
		//			 {
		//				 hide();
		//				 MainWorkSpaceGUI usergui = new MainWorkSpaceGUI();
		//			 }
		//			 else if (x == false)
		//			 {
		//				 hide();
		//				 AdminMainWorkSpaceGUI admingui = new AdminMainWorkSpaceGUI();
		//			 }
		//		}

	}
}
