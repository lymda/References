package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import controller.GroupController;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class GroupRequestsGUI designed for the user to .
 */
public class GroupRequestsGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The join group cmb. */
	private JComboBox joinGroupCmb;

	/** The groups useris in cmb. */
	private JComboBox groupsUserisInCmb;

	/** The paneljoin. */
	private JPanel paneljoin;

	/** The panelquit. */
	private JPanel panelquit;

	/** The cur usr. */
	private String curUsr;

	/**
	 * Instantiates a new group requests gui.
	 *
	 * @param Usr the usr
	 */
	public GroupRequestsGUI(String Usr) {
		initialize(Usr);
		this.initGUI(frame);

	}

	/**
	 * Initialize.
	 *
	 * @param Usr the usr
	 */
	public void initialize(String Usr){
		this.curUsr=Usr;
		frame=new JFrame();
		frame.setTitle("MyBox - Group Requests");
		frame.setBounds(100, 20, 480, 338);
		//frame.setResizable(false);
		//frame.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		JPanel mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);

		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);

		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JTabbedPane labeltabs = new JTabbedPane(JTabbedPane.TOP);
		labeltabs.setBounds(20, 16, 439, 232);
		mainpanelbg.add(labeltabs);

		paneljoin = new JPanel();
		paneljoin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		labeltabs.addTab("Join group", null, paneljoin, null);
		paneljoin.setLayout(null);

		JLabel lblgrname = new JLabel("Choose group:");
		lblgrname.setBounds(15, 16, 174, 27);
		paneljoin.add(lblgrname);
		lblgrname.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));

		JButton btnsendjoin = new JButton("Send Request to join Group");
		btnsendjoin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(joinGroupCmb.getItemCount()==0)
					JOptionPane.showMessageDialog(null, "There is no group to send.", "Error", JOptionPane.ERROR_MESSAGE);
				else
					GroupController.Request(curUsr,joinGroupCmb.getSelectedItem().toString(),"add");
			}
		});
		btnsendjoin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnsendjoin.setBounds(15, 153, 270, 29);
		paneljoin.add(btnsendjoin);

		joinGroupCmb = new JComboBox();
		joinGroupCmb.setBounds(199, 21, 211, 20);
		GroupController.GetGroupsUserIsNotIn(curUsr);

		panelquit = new JPanel();
		panelquit.setFont(new Font("Tahoma", Font.PLAIN, 18));
		labeltabs.addTab("Quit group", null, panelquit, null);
		panelquit.setLayout(null);

		JLabel lblgrname2 = new JLabel("Choose group:");
		lblgrname2.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		lblgrname2.setBounds(15, 16, 174, 27);
		panelquit.add(lblgrname2);

		JButton btnSendLeave = new JButton("Send Request to leave Group");
		btnSendLeave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(groupsUserisInCmb.getItemCount()==0)
					JOptionPane.showMessageDialog(null, "There is no group to send.", "Error", JOptionPane.ERROR_MESSAGE);
				else
					GroupController.Request(curUsr,groupsUserisInCmb.getSelectedItem().toString(),"leave");
			}
		});
		btnSendLeave.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnSendLeave.setBounds(15, 153, 270, 29);
		panelquit.add(btnSendLeave);

		groupsUserisInCmb = new JComboBox();
		groupsUserisInCmb.setBounds(199, 21, 201, 20);
		GroupController.GetGroupsUserIn(curUsr);



		JButton btnBACK = new JButton("Back");
		btnBACK.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBACK.setBounds(370, 259, 89, 23);
		btnBACK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//hide();
				goBack();
			}
		});
		mainpanelbg.add(btnBACK);

		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 474, 345);
		mainpanelbg.add(labelbackground);
		labelbackground.setIcon(new ImageIcon(img));
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep=(Reply)r;
		if(rep.getCommand().equals(Command.LOADGROUPSUSERNOTIN))
		{
			ArrayList<String> groups=(ArrayList<String>)rep.getResult();
			Object[] str=groups.toArray();
			joinGroupCmb.removeAllItems();
			for(Object str1 : str) {
				joinGroupCmb.addItem(str1);
			}
			paneljoin.add(joinGroupCmb);
			paneljoin.revalidate();
			paneljoin.repaint();
		}
		else if(rep.getCommand().equals(Command.LOADGROUPSUSERIN))
		{
			ArrayList<String> groups=(ArrayList<String>)rep.getResult();
			Object[] str=groups.toArray();
			groupsUserisInCmb.removeAllItems();
			for(Object str1 : str) {
				groupsUserisInCmb.addItem(str1);
			}
			panelquit.add(groupsUserisInCmb);
			panelquit.revalidate();
			panelquit.repaint();
		}
		else if(rep.getCommand().equals(Command.ADDREQUEST) || rep.getCommand().equals(Command.DELETEREQUEST))
		{
			if(rep.getResult().equals(Result.REQUESTEXISTS))
			{
				JOptionPane.showMessageDialog(null, "Request is allready in the system.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(rep.getResult().equals(Result.ERROR))
			{
				JOptionPane.showMessageDialog(null, "Sorry, an error has accured while trying to send your request.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(rep.getResult().equals(Result.REQUESTADDED))
			{
				JOptionPane.showMessageDialog(null, "Request has been sent seccessfuly.", "Done", JOptionPane.PLAIN_MESSAGE);
			}			
		}
	}
}
