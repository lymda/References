package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import client.ClientController;
import controller.FileController;
import entity.FileDetails;
import entity.Reply;
import java.awt.Label;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * The Class EditDetailsGUI designed for the user to make changes and update file details.
 */
public class EditDetailsGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The current user. */
	private String currUser = "";

	/** The text fieldname. */
	private JTextField textFieldname;

	/** The description flag. */
	private int nameFlag = 0, discriptionFlag = 0;

	/** The btn ok. */
	private JButton btnOk;

	/** The details entity. */
	private FileDetails details;

	/**
	 * Instantiates a new edits the details gui.
	 *
	 * @param currUser the current user
	 * @param b the button that represents file in the workspace gui
	 */
	public EditDetailsGUI(String currUser, JButton b) {

		details = new FileDetails(null, null, null, 0, 0);
		details.oldFileName = b.getText();
		this.currUser = currUser;
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setTitle("MyBox - Edit Details");
		frame.setBounds(100, 20, 439, 505);

		JPanel mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);

		Image img0 = new ImageIcon(this.getClass().getResource(
				"images/icon.jpg")).getImage();
		frame.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource(
				"images/wall12.jpg")).getImage();
		mainpanelbg.setLayout(null);

		Image img1 = new ImageIcon(this.getClass().getResource(
				"images/ok - 13.png")).getImage();

		JLabel lblFileName = new JLabel("File Name:");
		lblFileName.setBounds(10, 16, 201, 31);
		lblFileName
		.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		mainpanelbg.add(lblFileName);

		textFieldname = new JTextField();

		textFieldname.setToolTipText("Insert & Check unique File Name");

		textFieldname.setBounds(211, 16, 184, 29);
		textFieldname.setBorder(new BevelBorder(BevelBorder.LOWERED, null,
				null, null, null));
		textFieldname.setFont(new Font("Tahoma", Font.PLAIN, 18));
		mainpanelbg.add(textFieldname);

		JButton btncheck = new JButton("Check file name");
		btncheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileController.checkFileExistence(textFieldname.getText(),
						currUser);
			}
		});
		btncheck.setBounds(221, 50, 174, 23);
		mainpanelbg.add(btncheck);
		btncheck.setIcon(new ImageIcon(img1));

		JLabel lblFileDescription = new JLabel("File Description:");
		lblFileDescription.setBounds(10, 82, 201, 37);
		lblFileDescription.setFont(new Font("Copperplate Gothic Light",
				Font.BOLD, 18));
		mainpanelbg.add(lblFileDescription);

		JTextArea textAreadescription = new JTextArea();

		textAreadescription.setToolTipText("Insert & Check File Description");
		textAreadescription.setBounds(211, 86, 184, 272);
		textAreadescription.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null,
				null, null));
		textAreadescription.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textAreadescription.setLineWrap(true);
		mainpanelbg.add(textAreadescription);

		JButton btncheck2 = new JButton("Check file discription");
		btncheck2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) { // CHECK LESS THAN
				// 30 WORDS IN
				// DESCRIPTION

				String s = new String(textAreadescription.getText());
				String[] tokens = textAreadescription.getText().split("\\s+");

				if (tokens.length > 30) {
					JOptionPane.showMessageDialog(null,
							"File Description must be less than 30 words.");
					// textAreades.setText("");
				} else {
					if (++discriptionFlag == 1) {
						btnOk.setEnabled(true);
					}
					textAreadescription.setEditable(false);
					details.description = textAreadescription.getText();
					details.discriptionFlag = 1;
					JOptionPane.showMessageDialog(null,
							"File Description is ok.");
				}
			}
		});
		btncheck2.setBounds(221, 371, 174, 23);
		mainpanelbg.add(btncheck2);
		btncheck2.setIcon(new ImageIcon(img1));

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}

		});
		btnCancel.setBounds(315, 422, 89, 23);
		mainpanelbg.add(btnCancel);

		btnOk = new JButton("OK");
		btnOk.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (details.nameFlag == 1) {

					FileChoosedGUI fc = (FileChoosedGUI) ClientController
							.getGUIFlow().get(
									ClientController.getGUIFlow().size() - 2);
					fc.getB().setText(details.fileName);
				}
				FileController.editFileDetails(details, currUser);
				goBack();
			}
		});
		btnOk.setBounds(211, 422, 89, 23);
		btnOk.setEnabled(false);
		mainpanelbg.add(btnOk);

		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 451, 491);
		mainpanelbg.add(labelbackground);
		labelbackground.setIcon(new ImageIcon(img));
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {

		Reply rep = (Reply) r;
		if ((boolean) rep.getResult()) {
			JOptionPane.showMessageDialog(null,
					"File name allready exist, please choose diffrent one.");

		} else if (!(boolean) rep.getResult()) {
			textFieldname.setEditable(false);

			if (++nameFlag == 1) {
				btnOk.setEnabled(true);
			}
			details.fileName = textFieldname.getText();
			details.nameFlag = 1;
			JOptionPane.showMessageDialog(null, "File name ok.");
		}

	}
}
