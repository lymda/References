package boundary;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import controller.CreateNewFolderController;
import controller.FileController;
import controller.GetClientRootController;
import controller.LoadFilesFolderForWorkspaceController;
import controller.LoadFilesFoldersForFolderController;
import controller.LogoutController;
import controller.WSController;
import entity.FileFolderID;
import entity.Folder;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class MainWorkSpaceGUI consists all relevant buttons to manage myBox system for the User.
 * 
 */
public class MainWorkSpaceGUI extends AbstractGUI {

	/** The frc is File Right Click GUI. */
	private FileRightClickGUI frc;

	/** The copied file name. */
	private String copiedFileName; //file name that has been copied\cutted 

	/** The id of the folder that the file has bean copied or cut from. */
	private int fromFolderID;
	
	/** The id of the folder that the file has bean past to. */
	private int toFolderID;
	
	/** The operation, copy or cut. */
	private String operation; //the operation (copy\cut) 

	/** The button of the file that we want to cut. */
	private JButton removedButton;

	/** The panel of the removedButton. */
	private JPanel panelOfTheRemovedButton ;

	/** The label of the path of the current folder. */
	private JLabel lblPath;

	/** The current user. */
	public String curUser;

	/** for dealing with files in the os. */
	private Desktop desktop;

	/** The frame. */
	private JFrame frame;

	/** The logout button. */
	private JButton buttonlogout;

	/** The 'View authorized files' button. */
	private JButton buttonview;

	/** The 'Files to Delete'  button . */
	private JButton buttonbin;

	/** The  manage groups button. */
	private JButton btnManageGroups;

	/** The  'create new file' button. */
	private JButton btnCreateNewFile;

	/** The  'update file' button. */
	private JButton buttonUpdateFile;

	/** The  'create new folder' button. */
	private JButton btnCreateNewFolder;

	/** The 'create new work space button. */
	private JButton btnNewWS;

	/** The scroll pane. */
	private JScrollPane scrollPane;

	/** The path of the folder that the files will downloaded to there. */
	private	String rootPath;

	/** array list of  files names. */
	private ArrayList<String> fileNameArr;

	/** array list of  folders names. */
	private ArrayList<String> folderNameArr;

	/** array list of the name of all the opened folders. */
	private ArrayList<String> folderPathNameArr;

	/** array list of the id's of the opened folders. */
	private ArrayList<Integer> folderPath;

	/** array list of panels. each panel created when we open a folder. */
	private ArrayList<JPanel> panelArr;

	/** The create new file gui. */
	private CreateNewFileGUI createNewFileGUI;

	/** image of a folder. */
	private Image imgfolder = new ImageIcon(this.getClass().getResource("images/folder.png")).getImage();

	/** image of a file. */
	private Image imgfile = new ImageIcon(this.getClass().getResource("images/file.png")).getImage();

	/** The 'message board' button. */
	private JButton btnMessageBoard;

	/** user name label. */
	private JLabel lblUsername;

	/** current path label. */
	private JLabel lbl2Path;

	/**
	 * Constructor of the class.
	 *
	 * @param un the user name
	 */
	public MainWorkSpaceGUI(String un) {

		try {
			UIManager.getSystemLookAndFeelClassName();
		} catch (Exception e) { }

		desktop=Desktop.getDesktop();
		curUser = un;
		this.rootPath="";
		initialize();
		this.initGUI(frame);
		WSController.CheckWS(curUser);
	}

	/**
	 * Instantiates a new main work space gui.
	 */
	private void initialize() {
		GetClientRootController.getRoot(curUser);
		panelArr= new ArrayList<JPanel>();
		fileNameArr = new ArrayList<String>();
		folderNameArr = new ArrayList<String>();
		folderPath= new ArrayList<Integer>();
		folderPathNameArr=  new ArrayList<String>();

		frame = new JFrame();
		frame.setBounds(100, 20, 1124, 700);

		frame.getContentPane().setLayout(null);
		frame.setTitle("MyBox - My WorkSpace");
		Image imgic = new ImageIcon(this.getClass().getResource(
				"images/icon.jpg")).getImage();
		frame.setIconImage(imgic);

		btnMessageBoard = new JButton("Message Board");
		btnMessageBoard.setHorizontalAlignment(SwingConstants.LEFT);
		btnMessageBoard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				hide();
				MessageBoardGUI messageBoardGUI=new MessageBoardGUI(curUser);
			}
		});
		btnMessageBoard.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnMessageBoard.setBounds(15, 451, 247, 35);
		Image imgmsg = new ImageIcon(this.getClass().getResource("images/message - 26.png")).getImage();

		lblUsername = new JLabel(curUser);
		lblUsername.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsername.setFont(new Font("Vivaldi", Font.BOLD, 32));
		lblUsername.setForeground(Color.BLACK);
		lblUsername.setBounds(15, 173, 254, 44);
		frame.getContentPane().add(lblUsername);
		btnMessageBoard.setIcon(new ImageIcon(imgmsg));
		frame.getContentPane().add(btnMessageBoard);


		JLabel labellogo = new JLabel("");
		labellogo.setBounds(40, 16, 160, 160);
		frame.getContentPane().add(labellogo);
		labellogo.setIcon(new ImageIcon(MainWorkSpaceGUI.class.getResource("/boundary/images/loginlogo.png")));

		buttonlogout = new JButton("Logout"); // buttonlogout
		buttonlogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(frame,
						"Are you sure you want to Logout?", "Confirm",
						JOptionPane.YES_NO_OPTION) == 0)
					LogoutController.LogoutTest(curUser);
			}
		});

		JButton  btnNewButton= new JButton("Back");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnNewButton.setIcon(new ImageIcon(new ImageIcon(this.getClass().getResource("images/back-icon.png")).getImage()));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(panelArr.size()>1){
					scrollPane.setViewportView(panelArr.get(panelArr.size()-2));
					panelArr.remove(panelArr.size()-1);
					folderPath.remove(folderPath.size()-1);
					String s = getlblPath();
					int endIndex= s.length() - folderPathNameArr.get(folderPathNameArr.size()-1).length() -1 ;
					setlblPath(s.substring(0, endIndex));
					if(folderPathNameArr.size()>0)
						folderPathNameArr.remove(folderPathNameArr.size()-1);
				}
			}
		});
		btnNewButton.setBounds(958, 482, 140, 50);
		frame.getContentPane().add(btnNewButton);

		JButton btnpaste = new JButton("Paste file");
		btnpaste.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(copiedFileName!=null){
					if(operation.equals("Copy")){
						FileController.addFiletoFolder(copiedFileName, folderPath.get(folderPath.size()-1));					
					}
					else if (operation.equals("Cut")){
						toFolderID=folderPath.get(folderPath.size()-1);
						FileController.deleteFileFromFolder(copiedFileName, fromFolderID);
						FileController.addFiletoFolder(copiedFileName, toFolderID);
						removeButton(removedButton, panelOfTheRemovedButton );						
					}
				}
			}
		});

		Image imgpaste = new ImageIcon(this.getClass().getResource("images/newpaste.png")).getImage();
		btnpaste.setIcon(new ImageIcon(imgpaste));

		lblPath = new JLabel("No workspace");
		lblPath.setForeground(Color.DARK_GRAY);
		lblPath.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPath.setBounds(348, 541, 575, 20);
		frame.getContentPane().add(lblPath);

		lbl2Path = new JLabel("Path:");
		lbl2Path.setFont(new Font("Tahoma", Font.BOLD, 18));
		lbl2Path.setBounds(281, 543, 82, 14);
		frame.getContentPane().add(lbl2Path);
		btnpaste.setBounds(958, 431, 140, 35);
		frame.getContentPane().add(btnpaste);

		scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(281, 16, 667, 516);
		frame.getContentPane().add(scrollPane);

		panelArr.add(new JPanel());
		panelArr.get(panelArr.size()-1).setBackground(Color.WHITE);
		panelArr.get(panelArr.size()-1).setLayout(new GridLayout(0, 2, 0, 0));
		scrollPane.setViewportView(panelArr.get(panelArr.size()-1));

		buttonlogout.setFont(new Font("Tahoma", Font.PLAIN, 22));
		buttonlogout.setBounds(948, 600, 160, 50);
		frame.getContentPane().add(buttonlogout);
		Image imgout = new ImageIcon(this.getClass().getResource(
				"images/logout - 26.png")).getImage();
		buttonlogout.setIcon(new ImageIcon(imgout));


		buttonview = new JButton("View authorized files"); // buttonview
		buttonview.setHorizontalAlignment(SwingConstants.LEFT);
		buttonview.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonview.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				AuthorizedFileGUI authorizedFileGUI = new AuthorizedFileGUI(curUser);
			}
		});
		buttonview.setBounds(15, 409, 247, 35);
		frame.getContentPane().add(buttonview);
		Image imgview = new ImageIcon(this.getClass().getResource(
				"images/file - 26.png")).getImage();
		buttonview.setIcon(new ImageIcon(imgview));

		buttonbin = new JButton("Files to Delete"); // buttonbin
		buttonbin.setHorizontalAlignment(SwingConstants.LEFT);
		buttonbin.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonbin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				RecycleBinGUI recycleBinGUI = new RecycleBinGUI(curUser);
			}
		});
		buttonbin.setBounds(15, 493, 247, 35);
		frame.getContentPane().add(buttonbin);
		Image imgbin = new ImageIcon(this.getClass().getResource(
				"images/newbin.png")).getImage();
		buttonbin.setIcon(new ImageIcon(imgbin));

		btnManageGroups = new JButton("Group Requests"); // btnManageGroups
		btnManageGroups.setHorizontalAlignment(SwingConstants.LEFT);
		btnManageGroups.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnManageGroups.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				GroupRequestsGUI groupRequestsGUI = new GroupRequestsGUI(curUser);
			}
		});
		btnManageGroups.setBounds(15, 367, 247, 35);
		frame.getContentPane().add(btnManageGroups);
		Image imggr = new ImageIcon(this.getClass().getResource(
				"images/groupgreen - 26.png")).getImage();
		btnManageGroups.setIcon(new ImageIcon(imggr));

		btnCreateNewFile = new JButton("Create New File"); // btnCreateNewFile
		btnCreateNewFile.setHorizontalAlignment(SwingConstants.LEFT);
		btnCreateNewFile.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCreateNewFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				createNewFileGUI = new CreateNewFileGUI(curUser);
			}
		});
		btnCreateNewFile.setBounds(15, 281, 247, 35);
		frame.getContentPane().add(btnCreateNewFile);
		Image imgfile = new ImageIcon(this.getClass().getResource(
				"images/newfile - 26.png")).getImage();
		btnCreateNewFile.setIcon(new ImageIcon(imgfile));

		buttonUpdateFile = new JButton("Update File"); // buttonupdate
		buttonUpdateFile.setHorizontalAlignment(SwingConstants.LEFT);
		buttonUpdateFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				hide();
				UpdateFileGUI updateFileGUI = new UpdateFileGUI();
			}
		});
		buttonUpdateFile.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonUpdateFile.setBounds(15, 325, 247, 35);
		frame.getContentPane().add(buttonUpdateFile);
		Image imgup = new ImageIcon(this.getClass().getResource(
				"images/updatefile - 26.png")).getImage();
		buttonUpdateFile.setIcon(new ImageIcon(imgup));

		btnCreateNewFolder = new JButton("Create New Folder"); // btnCreateNewFolder
		btnCreateNewFolder.setHorizontalAlignment(SwingConstants.LEFT);
		btnCreateNewFolder.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCreateNewFolder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name = JOptionPane.showInputDialog(frame, "Enter a folder name");
				if ((name != null) && (name.length() > 0)) {
					CreateNewFolderController.sentReq(name, folderPath.get(folderPath.size()-1));
				}
				else JOptionPane.showMessageDialog(null, "You must enter folder name!");
			}
		});
		btnCreateNewFolder.setBounds(15, 238, 247, 35);
		frame.getContentPane().add(btnCreateNewFolder);
		Image imgfol = new ImageIcon(this.getClass().getResource(
				"images/addfolder2 - 26.png")).getImage();
		btnCreateNewFolder.setIcon(new ImageIcon(imgfol));

		btnNewWS = new JButton("Create New WorkSpace"); // btnNewWS
		btnNewWS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WSController.CreateWS(curUser);
			}
		});
		btnNewWS.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewWS.setBounds(15, 600, 276, 44);
		frame.getContentPane().add(btnNewWS);
		Image imgws = new ImageIcon(this.getClass().getResource(
				"images/addfolder - 26.png")).getImage();
		btnNewWS.setIcon(new ImageIcon(imgws));

		JLabel labelbackground = new JLabel("");
		labelbackground.setFont(new Font("Tahoma", Font.PLAIN, 18));
		labelbackground.setBounds(0, 0, 1119, 699);
		frame.getContentPane().add(labelbackground);

		Image img = new ImageIcon(this.getClass().getResource(
				"images/wall1118.jpg")).getImage();
		labelbackground.setIcon(new ImageIcon(img));

	}



	/**
	 * Add a file button.
	 *
	 * @param name the name of the file button 
	 * @param imgfile1 the image of a file
	 */
	public void addFileButton(String name, Image imgfile1) {
		JButton b = new JButton(name);

		b.setOpaque(false);
		b.setContentAreaFilled(false);
		b.setIcon(new ImageIcon(imgfile1));
		b.setHorizontalAlignment(SwingConstants.LEFT);
		b.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				if (e.getButton() == 3)
				{
					frame.setEnabled(false);
					removedButton=(JButton) e.getSource();
					frc = new FileRightClickGUI();
					copiedFileName=removedButton.getText();
					frc.getBtnCopy().addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							operation="Copy";
							frc.goBack();
							frame.setEnabled(true);
						}
					});
					frc.getBtnCut().addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							operation="Cut";
							fromFolderID=folderPath.get(folderPath.size()-1);
							panelOfTheRemovedButton = panelArr.get(panelArr.size()-1);
							frc.goBack();
							frame.setEnabled(true);
						}
					});
				}
				else
				{
					hide();
					FileChoosedGUI fc = new FileChoosedGUI((JButton) e.getSource(),curUser,folderPath.get(folderPath.size()-1));
				}

			}
		});


		int size = panelArr.size();
		if (size>0){
			panelArr.get(panelArr.size()-1).add(b);
			panelArr.get(panelArr.size()-1).revalidate();
			panelArr.get(panelArr.size()-1).repaint();
		}
	}

	/**
	 * Add a folder button.
	 *
	 * @param name the name of the folder
	 * @param imgfolder the image of a folder
	 */
	public void addFolderButton(String name, Image imgfolder) {
		JButton b = new JButton(name);

		b.setOpaque(false);
		b.setContentAreaFilled(false);
		b.setIcon(new ImageIcon(imgfolder));
		b.setHorizontalAlignment(SwingConstants.LEFT);
		b.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JButton b=(JButton) e.getSource();
				if (e.getButton() == 3)
				{
					int parentID=folderPath.get(folderPath.size()-1);
					Folder f = new Folder(b.getText(),parentID);
					FolderRightClickGUI frc = new FolderRightClickGUI(f,b);
					frame.setEnabled(false);
					//JOptionPane.showMessageDialog(null, parentID);
				}
				else
				{	
					folderPathNameArr.add(b.getText());
					panelArr.add(new JPanel());
					panelArr.get(panelArr.size()-1).setBackground(Color.WHITE);
					panelArr.get(panelArr.size()-1).setLayout(new GridLayout(0, 2, 0, 0));
					scrollPane.setViewportView(panelArr.get(panelArr.size()-1));
					LoadFilesFoldersForFolderController.sentReq(b.getText(),folderPath);
					String newPath=getlblPath()+"\\"+ b.getText();
					setlblPath(newPath);
				}

			}
		});

		panelArr.get(panelArr.size()-1).add(b);
		panelArr.get(panelArr.size()-1).revalidate();
		panelArr.get(panelArr.size()-1).repaint();

	}

	/**
	 * Remove button.
	 *
	 * @param b the button we want to remove
	 */
	public void removeButton(JButton b) {
		panelArr.get(panelArr.size()-1).remove(b);
		for(JPanel panel:panelArr){
			panel.revalidate();
			panel.repaint();
		}
	}

	/**
	 * Remove button.
	 *
	 * @param b the button we want to remove
	 * @param panel the panel of the button we want to remove
	 */
	public void removeButton(JButton b, JPanel panel) {
		panel.remove(b);
		panel.revalidate();
		panel.repaint();		
	}


	/**
	 * Gets the folder path arraylist.
	 *
	 * @return the folder path
	 */
	public ArrayList<Integer> getFolderPath(){
		return this.folderPath;
	}

	/**
	 * Gets the path label.
	 *
	 * @return the path label
	 */
	public String getlblPath(){
		return lblPath.getText();
	}

	/**
	 * Sets the lbl path.
	 *
	 * @param s the new lbl path
	 */
	public void setlblPath(String s){
		this.lblPath.setText(s);
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {

		Reply rep = (Reply) r;

		if (rep.getCommand().equals(Command.ADDFILETOFOLDER))
		{	
			if(!rep.getResult().equals(Result.FILEEXIST)){
				addFileButton(copiedFileName,imgfile);	
			}
		}

		if (rep.getResult() instanceof Result)
		{

			Result res = (Result) rep.getResult();

			if (res == Result.LOGGEDOUT)
			{
				JOptionPane.showMessageDialog(null, "Logged Out.");
				goBack();
			}			
			else if (res == Result.FILEEXIST)
			{
				JOptionPane.showMessageDialog(null, "File name already exist!");
			}
			else if (res == Result.FILENOTEXIST)
			{
				addFileButton(createNewFileGUI.getTextField().getText(),imgfile);
			}
			else if (res == Result.WSNOTEXIST)
			{
				buttonview.setEnabled(false);
				buttonbin.setEnabled(false);
				btnManageGroups.setEnabled(false);
				btnCreateNewFile.setEnabled(false);
				buttonUpdateFile.setEnabled(false);
				btnCreateNewFolder.setEnabled(false);
				btnMessageBoard.setEnabled(false);

			}
			else if (res == Result.WSEXIST)
			{
				buttonview.setEnabled(true);
				buttonbin.setEnabled(true);
				btnManageGroups.setEnabled(true);
				btnCreateNewFile.setEnabled(true);
				buttonUpdateFile.setEnabled(true);
				btnCreateNewFolder.setEnabled(true);
				btnMessageBoard.setEnabled(true);
				btnNewWS.setEnabled(false);
				LoadFilesFolderForWorkspaceController.sentReq(curUser);
				setlblPath("WS"+curUser);
			}
			else if (res == Result.WSHASBEENCREATED)
			{	
				JOptionPane.showMessageDialog(null, "Welcome! now you have your 'myBox' WorkSpace to share with friends.");
				JOptionPane.showMessageDialog(null, "In the next screen please choose a path at your PC for downloaded files.");
				JFileChooser myFileChooser = new JFileChooser();
				myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				myFileChooser.showOpenDialog(null);

				File newfile = myFileChooser.getSelectedFile();
				String path = newfile.getAbsolutePath();
				this.rootPath=path;

				WSController.Createpath(curUser, path);
				WSController.CheckWS(curUser);
				LoadFilesFolderForWorkspaceController.sentReq(curUser);
			}
			else if (res == Result.WSCREATIONERROR)
			{
				JOptionPane.showMessageDialog(null, "WorkSpace creation is failed.");
			}
			else if (res == Result.FOLDEREXIST)
			{
				JOptionPane.showMessageDialog(null, "Folder already exist!");
			}
		}
		else if (rep.getCommand().equals(Command.LOADFILESFOLDERSFORWORKSPACE))
		{	
			FileFolderID ffid = (FileFolderID) rep.getResult();
			fileNameArr = ffid.getFileArr();
			folderNameArr = ffid.getFolderArr();
			folderPath.add(ffid.getFolderID());
			for (int i = 0; i < folderNameArr.size(); i++)
			{
				addFolderButton(folderNameArr.get(i), imgfolder);
			}
			for (int i = 0; i < fileNameArr.size(); i++)
			{
				addFileButton(fileNameArr.get(i), imgfile);
			}
		}
		else if (rep.getCommand().equals(Command.LOADFILESFOLDERSFORFOLDER))
		{	
			FileFolderID ffid = (FileFolderID) rep.getResult();
			folderPath.add(ffid.getFolderID());
			for(String name : ffid.getFolderArr()){
				addFolderButton(name,imgfolder);
			}
			for(String name : ffid.getFileArr()){
				addFileButton(name,imgfile);
			}
		}		

		else if (rep.getResult() instanceof entity.Folder)
		{
			Folder f=(Folder)rep.getResult();
			addFolderButton(f.getFolderName(), imgfolder);
		}

		else if (rep.getCommand().equals(Command.GET_ROOT_CLIENT_PATH)) {
			this.rootPath=(String) rep.getResult();

		}
	}

	/**
	 * Gets the root path.
	 *
	 * @return the root path
	 */
	public String getRootPath () {
		return this.rootPath;
	}

	/**
	 * Gets the imgfile.
	 *
	 * @return the imgfile
	 */
	public  Image getImgfile() {
		return imgfile;
	}
}



