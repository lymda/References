package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import controller.GroupController;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class ManageGroupsGUI designed for the admin to manage groups of the system.
 */
public class ManageGroupsGUI extends AbstractGUI {
    
    	public boolean addGroupResult;
    	public boolean addUserResult;

	/** The text fieldname. */
	private JTextField textFieldname;

	/** The frame. */
	private JFrame frame;

	/** The add users combo. */
	private JComboBox addUsersCombo;

	/** The combo box_1. */
	private JComboBox comboBox_1;

	/** The paneledit. */
	private JPanel paneledit;

	/** The lbl remove users. */
	private JLabel lblRemoveUsers;

	/** The remove users button. */
	private JButton removeUsersButton;

	/** The group combo. */
	private JComboBox groupCombo;

	/** The lbl add user. */
	private JLabel lblAddUser;

	/** The add users button. */
	private JButton addUsersButton;

	/**
	 * Instantiates a new manage groups gui.
	 */
	public ManageGroupsGUI() {
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize.
	 */
	private void initialize(){
		frame=new JFrame();
		frame.setTitle("MyBox - Manage Groups");
		frame.setBounds(100, 20, 480, 600);
		JPanel mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);


		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				goBack();
			}
		});
		btnBack.setBounds(370, 521, 89, 23);
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				goBack();			}
		});
		mainpanelbg.add(btnBack);

		JTabbedPane labeltabs = new JTabbedPane(JTabbedPane.TOP);
		labeltabs.setBounds(20, 16, 439, 497);
		mainpanelbg.add(labeltabs);


		JPanel panelcreate = new JPanel();
		labeltabs.addTab("Create group", null, panelcreate, null);
		panelcreate.setLayout(null);

		JLabel lblgrname = new JLabel("Group Name:");
		lblgrname.setBounds(15, 27, 148, 27);
		panelcreate.add(lblgrname);
		lblgrname.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));

		textFieldname = new JTextField();
		textFieldname.setBounds(178, 27, 200, 27);
		textFieldname.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldname.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panelcreate.add(textFieldname);
		textFieldname.setColumns(10);




		JButton btnNewButton = new JButton("Apply");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(textFieldname.getText().equals(""))
					JOptionPane.showMessageDialog(null, "Please fill in a new group name", "Group name is empty", JOptionPane.ERROR_MESSAGE);
				else
					GroupController.CreateNewGroup(textFieldname.getText());
			}
		});
		btnNewButton.setBounds(232, 79, 89, 23);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		panelcreate.add(btnNewButton);

		paneledit = new JPanel();
		paneledit.setFont(new Font("Tahoma", Font.PLAIN, 20));
		labeltabs.addTab("Edit group", null, paneledit, null);
		paneledit.setLayout(null);

		JLabel lblGroupName = new JLabel("Group Name:");
		lblGroupName.setBounds(15, 27, 148, 27);
		lblGroupName.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		paneledit.add(lblGroupName);

		lblAddUser = new JLabel("Add Users:");
		lblAddUser.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		lblAddUser.setBounds(15, 104, 131, 21);


		lblRemoveUsers = new JLabel("Remove Users:");
		lblRemoveUsers.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		lblRemoveUsers.setBounds(15, 185, 160, 21);

		removeUsersButton = new JButton("Remove");
		removeUsersButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		removeUsersButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(comboBox_1.getItemCount()==0)
					JOptionPane.showMessageDialog(null, "There are no users to remove", "Group name is empty", JOptionPane.ERROR_MESSAGE);
				else	
					GroupController.RemoveUserFromGroup(comboBox_1.getSelectedItem().toString(), groupCombo.getSelectedItem().toString());
			}
		});

		comboBox_1 = new JComboBox();
		comboBox_1.setBounds(181, 187, 188, 20);


		addUsersButton = new JButton("Add");
		addUsersButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		addUsersButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(addUsersCombo.getItemCount()==0)
					JOptionPane.showMessageDialog(null, "There are no users to add", "Group name is empty", JOptionPane.ERROR_MESSAGE);
				else
					GroupController.AddUserToGroup(addUsersCombo.getSelectedItem().toString(), groupCombo.getSelectedItem().toString());
			}
		});


		groupCombo = new JComboBox();
		groupCombo.setBounds(173, 32, 214, 20);
		paneledit.add(groupCombo);
		GroupController.GetAllGroups();


		addUsersCombo = new JComboBox();
		addUsersCombo.setBounds(178, 106, 188, 20);


		JButton btnLoadUsers = new JButton("Load Users");
		btnLoadUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GroupController.GetUsersNotInGroup(groupCombo.getSelectedItem().toString());
				GroupController.GetUsersInGroup(groupCombo.getSelectedItem().toString());
			}
		});

		btnLoadUsers.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnLoadUsers.setBounds(207, 65, 148, 23);
		paneledit.add(btnLoadUsers);



		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 474, 590);
		mainpanelbg.add(labelbackground);
		labelbackground.setIcon(new ImageIcon(img));
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep=(Reply)r;

		if(rep.getResult() instanceof Result)
		{
			Result res=(Result)rep.getResult();
			if(res.equals(Result.GROUPEXISTS))
			{
			    	addGroupResult=false;
				//JOptionPane.showMessageDialog(null, "Group name allready exists.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else if(res.equals(Result.GROUPADDED))
			{
			    	addGroupResult=true;
				GroupController.GetAllGroups();
				//JOptionPane.showMessageDialog(null, "Group added successfully.", "Done",JOptionPane.PLAIN_MESSAGE);	
			}
			else if(res.equals(Result.USERADDEDTOGROUP))
			{
			    	addUserResult=true;
				//JOptionPane.showMessageDialog(null, "User added to group.", "Done",JOptionPane.PLAIN_MESSAGE);
				GroupController.GetUsersNotInGroup(groupCombo.getSelectedItem().toString());
				GroupController.GetUsersInGroup(groupCombo.getSelectedItem().toString());
			}
			else if(res.equals(Result.USERALLREADYINGROUP))
				JOptionPane.showMessageDialog(null, "User allready in group.", "Error",JOptionPane.ERROR_MESSAGE);
			else if(res.equals(Result.USERNOTINGROUP))
				JOptionPane.showMessageDialog(null, "User NOT in group.", "Error",JOptionPane.ERROR_MESSAGE);
			else if(res.equals(Result.USERREMOVEDFROMGROUP))
			{
				JOptionPane.showMessageDialog(null, "User removed from group.", "Done",JOptionPane.PLAIN_MESSAGE);
				GroupController.GetUsersNotInGroup(groupCombo.getSelectedItem().toString());
				GroupController.GetUsersInGroup(groupCombo.getSelectedItem().toString());
			}
		}
		else if(rep.getCommand().equals(Command.USERSINGROUP))
		{
			ArrayList<String> users=(ArrayList<String>)rep.getResult();
			Object[] str=users.toArray();
			paneledit.add(lblRemoveUsers);
			comboBox_1.removeAllItems();
			for(Object str1 : str) {
				comboBox_1.addItem(str1);
			}
			paneledit.add(comboBox_1);
			removeUsersButton.setBounds(232, 220, 100, 23);
			paneledit.add(removeUsersButton);
			paneledit.revalidate();
			paneledit.repaint();
		}
		else if(rep.getCommand().equals(Command.USERSNOTINGROUP))
		{
			ArrayList<String> users=(ArrayList<String>)rep.getResult();
			Object[] str=users.toArray();
			paneledit.add(lblAddUser);
			addUsersCombo.removeAllItems();
			for(Object str1 : str) {
				addUsersCombo.addItem(str1);
			}
			paneledit.add(addUsersCombo);
			addUsersButton.setBounds(232, 137, 100, 23);
			paneledit.add(addUsersButton);
			paneledit.revalidate();
			paneledit.repaint();
		}
		else if(rep.getCommand().equals(Command.ALLGROUPS))
		{
			ArrayList<String> groups=(ArrayList<String>)rep.getResult();
			Object[] str=groups.toArray();
			groupCombo.removeAllItems();
			for(Object str1 : str) {
				groupCombo.addItem(str1);
			}
			groupCombo.setBounds(173, 32, 214, 20);
			paneledit.add(groupCombo);

			paneledit.remove(addUsersCombo);
			paneledit.remove(lblAddUser);
			paneledit.remove(addUsersButton);
			paneledit.remove(comboBox_1);
			paneledit.remove(lblRemoveUsers);
			paneledit.remove(removeUsersButton);


			paneledit.revalidate();
			paneledit.repaint();
		}
		else if(rep.getCommand().equals(Command.NEWGROUP))
		{
		    if(rep.getResult() instanceof Result) {
			if(rep.getResult().equals(Result.ERROR))
			    addGroupResult=false;
		    }
		    else
			JOptionPane.showMessageDialog(null, "Group has added successfuly", "Done", JOptionPane.PLAIN_MESSAGE);
		}
		else if(rep.getCommand().equals(Command.SENDMESSAGE))
			JOptionPane.showMessageDialog(null, "Message has been sent to user", "Done", JOptionPane.PLAIN_MESSAGE);		
	}
}
