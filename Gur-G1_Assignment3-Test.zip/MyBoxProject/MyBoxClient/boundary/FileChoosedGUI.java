package boundary;

import java.awt.Desktop;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import client.ClientController;
import controller.CheckIfUserAuthorizedReadController;
import controller.FileController;
import controller.FileReceiveController;
import controller.MessageController;
import controller.ShowFileDetalisController;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class FileChoosedGUI designed for the user to choose bewtween several option he want to do with file.
 */
public class FileChoosedGUI extends AbstractGUI {

	/** The current user. */
	private String curUser;

	/** The frame. */
	private JFrame frame;

	/** The desktop. */
	private Desktop desktop;

	/** The is file owner. */
	private boolean isFileOwner;

	/** The folder id. */
	private int folderID;

	/** The button that represents this file. */
	private JButton b;

	/** The edit details gui. */
	private EditDetailsGUI editDetailsGUI;

	/** The loading gif. */
	private JLabel loadingGIF;

	/**
	 * Gets the b button.
	 *
	 * @return the b
	 */
	public JButton getB() {
		return b;
	}

	/**
	 * Instantiates a new file choosed gui.
	 *
	 * @param b the button that represents this file
	 * @param curUser the current user
	 * @param folder the folder
	 */
	public FileChoosedGUI(JButton b, String curUser, int folder) {

		this.curUser = curUser;
		folderID = folder;
		this.b = b;
		desktop = Desktop.getDesktop();

		initialize();
		this.initGUI(frame);

		FileController.checkFileExistence(b.getText(), curUser);
		FileController.isFileOwner(curUser, b.getText());
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 100, 273, 373);
		frame.getContentPane().setLayout(null);

		Image img = new ImageIcon(this.getClass().getResource(
				"images/wall12.jpg")).getImage();

		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});

		loadingGIF = new JLabel("");
		loadingGIF.setIcon(new ImageIcon(FileChoosedGUI.class
				.getResource("/boundary/images/ajax-loader.gif")));
		loadingGIF.setBounds(54, 90, 193, 171);
		frame.getContentPane().add(loadingGIF);
		buttonBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonBack.setBounds(63, 290, 130, 23);
		loadingGIF.setVisible(false);
		frame.getContentPane().add(buttonBack);

		JButton btnShow = new JButton("Show file details");
		btnShow.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnShow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowFileDetalisController.getFileDetails(b.getText());
			}
		});
		btnShow.setBounds(24, 217, 207, 35);
		frame.getContentPane().add(btnShow);
		Image imgshowdetails = new ImageIcon(this.getClass().getResource(
				"images/newshowdetails.png")).getImage();
		btnShow.setIcon(new ImageIcon(imgshowdetails));

		JButton btnRead = new JButton("Read file");
		btnRead.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadingGIF.setVisible(true);
				CheckIfUserAuthorizedReadController.sentReq(curUser,
						b.getText(), "read");
				// FileReceiveController.recieveFileFromServer(curUser,
				// b.getText());
			}
		});
		Image imgread = new ImageIcon(this.getClass().getResource(
				"images/newreadfile2.png")).getImage();
		btnRead.setIcon(new ImageIcon(imgread));
		btnRead.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnRead.setBounds(24, 13, 207, 35);
		frame.getContentPane().add(btnRead);

		JButton btnEditPermissions = new JButton("Edit Permissions");
		btnEditPermissions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (isFileOwner) {
					hide();
					FilePermissionForUserGUI filePermissionForUserGUI = new FilePermissionForUserGUI(
							b.getText(), curUser);
				} else
					JOptionPane.showMessageDialog(null,
							"You are not the file owner!");
			}
		});
		btnEditPermissions.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnEditPermissions.setBounds(24, 166, 207, 35);
		frame.getContentPane().add(btnEditPermissions);
		Image imgpermissions = new ImageIcon(this.getClass().getResource(
				"images/neweditpermissions.png")).getImage();
		btnEditPermissions.setIcon(new ImageIcon(imgpermissions));

		JButton btnDelete = new JButton("Delete File");
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(frame,"Are you sure you want to delete file?", "Confirm",JOptionPane.YES_NO_OPTION) == 0) {
					String fileName = b.getText();
					if (isFileOwner) {
						if (JOptionPane.showConfirmDialog(frame,"Do you want to delete the file permenantly?","Confirm", JOptionPane.YES_NO_OPTION) == 0) 
						{
							MessageController.SendMessageToUsersRelvantForFile(fileName,"File '"+ fileName+ "' has been delete by his owner permenantly.");
							FileController.deleteFilePermenantly(fileName);
						} else {
							FileController.deleteFileFromFolder(fileName,folderID);
							FileController.changeFileStatus(fileName, 0);
						}
					} else {
						FileController.deleteFileFromFolder(fileName, folderID);
					}
				}
			}
		});

		btnDelete.setBounds(24, 64, 207, 35);
		frame.getContentPane().add(btnDelete);
		Image imgdelete = new ImageIcon(this.getClass().getResource(
				"images/newdeletefile.png")).getImage();
		btnDelete.setIcon(new ImageIcon(imgdelete));

		JButton btnEditDetails = new JButton("Edit File Details");
		btnEditDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (isFileOwner == true)
					editDetailsGUI = new EditDetailsGUI(curUser, b);
				else
					JOptionPane
					.showMessageDialog(null,
							"You are not the file owner, you can not change file details.");
				// FileController.isFileOwner(curUser, b.getText());
			}
		});
		btnEditDetails.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnEditDetails.setBounds(24, 115, 207, 35);
		frame.getContentPane().add(btnEditDetails);
		Image imgeditdetails = new ImageIcon(this.getClass().getResource(
				"images/neweditdetails.png")).getImage();
		btnEditDetails.setIcon(new ImageIcon(imgeditdetails));

		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(-140, -39, 456, 447);
		frame.getContentPane().add(labelbackground);
		labelbackground.setIcon(new ImageIcon(img));

		// frame.setVisible(true);
	}

	// ********************************************************* GETREPLY***************************

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void getReply(Object r) {

		Reply rep = (Reply) r;
		if (rep.getResult() instanceof entity.File) {
			loadingGIF.setVisible(false);
		}
		if (rep.getCommand().equals(Command.SHOW_FILE_DETAILS)) {
			ArrayList<String> dt = (ArrayList<String>) rep.getResult();
			String str = "File name: " + dt.get(0) + ".\n" + "Description: "
					+ dt.get(1) + ".\n" + "Permission: " + dt.get(2) + ".\n"
					+ "File owner: " + dt.get(3) + ".\n";

			JOptionPane.showMessageDialog(null, str);

		} else if (rep.getCommand().equals(Command.CHECK_FILE_OWNER)) {
			if ((boolean) rep.getResult()) {
				isFileOwner = true;
				// EditDetailsGUI editDetailsGUI = new EditDetailsGUI(curUser,
				// b);
			} else {
				isFileOwner = false;
				// JOptionPane.showMessageDialog(null,"You are not the file owner, you can not change file details.");
			}
		} else if (rep.getCommand().equals(Command.SEND_FILE_TO_CLIENT)) {
			MainWorkSpaceGUI main = (MainWorkSpaceGUI) ClientController
					.getGUIFlow().get(ClientController.getGUIFlow().size() - 2);
			FileReceiveController.recieveReplyFileFromServer(rep, desktop,
					main.getRootPath());
		} else if (rep.getCommand().equals(Command.DELETEFILEFROMFOLDER)) {
			if (rep.getResult().equals(Result.OK)) {
				MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(index - 1);
				gui.removeButton(b);
				JOptionPane.showMessageDialog(frame, "File  has been deleted from your workspace.");
				goBack();
			}
		} else if (rep.getCommand().equals(Command.CHECK_FILE_EXISTENCE)) {
			if (rep.getResult().equals(false)) {
				JOptionPane.showMessageDialog(frame,"This file no longer exists.");
				goBack();
			}
		}

		else if (rep.getCommand().equals(Command.DELETEFILEPERMENANTLY)) {
			if (rep.getResult().equals(Result.OK)) {
				MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController
						.getGUIFlow().get(index - 1);
				gui.removeButton(b);
				JOptionPane.showMessageDialog(frame,
						"File  has been deleted permenantly.");
				goBack();
			}
		} else if (rep.getCommand().equals(Command.CHECK_READ_AUTHORIZATION)) {

			if (rep.getResult().equals(Result.READ_APPROVE)) {
				FileReceiveController.recieveFileFromServer(curUser,
						b.getText());

			} else if (rep.getResult().equals(Result.READ_NOT_APPROVE)) {
				JOptionPane.showMessageDialog(frame,
						"You do not have read permission for this file.");
				goBack();
			}
		}

	}
}
