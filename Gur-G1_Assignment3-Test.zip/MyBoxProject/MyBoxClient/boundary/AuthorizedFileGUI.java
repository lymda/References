package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import client.ClientController;
import controller.AuthorizedFileController;
import entity.File;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class AuthorizedFileGUI designed for the user to see and add his authorized files to his private workspace.
 */
public class AuthorizedFileGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The current user. */
	private String curUser;

	/** The main panel for this window. */
	private JPanel mainpanelbg;

	/** The scroll pane. */
	private JScrollPane scrollPane;

	/** The table. */
	private JTable table;

	/** The data of files for this user. */
	private Object data[][];

	/** The localfilename for add to workspace. */
	private String localfilename;


	/**
	 * Instantiates a new authorized file gui.
	 *
	 * @param un the user name
	 */
	public AuthorizedFileGUI(String un) {

		initialize(un);
		this.initGUI(frame);
		AuthorizedFileController.GetFiles(curUser);
	}

	/**
	 * Initialize.
	 *
	 * @param un the user name
	 */
	public void initialize (String un){

		curUser = un;
		frame = new JFrame();
		frame.setTitle("MyBox - Authorized Files");
		frame.setBounds(100, 20, 956, 521);
		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);

		mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);

		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 1139, 481);
		//		labelbg.setIcon(new ImageIcon(img));
		mainpanelbg.add(labelbackground);

		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});
		buttonBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonBack.setBounds(840, 443, 89, 23);
		mainpanelbg.add(buttonBack);

		JLabel lblChooseFiles = new JLabel("Choose files to add to your private WorkSpace:");
		lblChooseFiles.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 14));
		lblChooseFiles.setBounds(20, 18, 423, 43);
		mainpanelbg.add(lblChooseFiles);

		JButton btnAddFilesTo = new JButton("Add files to workspace");
		btnAddFilesTo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int row = table.getSelectedRow();
				if (row == -1) JOptionPane.showMessageDialog(null, "No row is selected. Choose file to add or exit.");
				else if (JOptionPane.showConfirmDialog(null, "Are you sure you want to add this file to your WorkSpace?","Confirm", JOptionPane.YES_NO_OPTION) == 0)
				{
					localfilename = table.getModel().getValueAt(row, 1).toString(); // get file name
					String fileid = table.getModel().getValueAt(row, 0).toString(); // get file id
					controller.AddToWSfromAuthorizedController.AddFile(curUser, Integer.parseInt(fileid));// add to DB
				}
			}
		});
		btnAddFilesTo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddFilesTo.setBounds(15, 443, 255, 23);
		mainpanelbg.add(btnAddFilesTo);



	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {

		Reply rep = (Reply) r;

		if (rep.getCommand().equals(Command.GETAUTHORIZEDFILES))
		{

			String[] columnNames = {"File ID", "File Name", "Description", "File permission", "File Owner"};
			ArrayList<File> filesdata = (ArrayList<File>) rep.getResult();
			data = new Object[filesdata.size()][5];

			for(int i=0; i<filesdata.size(); i++)
			{
				data[i][0]=Integer.toString(filesdata.get(i).getFileID());
				data[i][1]=filesdata.get(i).getFileName();
				data[i][2]=filesdata.get(i).getDescription();
				data[i][3]=filesdata.get(i).getPermissionRate();
				data[i][4]=filesdata.get(i).getFileOwner();

			}

			table = new JTable(data, columnNames);
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.getTableHeader().setReorderingAllowed(false);
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			table.setFont(new Font("Tahoma", Font.PLAIN, 18));


			table.getColumnModel().getColumn(0).setPreferredWidth(80);
			table.getColumnModel().getColumn(1).setPreferredWidth(220);
			table.getColumnModel().getColumn(2).setPreferredWidth(300);
			table.getColumnModel().getColumn(3).setPreferredWidth(150);
			table.getColumnModel().getColumn(4).setPreferredWidth(150);


			scrollPane = new JScrollPane(table,
					JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
					JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setViewportBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			scrollPane.setFont(new Font("Tahoma", Font.PLAIN, 18));
			scrollPane.setBounds(20, 61, 900, 366);
			mainpanelbg.add(scrollPane);

		}
		else if (rep.getCommand().equals(Command.ADDFROMAUTHORIZED))
		{
			Result res = (Result) rep.getResult();

			if (res == Result.FILEWITHTHESAMENAME)
			{
				JOptionPane.showMessageDialog(null, "You already have file with the same name in your Main WorkSpace.");
				goBack();

			}
			else if (res == Result.FILEHASBEENADDEDTOMAINWS)
			{
				Image fileimg = new ImageIcon(this.getClass().getResource("images/file.png")).getImage();
				MainWorkSpaceGUI mg = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(ClientController.getGUIFlow().size()-2);
				mg.addFileButton(localfilename, fileimg);		// add file to private ws - GUI
				goBack();
			}

		}
	}
}