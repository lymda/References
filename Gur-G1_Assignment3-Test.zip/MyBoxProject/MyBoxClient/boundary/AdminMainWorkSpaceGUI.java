package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import controller.LogoutController;
import entity.Reply;
import enums.Result;

/**
 * The Class AdminMainWorkSpaceGUI consists all relevant buttons to manage myBox system for the Admin.
 */
public class AdminMainWorkSpaceGUI extends AbstractGUI{

	/** The frame. */
	private JFrame frame;

	/** The currnet user. */
	public String curUser;

	/**
	 * Instantiates a new admin main work space gui.
	 *
	 * @param un the user name as Admin.
	 */
	public AdminMainWorkSpaceGUI(String un) {

		curUser = un;
		initialize();
		this.initGUI(frame);
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 20, 1124, 700);
		frame.getContentPane().setLayout(null);
		frame.setTitle("MyBox - Admin WorkSpace");

		Image imgic = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(imgic);

		//Image imglogo = new ImageIcon(this.getClass().getResource("images/loginlogo.jpg")).getImage();
		//labellogo.setIcon(new ImageIcon(imglogo));

		JLabel labellogo = new JLabel("");
		labellogo.setIcon(new ImageIcon(AdminMainWorkSpaceGUI.class.getResource("/boundary/images/loginlogo.png")));
		labellogo.setBounds(46, 45, 160, 155);
		frame.getContentPane().add(labellogo);

		JButton btnRequests = new JButton("Requests");							//	btnRequests
		btnRequests.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				hide();
				RequestsGUI RequestsGUI = new RequestsGUI();
			}
		});

		btnRequests.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnRequests.setBounds(40, 350, 325, 75);
		frame.getContentPane().add(btnRequests);
		Image imggrb = new ImageIcon(this.getClass().getResource("images/groupblue - 26.png")).getImage();
		btnRequests.setIcon(new ImageIcon(imggrb));

		JButton btnFilesInGroup = new JButton("Files In Group Permission");
		btnFilesInGroup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				ChangeFileInGroupGUI fileInGroup=new ChangeFileInGroupGUI();
			}
		});

		btnFilesInGroup.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnFilesInGroup.setBounds(40, 450, 325, 75);
		frame.getContentPane().add(btnFilesInGroup);
		Image imgfilepermission = new ImageIcon(this.getClass().getResource("images/permissions icon - 26.png")).getImage();
		btnFilesInGroup.setIcon(new ImageIcon(imgfilepermission));

		JButton btnManageGroups = new JButton("Manage Groups");						//	btnManageGroups
		btnManageGroups.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hide();
				ManageGroupsGUI GroupsGUI = new ManageGroupsGUI();
			}
		});
		btnManageGroups.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnManageGroups.setBounds(40, 259, 325, 75);
		frame.getContentPane().add(btnManageGroups);
		Image imggrg = new ImageIcon(this.getClass().getResource("images/groupgreen - 26.png")).getImage();
		btnManageGroups.setIcon(new ImageIcon(imggrg));


		JButton buttonexit = new JButton("Logout");								//	buttonexit
		buttonexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(frame, "Are you sure you want to Logout?","Confirm", JOptionPane.YES_NO_OPTION) == 0)

					//					LogoutController.LogoutTest(ClientController.getCurrentUser().getUserName());
					LogoutController.LogoutTest(curUser);
			}
		});
		buttonexit.setFont(new Font("Tahoma", Font.PLAIN, 22));
		buttonexit.setBounds(943, 594, 160, 50);
		frame.getContentPane().add(buttonexit);
		Image imgout = new ImageIcon(this.getClass().getResource("images/logout - 26.png")).getImage();
		buttonexit.setIcon(new ImageIcon(imgout));

		JLabel labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 1119, 686);
		frame.getContentPane().add(labelbackground);
		Image img = new ImageIcon(this.getClass().getResource("images/wall1118.jpg")).getImage();
		labelbackground.setIcon(new ImageIcon(img));
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep = (Reply) r;
		Result res = (Result) rep.getResult();

		if (res == Result.LOGGEDOUT)
		{
			JOptionPane.showMessageDialog(null, "Logged Out.");
			goBack();
		}

	}
}
