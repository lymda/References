package boundary;

import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.ScrollPaneConstants;

import controller.FileController;
import controller.MessageController;
import entity.Reply;
import enums.Command;

/**
 * The Class RecycleBinGUI designed for the user to delete permanently files from the system.
 */
public class RecycleBinGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The list of deletet files. */
	private JList listdeletetfiles;

	/** The scroll pane. */
	private JScrollPane scrollPane;

	/** The cur user. */
	private String curUser;

	/**
	 * Instantiates a new recycle bin gui.
	 *
	 * @param curUser the current user
	 */
	public RecycleBinGUI(String curUser) {

		this.curUser=curUser;
		initialize();
		this.initGUI(frame);		
	}

	/**
	 * Initialize.
	 */
	private void initialize(){

		frame=new JFrame();
		frame.setTitle("MyBox - Trash");
		frame.setBounds(100, 20, 468, 338);
		JPanel bg = new JPanel();
		frame.setContentPane(bg);

		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);

		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();
		bg.setLayout(null);


		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBack.setBounds(358, 259, 89, 23);
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				goBack();
			}
		});
		bg.add(btnBack);

		JLabel lblChooseFiles = new JLabel("Choose Files to Delete:");
		lblChooseFiles.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
		lblChooseFiles.setBounds(20, 16, 300, 27);
		bg.add(lblChooseFiles);

		JButton btnAddFilesTo = new JButton("Delete Permenantly");
		btnAddFilesTo.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String toDel=null;
				toDel=(String)listdeletetfiles.getSelectedValue();
				if ((toDel != null) && (toDel.length() > 0)){
					if (JOptionPane.showConfirmDialog(frame,"Are you sure you want to delete file '"+toDel+"' permanantly?", "Confirm",JOptionPane.YES_NO_OPTION) == 0) 
					{
						MessageController.SendMessageToUsersRelvantForFile(toDel, "File '"+toDel+"' has been deleted by his owner permenantly");
						FileController.deleteFilePermenantly(toDel);
					}
				}
			}
		});
		btnAddFilesTo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddFilesTo.setBounds(30, 259, 191, 23);
		bg.add(btnAddFilesTo);

		scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(20, 48, 300, 182);
		bg.add(scrollPane);


		JLabel labelbg = new JLabel("");
		labelbg.setBounds(0, 0, 462, 331);
		bg.add(labelbg);
		labelbg.setIcon(new ImageIcon(img));
		FileController.getDeletedFiledForUser(curUser);
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		// TODO Auto-generated method stub
		Reply rep=(Reply)r;
		if(rep.getCommand().equals(Command.GETDELETEDFILESOFUSERS))
		{
			ArrayList<String> files=(ArrayList<String>)rep.getResult();
			listdeletetfiles = new JList(files.toArray());
			listdeletetfiles.setFont(new Font("Tahoma", Font.PLAIN, 18));
			scrollPane.setViewportView(listdeletetfiles);
			frame.revalidate();
			frame.repaint();
		}
		else if(rep.getCommand().equals(Command.DELETEFILEPERMENANTLY))
		{
			JOptionPane.showMessageDialog(null, "File has been deleted permenantly and messages sent to relevant users.");
			goBack();
		}

	}
}
