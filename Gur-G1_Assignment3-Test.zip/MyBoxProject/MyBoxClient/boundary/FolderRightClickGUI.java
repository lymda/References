package boundary;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import client.ClientController;
import controller.ChangeFolderNameController;
import controller.DeleteFolderController;
import entity.Folder;
import entity.Reply;
import enums.Result;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

/**
 * The Class FolderRightClickGUI designed for the user to delete or change name for folder.
 */
public class FolderRightClickGUI extends AbstractGUI{

	/** The frame. */
	private JFrame frame;
	
	/** The folder. */
	private Folder folder;
	
	/** The button. */
	private JButton button;
	
	/** The new name. */
	private String newName;

	/**
	 * Instantiates a new folder right click gui.
	 *
	 * @param f the f
	 * @param b the b
	 */
	public FolderRightClickGUI(Folder f, JButton b) {
		this.folder=f;
		this.button=b;
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 268, 194);
		frame.getContentPane().setLayout(null);
		
		JButton btnChangeName = new JButton("Change name");
		btnChangeName.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnChangeName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				newName = JOptionPane.showInputDialog(frame, "Enter a folder name");
				if ((newName != null) && (newName.length() > 0)) 
					ChangeFolderNameController.sentReq(folder,newName);
				
				
			}
		});
		btnChangeName.setBounds(30, 61, 191, 35);
		frame.getContentPane().add(btnChangeName);
		Image imgchangename = new ImageIcon(this.getClass().getResource("images/newrenamefolder.png")).getImage();
		btnChangeName.setIcon(new ImageIcon(imgchangename));
		
		JButton btnDeleteFolder = new JButton("Delete folder");
		btnDeleteFolder.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDeleteFolder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(frame,"Are you sure you want to delete folder?", "Confirm",
						JOptionPane.YES_NO_OPTION) == 0) {
					DeleteFolderController.sentReq(folder);
				}
			}
		});
		btnDeleteFolder.setBounds(30, 13, 191, 35);
		frame.getContentPane().add(btnDeleteFolder);
		Image imgdeletefolder = new ImageIcon(this.getClass().getResource("images/newdeletefolder.png")).getImage();
		btnDeleteFolder.setIcon(new ImageIcon(imgdeletefolder));
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(ClientController.getGUIFlow().size()-2);
				gui.getFrame(frame).setEnabled(true);
				goBack();
			}
		});
		btnNewButton.setBounds(93, 111, 77, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel background = new JLabel("");
		background.setIcon(new ImageIcon(FolderRightClickGUI.class.getResource("/boundary/images/server UI.jpg")));
		background.setBounds(0, 0, 304, 187);
		frame.getContentPane().add(background);
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep = (Reply) r;

		if (rep.getResult() instanceof Result)
		{
			Result res = (Result) rep.getResult();
			if (res == Result.FOLDERNAMEEXIST)
			{
				JOptionPane.showMessageDialog(null, "Folder name already exist!");
			}
			
			else if (res == Result.FOLDERNAMECHANGED)
			{
				button.setText(newName);
				JOptionPane.showMessageDialog(null, "Folder name is changed!");
			}
			else if (res == Result.FOLDERISFULL)
			{
				JOptionPane.showMessageDialog(null, "Can't delete folder. folder is not empty!");
			}
			else if (res == Result.FOLDERDELETED)
			{
				MainWorkSpaceGUI mws = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(ClientController.getGUIFlow().size()-2);
				mws.removeButton(button);
				JOptionPane.showMessageDialog(null, "Folder deleted!");
				
			}
			MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(ClientController.getGUIFlow().size()-2);
			gui.getFrame(frame).setEnabled(true);
			goBack();
		}
	}
}
