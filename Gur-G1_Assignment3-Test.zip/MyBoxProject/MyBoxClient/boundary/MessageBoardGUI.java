package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import controller.MessageController;
import entity.Message;
import entity.Reply;
import enums.Command;

/**
 * The Class MessageBoardGUI designed for the user to see massages from the system about relevant operations.
 */
public class MessageBoardGUI extends AbstractGUI {

	/** The frm mybox messages. */
	private JFrame frmMyboxMessages;

	/** The table_2. */
	private JTable table_2;

	/** The data. */
	private Object data[][];

	/** The scroll pane. */
	private JScrollPane scrollPane;

	/** The bg. */
	private JPanel mainpanelbg;

	/** The labelbg. */
	private JLabel labelbackground;

	/** The cur user. */
	private String curUser;

	/**
	 * Instantiates a new message board gui.
	 *
	 * @param user the user
	 */
	public MessageBoardGUI(String user) {
		initialize(user);

		this.initGUI(frmMyboxMessages);
	}

	/**
	 * Initialize.
	 *
	 * @param user the user
	 */
	private void initialize(String user){
		this.curUser=user;
		frmMyboxMessages=new JFrame();
		frmMyboxMessages.setTitle("MyBox - Messages");
		frmMyboxMessages.setBounds(100, 20, 740, 488);
		frmMyboxMessages.setResizable(false);
		mainpanelbg = new JPanel();
		frmMyboxMessages.setContentPane(mainpanelbg);

		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frmMyboxMessages.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource("images/wall12.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});
		buttonBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonBack.setBounds(630, 422, 89, 23);
		mainpanelbg.add(buttonBack);

		MessageController.GetAllMessagesForUser(curUser);

		JButton btnDeleteAllMesages = new JButton("Delete All Mesages");
		btnDeleteAllMesages.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (JOptionPane.showConfirmDialog(null, "Are you sure you want to delete all your messages?","Confirm", JOptionPane.YES_NO_OPTION) == 0)
					MessageController.deleteMessagesForUser(curUser);
			}
		});
		btnDeleteAllMesages.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDeleteAllMesages.setBounds(15, 422, 200, 23);
		mainpanelbg.add(btnDeleteAllMesages);

		JLabel lblPendingRequests = new JLabel("Message Board");
		lblPendingRequests.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblPendingRequests.setBounds(290, 11, 173, 35);
		mainpanelbg.add(lblPendingRequests);

		labelbackground = new JLabel("");
		labelbackground.setBounds(0, 0, 734, 488);
		mainpanelbg.add(labelbackground);
		//labelbg.setIcon(new ImageIcon(img));

	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep=(Reply)r;
		if(rep.getCommand().equals(Command.GETMESSAGESFORUSER))
		{
			String columns[]={"Message"};
			ArrayList<Message> messages_arryList=(ArrayList<Message>)rep.getResult();
			data=new Object[messages_arryList.size()][1];
			for(int i=0;i<messages_arryList.size();i++)
				data[i][0]=messages_arryList.get(i).getMessage();
			table_2 = new JTable(data,columns);
			table_2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table_2.getTableHeader().setReorderingAllowed(false);
			scrollPane = new JScrollPane(table_2,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			table_2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			table_2.getColumnModel().getColumn(0).setPreferredWidth(710);
			table_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
			scrollPane.setViewportBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			scrollPane.setBounds(10, 57, 720, 354);
			mainpanelbg.add(scrollPane);
		}
		if(rep.getCommand().equals(Command.DELETE_MESSAGES_FOR_USER))
		{
			MessageController.GetAllMessagesForUser(curUser);
			JOptionPane.showMessageDialog(null, "All mesages has been deleted.");
			goBack();
		}
	}
}
