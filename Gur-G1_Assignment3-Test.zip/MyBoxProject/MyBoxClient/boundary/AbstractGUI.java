package boundary;

import javax.swing.JFrame;

import client.ClientController;

/**
 * General GUI for all GUIs in project. All GUIs that extends this class must
 * implement getReply() method and may override other methods if needed. made
 * for easy navigation between GUIs and for easy handling with messages from
 * server. Defining general-most common properties for GUIs in the project.
 */
public abstract class AbstractGUI {
	/**
	 * Child's frame. initiate by calling super() constructor from child's
	 * constructor.
	 */
	protected JFrame frame;
	/**
	 * GUI's index in the GUIs' array.
	 */
	protected int index;

	/**
	 * Abstract method for easy handling with messages from server. ALL GUIs
	 * must implement this method in order to get messages from server.
	 *
	 * @param r the reply that every gui get from the server
	 */
	public abstract void getReply(Object r);

	/**
	 * Defining general-most common properties for GUIs in the project.
	 *
	 * @param f the f
	 */
	protected void initGUI(JFrame f) {
		frame = f;
		index = ClientController.getGUIFlow().size();
		ClientController.getGUIFlow().add(this);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setResizable(false);
		frame.setVisible(true);

	}

	/**
	 * Returning child's frame.
	 * 
	 * @param f the frame
	 * @return the frame
	 * 
	 */
	public JFrame getFrame(JFrame f) {
		return frame;
	}

	/**
	 * Returning GUI's index - current place in the gui's array.
	 *
	 * @return the index
	 */
	public int getIndex() {
		return index;

	}

	/**
	 * Disposing current frame and GUI and returning visibility of previous
	 * GUI's frame.
	 */
	public void goBack() {
		AbstractGUI gui = null;
		if (index != 0) {
			gui = ClientController.getGUIFlow().get(index - 1);
			gui.show();
		}
		ClientController.getGUIFlow().remove(index);
		frame.dispose();
	}

	/**
	 * Enable visibility of child's frame.
	 */
	public void show() {

		frame.setVisible(true);
	}

	/**
	 * Hide frame.
	 */
	public void hide() {

		frame.setVisible(false);
	}
}
