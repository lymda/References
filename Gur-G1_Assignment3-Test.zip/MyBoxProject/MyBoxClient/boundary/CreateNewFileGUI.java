package boundary;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import client.ClientController;
import controller.CreateNewFileController;
import controller.FileController;
import entity.File;
import entity.Reply;
import enums.Command;
import enums.Result;

/**
 * The Class CreateNewFileGUI designed for the user to create new file with the fields: name, permission, description.
 */
public class CreateNewFileGUI extends AbstractGUI {

    /** The current user. */
    public String curUser;

    /** The file path. */
    private String filePath = "";

    /** The frame. */
    private JFrame frame;

    /** The btn ok. */
    private JButton btnOk;

    /** The text field filename. */
    private JTextField textFieldFilename;

    /** Flags to check and accpet user's choices in this screen. */
    private int nameFlag = 0, discriptionFlag = 0, nameok = 0, desok = 0;

    /** The btn choosebrowse. */
    JButton btnChoosebrowse;

    /** The combo box file permission. */
    JComboBox comboBoxFilePermission;

    /** The groupsin. */
    private ArrayList<String> groupsin;

    /** The groupsflag. */
    private int groupsflag = 0;

    /** The permissionlist. */
    private ArrayList<String> permissionlist = new ArrayList<String>();
    private JLabel loadGIF;
    /**
     * Instantiates a new creates the new file gui.
     *
     * @param un the user name
     */
    public CreateNewFileGUI(String un) {
	curUser = un;
	permissionlist.add(0, "public");
	initialize();
	this.initGUI(frame);
    }

    /**
     * Initialize this class.
     */
    public void initialize() {

	Image imgfile1 = new ImageIcon(this.getClass().getResource(
		"images/folder.png")).getImage();
	frame = new JFrame();
	frame.setTitle("MyBox - Create New File");
	frame.setBounds(100, 20, 445, 600);

	JPanel mainpanelbg = new JPanel();
	frame.setContentPane(mainpanelbg);

	Image img0 = new ImageIcon(this.getClass().getResource(
		"images/icon.jpg")).getImage();
	frame.setIconImage(img0);
	Image img = new ImageIcon(this.getClass().getResource(
		"images/wall1118.jpg")).getImage();
	mainpanelbg.setLayout(null);

	Image img1 = new ImageIcon(this.getClass().getResource(
		"images/ok - 13.png")).getImage();

	JLabel lblFileLocation = new JLabel("Choose File:");
	lblFileLocation.setBounds(10, 16, 201, 37);
	lblFileLocation.setFont(new Font("Copperplate Gothic Light", Font.BOLD,
		18));
	mainpanelbg.add(lblFileLocation);

	JLabel lblFileName = new JLabel("File Name:");
	lblFileName.setBounds(10, 62, 201, 31);
	lblFileName
	.setFont(new Font("Copperplate Gothic Light", Font.BOLD, 18));
	mainpanelbg.add(lblFileName);
	textFieldFilename = new JTextField();
	textFieldFilename.setBounds(150, 62, 247, 29);
	textFieldFilename.setBorder(new BevelBorder(BevelBorder.LOWERED, null,
		null, null, null));
	textFieldFilename.setFont(new Font("Tahoma", Font.PLAIN, 18));
	textFieldFilename.setEditable(false);
	mainpanelbg.add(textFieldFilename);

	btnChoosebrowse = new JButton("Browse");
	btnChoosebrowse.setBounds(212, 23, 117, 23);
	btnChoosebrowse.setFont(new Font("Tahoma", Font.BOLD, 16));

	btnChoosebrowse.addActionListener(new ActionListener() {

	    public void actionPerformed(ActionEvent arg0) {

		JButton open = new JButton();
		JFileChooser fc = new JFileChooser();

		if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
		    textFieldFilename.setEditable(true);
		    filePath = fc.getSelectedFile().toString();
		    ArrayList<String> path = new ArrayList<String>(Arrays
			    .asList(filePath.split("\\\\")));
		    String fileName = path.get(path.size() - 1);
		    textFieldFilename.setText(fileName);
		}
	    }
	});
	mainpanelbg.add(btnChoosebrowse);

	JButton btncheck = new JButton("Check file name");
	btncheck.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		if (textFieldFilename.getText().compareTo("") == 0) {
		    JOptionPane.showMessageDialog(null,
			    "You did not inserted name, please insert one.");
		} else
		    FileController.checkFileExistence(
			    textFieldFilename.getText(), curUser);
	    }
	});
	btncheck.setBounds(255, 104, 141, 23);
	mainpanelbg.add(btncheck);
	btncheck.setIcon(new ImageIcon(img1));

	JLabel lblPermission = new JLabel("Permission:");
	lblPermission.setBounds(12, 140, 201, 31);
	lblPermission.setFont(new Font("Copperplate Gothic Light", Font.BOLD,
		18));
	mainpanelbg.add(lblPermission);

	comboBoxFilePermission = new JComboBox();
	comboBoxFilePermission.setFont(new Font("Tahoma", Font.PLAIN, 18));
	comboBoxFilePermission.setBounds(214, 140, 184, 31);
	comboBoxFilePermission.addItem("Public");
	comboBoxFilePermission.addItem("Private");
	comboBoxFilePermission.addItem("Group");
	comboBoxFilePermission.setEnabled(false);

	comboBoxFilePermission.addActionListener(new ActionListener() {

	    public void actionPerformed(ActionEvent arg0) {

		if (comboBoxFilePermission.getSelectedItem() == "Public") {
		    permissionlist.set(0, "public");
		} else if (comboBoxFilePermission.getSelectedItem() == "Private") {
		    permissionlist.set(0, "private");
		} else if (comboBoxFilePermission.getSelectedItem() == "Group") {
		    permissionlist.set(0, "group");
		    if (groupsflag == 0) {
			FileController.getGroupsUserIsIn(curUser);
			groupsflag = 1;
		    }
		}
	    }
	});
	mainpanelbg.add(comboBoxFilePermission);

	JLabel lblFileDescription = new JLabel("File Description:");
	lblFileDescription.setBounds(12, 187, 201, 37);
	lblFileDescription.setFont(new Font("Copperplate Gothic Light",
		Font.BOLD, 18));
	mainpanelbg.add(lblFileDescription);

	JTextArea textAreaFileDescription = new JTextArea();
	textAreaFileDescription.setBounds(201, 191, 196, 272);
	textAreaFileDescription.setBorder(new BevelBorder(BevelBorder.LOWERED,
		null, null, null, null));
	textAreaFileDescription.setFont(new Font("Tahoma", Font.PLAIN, 18));
	textAreaFileDescription.setLineWrap(true);
	mainpanelbg.add(textAreaFileDescription);

	JButton btncheck2 = new JButton("Check file discription");
	btncheck2.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent arg0) { // CHECK LESS THAN
		// 30 WORDS IN
		// DESCRIPTION

		String s = new String(textAreaFileDescription.getText());
		String[] tokens = textAreaFileDescription.getText().split(
			"\\s+");

		if (tokens.length > 30) {
		    JOptionPane
		    .showMessageDialog(null,
			    "File Description must be less than 30 characters.");
		    textAreaFileDescription.setText("");
		} else {
		    JOptionPane.showMessageDialog(null,
			    "File Description is OK.");
		    desok = 1;
		    textAreaFileDescription.setEditable(false);
		    if (nameok == 1)
			btnOk.setEnabled(true);
		}
	    }
	});
	btncheck2.setBounds(223, 476, 173, 23);
	mainpanelbg.add(btncheck2);
	btncheck2.setIcon(new ImageIcon(img1));

	JButton btnCancel = new JButton("Cancel");
	btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnCancel.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		goBack();
	    }

	});
	btnCancel.setBounds(304, 517, 89, 23);
	mainpanelbg.add(btnCancel);

	btnOk = new JButton("OK");
	btnOk.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnOk.setEnabled(false);

	btnOk.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent arg0) {

		MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController
			.getGUIFlow().get(
				ClientController.getGUIFlow().size() - 2);
		ArrayList<Integer> arr = gui.getFolderPath();
		int folderID = arr.get(arr.size() - 1);
		System.out.println(arr.size());

		File file = new File(curUser, filePath, textFieldFilename
			.getText(), textAreaFileDescription.getText(),
			permissionlist, folderID);
		CreateNewFileController.sentReq(file);
		goBack();
		// for (int i=0; i< groupsin.size(); i++)
		// {
		// FileController.changeFilePermissionForGroup(textFieldFilename.getText(),
		// groupsin.get(i), "read");
		// }

	    }
	});
	btnOk.setBounds(200, 517, 89, 23);
	mainpanelbg.add(btnOk);


	JLabel labelbackground = new JLabel("");
	labelbackground.setBounds(-442, -97, 930, 672);
	mainpanelbg.add(labelbackground);
	labelbackground.setIcon(new ImageIcon(img));
    }

    /**
     * Gets the text field.
     *
     * @return the text field
     */
    public JTextField getTextField() {
	return textFieldFilename;
    }

    /**
     * 
     * @see boundary.AbstractGUI#getReply(java.lang.Object)
     */
    @Override
    public void getReply(Object r) {

	Reply rep = (Reply) r;

	if (rep.getCommand().equals(Command.CHECK_FILE_EXISTENCE)) {
	    if ((boolean) rep.getResult()) {
		JOptionPane
		.showMessageDialog(null,
			"File name allready exist, please choose diffrent one.");
	    } else if (!(boolean) rep.getResult()) {
		textFieldFilename.setEditable(false);

		if (++nameFlag == 1) {
		    nameok = 1;
		    comboBoxFilePermission.setEnabled(true);
		    btnChoosebrowse.setEnabled(false);
		    if (desok == 1)
			btnOk.setEnabled(true);
		}
		JOptionPane.showMessageDialog(null, "File name ok.");
	    }
	} else if (rep.getCommand().equals(Command.LOADGROUPSUSERIN)) {
	    ArrayList<String> groupsin2 = (ArrayList<String>) rep.getResult();
	    groupsin = (ArrayList<String>) rep.getResult();
	} else if (rep.getResult() instanceof Result) {

	    if((Result) rep.getResult() ==Result.FILENOTEXIST) {
		JOptionPane.showMessageDialog(null,"File created successfully.");
		
	    }

	}
    }
}
