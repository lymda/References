package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import client.ClientController;

/**
 * The Class FileRightClickGUI designed for the user to cut or copy files.
 */
public class FileRightClickGUI extends AbstractGUI{

	/** The frame. */
	private JFrame frame;
	
	/** The btn copy. */
	private JButton btnCopy ;
	
	/** The btn cut. */
	private JButton btnCut;
	
	/** The imgcut. */
	private Image imgcut = new ImageIcon(this.getClass().getResource("images/newcut.png")).getImage();

	/**
	 * Instantiates a new file right click gui.
	 */
	public FileRightClickGUI() {
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 18));
		frame.setBounds(100, 100, 230, 210);
		frame.getContentPane().setLayout(null);
		
		btnCut = new JButton("Cut");
		btnCut.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCut.setBounds(35, 13, 142, 35);
		frame.getContentPane().add(btnCut);
		btnCut.setIcon(new ImageIcon(imgcut));
		
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainWorkSpaceGUI gui = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(ClientController.getGUIFlow().size()-2);
				gui.getFrame(frame).setEnabled(true);
				goBack();
			}
		});
		btnBack.setBounds(60, 113, 89, 23);
		frame.getContentPane().add(btnBack);
		
		btnCopy = new JButton("Copy");
		btnCopy.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnCopy.setBounds(35, 61, 142, 35);
		frame.getContentPane().add(btnCopy);
		Image imgcopy = new ImageIcon(this.getClass().getResource("images/newcopy.png")).getImage();
		btnCopy.setIcon(new ImageIcon(imgcopy));
		
		JLabel background = new JLabel("");
		background.setIcon(new ImageIcon(FileRightClickGUI.class.getResource("/boundary/images/server UI.jpg")));
		background.setBounds(0, 0, 266, 211);
		frame.getContentPane().add(background);
	}
	
	/**
	 * Gets the btn copy.
	 *
	 * @return the btn copy
	 */
	public JButton getBtnCopy(){
		return btnCopy;
	}
	
	/**
	 * Gets the btn cut.
	 *
	 * @return the btn cut
	 */
	public JButton getBtnCut(){
		return btnCut;
	}
	
	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		// TODO Auto-generated method stub
		
	}
}
