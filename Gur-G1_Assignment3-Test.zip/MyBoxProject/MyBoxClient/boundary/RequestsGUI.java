package boundary;

import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import controller.GroupController;
import controller.MessageController;
import controller.RequestsController;
import entity.Reply;
import entity.Requests;
import enums.Command;
import enums.Result;

/**
 * The Class RequestsGUI designed for the admin to accept or deny requests from users.
 */
public class RequestsGUI extends AbstractGUI {

	/** The frame. */
	private JFrame frame;

	/** The table_2 is the graphical table of the requests. */
	private JTable table_2;

	/** The data of the requests. */
	private Object data[][];

	/** The scroll pane. */
	private JScrollPane scrollPane;

	/** The bg. */
	private JPanel mainpanelbg;
	//	private JLabel labelbg;

	/**
	 * Instantiates a new requests gui.
	 */
	public RequestsGUI() {
		initialize();
		this.initGUI(frame);
	}

	/**
	 * Initialize.
	 */
	private void initialize(){
		frame=new JFrame();
		frame.setTitle("MyBox - Requests");
		frame.setBounds(100, 20, 581, 488);
		frame.setResizable(false);
		mainpanelbg = new JPanel();
		frame.setContentPane(mainpanelbg);

		Image img0 = new ImageIcon(this.getClass().getResource("images/icon.jpg")).getImage();
		frame.setIconImage(img0);
		Image img = new ImageIcon(this.getClass().getResource("images/wall1gur.jpg")).getImage();
		mainpanelbg.setLayout(null);

		JButton buttonBack = new JButton("Back");
		buttonBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				goBack();
			}
		});
		buttonBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		buttonBack.setBounds(476, 422, 89, 23);
		mainpanelbg.add(buttonBack);

		RequestsController.GetAllRequests();

		JLabel lblPendingRequests = new JLabel("Pending Requests");
		lblPendingRequests.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblPendingRequests.setBounds(180, 11, 204, 35);
		mainpanelbg.add(lblPendingRequests);

		JButton btnApprove = new JButton("Approve");
		btnApprove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row=table_2.getSelectedRow();
				if(row==-1)
					JOptionPane.showMessageDialog(null, "No row is selected", "Error", JOptionPane.ERROR_MESSAGE);
				else
				{
					Requests request=new Requests(Integer.parseInt(table_2.getModel().getValueAt(row, 0).toString()),table_2.getModel().getValueAt(row, 1).toString(),
							table_2.getModel().getValueAt(row, 2).toString(),table_2.getModel().getValueAt(row, 3).toString());
					if(request.getType().equals("add"))
					{
						GroupController.AddUserToGroup(table_2.getModel().getValueAt(row, 1).toString(),table_2.getModel().getValueAt(row, 2).toString());
						RequestsController.deleteRequest(request);
					}
					else if(request.getType().equals("leave"))
					{
						GroupController.RemoveUserFromGroup(table_2.getModel().getValueAt(row, 1).toString(),table_2.getModel().getValueAt(row, 2).toString());
						RequestsController.deleteRequest(request);
					}
					else
						JOptionPane.showMessageDialog(null, "Type of permission is not recognize", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnApprove.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnApprove.setBounds(15, 422, 103, 23);
		mainpanelbg.add(btnApprove);

		JButton btnDeny = new JButton("Deny");
		btnDeny.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row=table_2.getSelectedRow();
				if(row==-1)
					JOptionPane.showMessageDialog(null, "No row is selected", "Error", JOptionPane.ERROR_MESSAGE);
				else if (JOptionPane.showConfirmDialog(frame, "Are you sure you want to deny the selected request?","Confirm", JOptionPane.YES_NO_OPTION) == 0)
				{
					String temp=table_2.getModel().getValueAt(row, 1).toString();
					Requests request=new Requests(Integer.parseInt(table_2.getModel().getValueAt(row, 0).toString()),table_2.getModel().getValueAt(row, 1).toString(),
							table_2.getModel().getValueAt(row, 2).toString(),table_2.getModel().getValueAt(row, 3).toString());
					if(request.getType().equals("add"))
						MessageController.SendMessage(request.getUserName(), "Your request to join the group: "+request.getGroupName()+" was rejected by system administrator");
					else if(request.getType().equals("leave"))
						MessageController.SendMessage(request.getUserName(), "Your request to leave the group: "+request.getGroupName()+" was rejected by system administrator");
					RequestsController.deleteRequest(request);
				}
			}
		});

		btnDeny.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDeny.setBounds(127, 422, 103, 23);
		mainpanelbg.add(btnDeny);

		JLabel labelbg = new JLabel("");
		labelbg.setBounds(0, -11, 590, 488);
		mainpanelbg.add(labelbg);
		//		labelbg.setIcon(new ImageIcon(img));		
	}

	/**
	 * @see boundary.AbstractGUI#getReply(java.lang.Object)
	 */
	@Override
	public void getReply(Object r) {
		Reply rep=(Reply)r;
		if(rep.getCommand().equals(Command.GETALLREQUESTS))
		{
			String columns[]={"Request ID","User Name","Group Name","Request Type"};
			ArrayList<Requests> requests_arryList=(ArrayList<Requests>)rep.getResult();
			data=new Object[requests_arryList.size()][4];
			for(int i=0;i<requests_arryList.size();i++)
			{
				data[i][0]=Integer.toString(requests_arryList.get(i).getRequestsID());
				data[i][1]=requests_arryList.get(i).getUserName();
				data[i][2]=requests_arryList.get(i).getGroupName();
				data[i][3]=requests_arryList.get(i).getType();
			}
			table_2 = new JTable(data,columns);
			table_2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table_2.getTableHeader().setReorderingAllowed(false);
			scrollPane = new JScrollPane(table_2,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			table_2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			for(int i=0;i<4;i++)
				table_2.getColumnModel().getColumn(i).setPreferredWidth(134);
			scrollPane.setViewportBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
			scrollPane.setBounds(10, 57, 545, 354);
			mainpanelbg.add(scrollPane);

		}
		else if(rep.getResult() instanceof Result)
		{
			Result res=(Result)rep.getResult();
			if(res.equals(Result.USERADDEDTOGROUP) || res.equals(Result.USERREMOVEDFROMGROUP))
				JOptionPane.showMessageDialog(null, "Request has been aprroved.", "Done", JOptionPane.PLAIN_MESSAGE);
			else if(res.equals(Result.USERALLREADYINGROUP))
				JOptionPane.showMessageDialog(null, "User is allready in group.", "Done", JOptionPane.PLAIN_MESSAGE);
			else if(res.equals(Result.USERNOTINGROUP))
				JOptionPane.showMessageDialog(null, "User is allready not in group.", "Done", JOptionPane.PLAIN_MESSAGE);
			scrollPane.remove(table_2);
			mainpanelbg.remove(scrollPane);
			RequestsController.GetAllRequests();
		}
		else if(rep.getResult().equals(Command.DELETEREQUEST))
			goBack();
	}
}
