package boundary;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import client.ClientController;
import controller.CheckUpdateAuthorizedController;
import controller.CreateNewFileController;
import controller.FileController;
import controller.MessageController;
import controller.UpdateFileController;
import entity.File;
import entity.Reply;
import enums.Result;

/**
 * The Class UpdateFileGUI designed for the user to update existing file to the system.
 * file with the same name will replace the existing.
 * file with new name will be create.
 */
public class UpdateFileGUI extends AbstractGUI {

    /** The frame. */
    private JFrame frame;

    /** The file path. */
    private String filePath = "";

    /** The btn ok. */
    private JButton btnOk;

    /** The permission list. */
    private ArrayList<String> permissionlist = new ArrayList<String>();

    /** The file. */
    private File file = null;

    /** The main. */
    private MainWorkSpaceGUI main;

    /** The update or create flag. */
    private int updateOrCreateFlag = 0;

    /** The loading gif. */
    private  JLabel loadingGIF;

    /**
     * Instantiates a new update file gui.
     */
    public UpdateFileGUI() {
	permissionlist.add(0, "public");
	initialize();
	this.initGUI(frame);
	main = (MainWorkSpaceGUI) ClientController.getGUIFlow().get(
		ClientController.getGUIFlow().size() - 2);
    }

    /**
     * Initialize.
     */
    public void initialize() {
	frame = new JFrame();
	frame.setTitle("MyBox - Upload File");
	frame.setBounds(100, 20, 384, 221);
	JPanel mainpanelbg = new JPanel();
	frame.setContentPane(mainpanelbg);

	Image img0 = new ImageIcon(this.getClass().getResource(
		"images/icon.jpg")).getImage();
	frame.setIconImage(img0);
	Image img = new ImageIcon(this.getClass().getResource(
		"images/wall12.jpg")).getImage();
	mainpanelbg.setLayout(null);

	Image img1 = new ImageIcon(this.getClass().getResource(
		"images/ok - 13.png")).getImage();

	loadingGIF = new JLabel("");
	loadingGIF.setIcon(new ImageIcon(UpdateFileGUI.class.getResource("/boundary/images/ajax-loader.gif")));
	loadingGIF.setBounds(92, 13, 180, 161);
	loadingGIF.setVisible(false);
	mainpanelbg.add(loadingGIF);

	JLabel lblFileLocation = new JLabel("Choose File:");
	lblFileLocation.setBounds(10, 29, 201, 37);
	lblFileLocation.setFont(new Font("Copperplate Gothic Light", Font.BOLD,
		18));
	mainpanelbg.add(lblFileLocation);

	JButton btnChoosebrowse = new JButton("Browse");
	btnChoosebrowse.setBounds(228, 36, 117, 23);
	btnChoosebrowse.setFont(new Font("Tahoma", Font.BOLD, 16));
	btnChoosebrowse.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent arg0) {
		JButton open = new JButton();
		JFileChooser fc = new JFileChooser();
		if (fc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
		    JOptionPane.showMessageDialog(null,
			    "File Has been choosen.");
		    filePath = fc.getSelectedFile().toString();
		    ArrayList<String> path = new ArrayList<String>(Arrays
			    .asList(filePath.split("\\\\")));
		    String fileName = path.get(path.size() - 1);

		    ArrayList<Integer> arr = main.getFolderPath();
		    int folderID = arr.get(arr.size() - 1);
		    FileController.checkFileExistence(fileName, main.curUser);
		    file = new File(main.curUser, filePath, fileName, "",
			    permissionlist, folderID);
		}
	    }
	});
	mainpanelbg.add(btnChoosebrowse);

	JButton btnCancel = new JButton("Cancel");
	btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnCancel.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		goBack();
	    }

	});
	btnCancel.setBounds(256, 131, 89, 23);
	mainpanelbg.add(btnCancel);

	btnOk = new JButton("OK");
	btnOk.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnOk.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent arg0) {
		loadingGIF.setVisible(true);
		if (updateOrCreateFlag==1) 
		    CreateNewFileController.sentReq(file);

		else {
		    CheckUpdateAuthorizedController.sentReq(main.curUser, file.getFileName(), "update");
		}


	    }
	});
	btnOk.setEnabled(false);
	btnOk.setBounds(152, 131, 89, 23);
	mainpanelbg.add(btnOk);

	JLabel labelbackground = new JLabel("");
	labelbackground.setBounds(0, 0, 382, 255);
	mainpanelbg.add(labelbackground);
	labelbackground.setIcon(new ImageIcon(img));
    }

    /**
     * @see boundary.AbstractGUI#getReply(java.lang.Object)
     */
    @Override
    public void getReply(Object r) {
	Reply rep = (Reply) r;
	if(rep.getResult() instanceof Boolean ) {

	    if (!(boolean) rep.getResult()) {
		JOptionPane
		.showMessageDialog(
			null,
			"You are updating file that does not exist."+"\n The file will be add to your current location with public permission and without description."
				+ "\n If you want diffrent "
				+ "location, do it in the wanted one. ");
		updateOrCreateFlag=1;
		btnOk.setEnabled(true);

	    } else if ((boolean) rep.getResult()) {
		updateOrCreateFlag=2;
		btnOk.setEnabled(true);
	    }
	}
	else if (rep.getResult() instanceof Result)
	{
	    if((Result) rep.getResult() == Result.FILENOTEXIST) {
		main.addFileButton(file.getFileName(),main.getImgfile());
		goBack();
	    }
	    else if((Result) rep.getResult() == Result.UPDATE_APPROVE) {
		Date now = new Date();
		String message="File "+file.getFileName()+" you are related to was updated at " + DateFormat.getInstance().format(now) +".";
		MessageController.SendMessageToUsersRelvantForFile(file.getFileName(), message);
		UpdateFileController.sentReq(file);
		loadingGIF.setVisible(false);
		JOptionPane.showMessageDialog(null,"File updated successful."); 
		goBack();
	    }
	    else if((Result) rep.getResult() == Result.UPDATE_NOT_APPROVE) {
		JOptionPane.showMessageDialog(null,"You do not have permission to update this file.");
		goBack();
	    }
	}
    }
}
