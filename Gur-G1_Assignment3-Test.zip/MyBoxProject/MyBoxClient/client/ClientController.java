package client;

import java.io.IOException;
import java.util.ArrayList;

import ocsf.client.AbstractClient;
import boundary.AbstractGUI;

import common.UI;

import entity.User;

/**
 * The Class ClientController is the client controller of MyBox System.
 */
public class ClientController extends AbstractClient {

    /** The current user. */
    private static User currentUser = null;
    
    /** The GUI flow. */
    private static ArrayList<AbstractGUI> GUIFlow;
    
    /** The client ui. */
    private UI clientUI;

    /**
     * Instantiates a new client controller.
     *
     * @param host the host of connected server.
     * @param port the port of connected server.
     * @param clientUI the client ui.
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public ClientController(String host, int port, UI clientUI)
	    throws IOException {
	super(host, port);
	this.clientUI = clientUI;
	ClientController.GUIFlow = new ArrayList<AbstractGUI>();
	openConnection();
    }

    /* (non-Javadoc)
     * @see ocsf.client.AbstractClient#handleMessageFromServer(java.lang.Object)
     */
    @Override
    protected void handleMessageFromServer(Object msg) {

	GUIFlow.get(GUIFlow.size() - 1).getReply(msg);
    }

    /**
     * Handle message from client ui.
     *
     * @param message the message
     */
    public void handleMessageFromClientUI(Object message) {

	try {
	    sendToServer(message);
	} catch (IOException e) {
	    clientUI.display("Could not send message to server.  Terminating client.");
	    quit();
	}

    }

    /**
     * Quit.
     */
    public void quit() {
	try {
	    closeConnection();
	} catch (IOException e) {
	}
	System.exit(0);
    }

    /**
     * Gets the current user.
     *
     * @return the current user
     */
    public static User getCurrentUser() {
	return currentUser;
    }

    /**
     * Sets the current user.
     *
     * @param currentUser the new current user
     */
    public static void setCurrentUser(User currentUser) {
	ClientController.currentUser = currentUser;
    }

    /**
     * Gets the GUI flow.
     *
     * @return the GUI flow
     */
    public static ArrayList<AbstractGUI> getGUIFlow() {
	return GUIFlow;
    }

    /**
     * Sets the GUI flow.
     *
     * @param gUIFlow the new GUI flow
     */
    public static void setGUIFlow(ArrayList<AbstractGUI> gUIFlow) {
	GUIFlow = gUIFlow;
    }
}
