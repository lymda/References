package client;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import server.ServerSession;

/**
 * The Class Main is the client entry point to the system.
 */
public class Main {

    /** The Client frame. */
    private JFrame ClientFrame;

    /** The ip text field. */
    private JTextField ipTextField;

    /**
     * Launch client application application.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
	    public void run() {

		try {
		    Main window = new Main();
		    window.ClientFrame.setVisible(true);
		} catch (Exception e) {
		    e.printStackTrace();
		}
	    }
	});
    }

    /**
     * Create the application.
     */
    public Main() {
	initialize();
	ClientFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
	ClientFrame = new JFrame();
	ClientFrame.setBackground(new Color(240, 240, 240));
	ClientFrame.setResizable(false);
	ClientFrame.setTitle("Connecting to Server");
	ClientFrame.setBounds(500, 500, 267, 165);
	ClientFrame.getContentPane().setLayout(null);

	ipTextField = new JTextField();
	ipTextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
	ipTextField.setText("localhost");
	ipTextField.setBounds(73, 29, 143, 20);
	ClientFrame.getContentPane().add(ipTextField);
	ipTextField.setColumns(10);

	JButton btnNewButton = new JButton("Connect");
	btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnNewButton.addActionListener(new ActionListener() {
	    public void actionPerformed(ActionEvent arg0) {
		MyBoxMain.connectClient(ipTextField.getText());
		ServerSession.setIp(ipTextField.getText());
		ClientFrame.dispose();
	    }
	});
	btnNewButton.setBounds(73, 78, 111, 33);
	ClientFrame.getContentPane().add(btnNewButton);

	JLabel lblIp = new JLabel("IP:");
	lblIp.setFont(new Font("Tahoma", Font.BOLD, 18));
	lblIp.setBounds(15, 32, 46, 14);
	ClientFrame.getContentPane().add(lblIp);

	JLabel label = new JLabel("");
	label.setIcon(new ImageIcon(Main.class
		.getResource("/boundary/images/client.jpg")));
	label.setBounds(0, 0, 261, 130);
	ClientFrame.getContentPane().add(label);
    }

}
