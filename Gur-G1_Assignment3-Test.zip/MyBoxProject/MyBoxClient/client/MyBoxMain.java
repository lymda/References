package client;

import java.io.IOException;

import boundary.LoginGUI;
import common.UI;
import entity.Request;

/**
 * The Class MyBoxMain is the main that creates the client controller and the login.
 */
public class MyBoxMain implements UI {
	
	public static MyBoxMain box;

    /** The Constant DEFAULT_PORT. */
    final public static int DEFAULT_PORT = 5551;

    /** The client. */
    public static ClientController client;

    /** The login GUI. */
    LoginGUI login;

    public LoginGUI getLogin() {
		return login;
	}

	public void setLogin(LoginGUI login) {
		this.login = login;
	}

	/**
     * Instantiates a new my box main.
     *
     * @param host the host of the server.
     * @param port the port of the server.
     */
    public MyBoxMain(String host, int port) {

	try {
	    client = new ClientController(host, port, this);
	    login = new LoginGUI();

	} catch (IOException exception) {
	    System.out.println("Error: Can't setup connection!"
		    + " Terminating client.");
	    System.exit(1);
	}
    }

    /**
     * Display.
     *
     * @param message the message
     */
    public void display(Object message) {
	System.out.println("> " + message);
    }

    /**
     * Accept the events from client UI.
     *
     * @param requset is the request for the server.
     */
    @SuppressWarnings("unused")
    private void accept(Request requset) {
	try {

	    client.handleMessageFromClientUI(requset);

	} catch (Exception ex) {
	    System.out.println("Unexpected error while reading from console!");
	}

    }

    /**
     * Connect client to the server.
     *
     * @param args is the IP of the servr.
     */
    public static void connectClient(String args) {
	// TODO Auto-generated method stub
	String host = "";

	try {

	    host = args;
	} catch (ArrayIndexOutOfBoundsException e) {
	    host = "localhost";
	}
	box = new MyBoxMain(host, DEFAULT_PORT);
	System.out.println("Connection to " + host + " succeeded!");
    }

    /* (non-Javadoc)
     * @see common.UI#display(java.lang.String)
     */
    @Override
    public void display(String message) {
    }

    /* (non-Javadoc)
     * @see common.UI#displayError(java.lang.String)
     */
    @Override
    public void displayError(String message) {
    }

}
