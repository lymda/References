package entity;

import java.io.Serializable;

/**
 * The Class Workspace describe a workspace folder in the MyBox system.
 */
public class Workspace implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The workspace id. */
	private int workspaceID;

	/**
	 * Instantiates a new workspace.
	 *
	 * @param workspaceID the workspace id
	 */
	public Workspace(int workspaceID) {
		super();
		this.workspaceID = workspaceID;
	}

	/**
	 * Gets the workspace id.
	 *
	 * @return the workspace id
	 */
	public int getWorkspaceID() {
		return workspaceID;
	}

	/**
	 * Sets the workspace id.
	 *
	 * @param workspaceID the new workspace id
	 */
	public void setWorkspaceID(int workspaceID) {
		this.workspaceID = workspaceID;
	}

}
