package entity;

import java.io.Serializable;

/**
 * The Class Group describe a recored in group table.
 */
public class Group implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The group name. */
	private	String groupName;

	/**
	 * Instantiates a new group.
	 *
	 * @param groupName the group name
	 */
	public Group(String groupName) {
		super();
		this.groupName = groupName;
	}

	/**
	 * Gets the group name.
	 *
	 * @return the group name
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * Sets the group name.
	 *
	 * @param groupName the new group name
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	

}
