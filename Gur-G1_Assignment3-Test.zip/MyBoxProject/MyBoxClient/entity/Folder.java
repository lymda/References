package entity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * The Class Folder describe a folder record in folder table.
 */
public class Folder implements Serializable{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The folder id. */
	private int folderID;
	
	/** The folder name. */
	private String folderName;
	
	/** The folders array. */
	private ArrayList<Integer> folders;
	
	/** The parent folder. */
	private	int parent;
	
	/**
	 * Instantiates a new folder.
	 *
	 * @param folderName the folder name
	 * @param parent the parent folder
	 */
	public Folder(String folderName, int parent) {
		super();
		this.folderName = folderName;
		this.parent = parent;
	}

	/**
	 * Gets the folder id.
	 *
	 * @return the folder id
	 */
	public int getFolderID() {
		return folderID;
	}

	/**
	 * Sets the folder id.
	 *
	 * @param folderID the new folder id
	 */
	public void setFolderID(int folderID) {
		this.folderID = folderID;
	}

	/**
	 * Gets the folder name.
	 *
	 * @return the folder name
	 */
	public String getFolderName() {
		return folderName;
	}

	/**
	 * Sets the folder name.
	 *
	 * @param folderName the new folder name
	 */
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	/**
	 * Gets the folders array.
	 *
	 * @return the folders array
	 */
	public ArrayList<Integer> getFolders() {
		return folders;
	}

	/**
	 * Sets the folders array.
	 *
	 * @param folders the new folders array
	 */
	public void setFolders(ArrayList<Integer> folders) {
		this.folders = folders;
	}

	/**
	 * Gets the parent folder.
	 *
	 * @return the parent folder
	 */
	public int getParent() {
		return parent;
	}

	/**
	 * Sets the parent folder.
	 *
	 * @param parent the new parent folder
	 */
	public void setParent(int parent) {
		this.parent = parent;
	}
	
	

}
