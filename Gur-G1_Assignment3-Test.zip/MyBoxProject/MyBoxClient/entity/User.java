package entity;

import java.io.Serializable;

/**
 * The Class User describe a user recored in user table.
 */
public class User implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The user name. */
	private String userName;
	
	/** The password. */
	private String password;
	
	/** The my workspace id. */
	private int myWorkspaceID;
	
	/** The is admin. */
	private boolean isAdmin;
	
	/** The user status. */
	private int status; // logged in = 1, logged off = 0.

	/**
	 * Instantiates a new user.
	 *
	 * @param userName the user name
	 * @param password the password
	 * @param isAdmin the is admin
	 */
	public User(String userName, String password, boolean isAdmin) {
		super();
		this.userName = userName;
		this.password = password;
		this.isAdmin = isAdmin;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the password.
	 *
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Sets the password.
	 *
	 * @param password the new password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * Gets the my workspace id.
	 *
	 * @return the my workspace id
	 */
	public int getMyWorkspaceID() {
		return myWorkspaceID;
	}

	/**
	 * Sets the my workspace id.
	 *
	 * @param myWorkspaceID the new my workspace id
	 */
	public void setMyWorkspaceID(int myWorkspaceID) {
		this.myWorkspaceID = myWorkspaceID;
	}

	/**
	 * Checks if is admin.
	 *
	 * @return true, if is admin
	 */
	public boolean isAdmin() {
		return isAdmin;
	}

	/**
	 * Sets the admin.
	 *
	 * @param isAdmin the sets admin
	 */
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	/**
	 * Gets the user status.
	 *
	 * @return the user status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Sets the user status.
	 *
	 * @param status the new user status
	 */
	public void setStatus(int status) {
		this.status = status;
	}


}
