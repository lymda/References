package entity;

import java.io.Serializable;

/**
 * The Class FileGroup describe a record in filegroup table.
 */
public class FileGroup implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The group name. */
	private String groupName;
	
	/** The file name. */
	private String fileName;
	
	/** The permission. */
	private String permission;

	/**
	 * Gets the group name.
	 *
	 * @return the group name
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * Sets the group name.
	 *
	 * @param groupName the new group name
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * Gets the file name.
	 *
	 * @return the file name
	 */
	public String getfileName() {
		return fileName;
	}

	/**
	 * Sets the file name.
	 *
	 * @param fileName the new file name
	 */
	public void setfileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Gets the permission.
	 *
	 * @return the permission
	 */
	public String getPermission() {
		return permission;
	}

	/**
	 * Sets the permission.
	 *
	 * @param permission the new permission
	 */
	public void setPermission(String permission) {
		this.permission = permission;
	}

	/**
	 * Instantiates a new file group.
	 *
	 * @param groupName the group name
	 * @param fileName the file name
	 * @param permission the permission
	 */
	public FileGroup(String groupName, String fileName, String permission) {
		super();
		this.groupName = groupName;
		this.fileName = fileName;
		this.permission = permission;
	}

}
