package entity;

import java.io.Serializable;

/**
 * The Class FileDetails manage the file details in the system.
 */
public class FileDetails implements Serializable {
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The file description. */
    public String oldFileName,fileName, description;
    
    /** The description flag. */
    public int nameFlag, discriptionFlag;

    /**
     * Instantiates a new file details.
     *
     * @param oldFileName the old file name
     * @param fileName the file name
     * @param description the file description
     * @param nameFlag the file name flag
     * @param discriptionFlag the description flag
     */
    public FileDetails(String oldFileName,String fileName, String description, int nameFlag,
	    int discriptionFlag) {
	super();
	this.oldFileName=oldFileName;
	this.fileName = fileName;
	this.description = description;
	this.nameFlag = nameFlag;
	this.discriptionFlag = discriptionFlag;
    }

}
