package entity;

import java.io.Serializable;

/**
 * The Class Requests describe a record in request table.
 */
public class Requests implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Requests id. */
	private int RequestsID;
	
	/** The user name. */
	private String userName;
	
	/** The group name. */
	private String groupName;
	
	/** The request type. */
	private String type;

	/**
	 * Instantiates a new requests.
	 *
	 * @param RequestsID the requests id
	 * @param userName the user name
	 * @param groupName the group name
	 * @param permission the permission
	 */
	public Requests(int RequestsID, String userName, String groupName,
			String permission) {
		super();
		this.RequestsID = RequestsID;
		this.userName = userName;
		this.groupName = groupName;
		this.type = permission;
	}
	
	/**
	 * Instantiates a new requests.
	 *
	 * @param userName the user name
	 * @param groupName the group name
	 * @param permission the permission
	 */
	public Requests(String userName, String groupName, String permission) {
		super();
		this.userName = userName;
		this.groupName = groupName;
		this.type = permission;
	}

	/**
	 * Gets the requests id.
	 *
	 * @return the requests id
	 */
	public int getRequestsID() {
		return RequestsID;
	}

	/**
	 * Sets the requests id.
	 *
	 * @param RequestsID the new requests id
	 */
	public void setRequestsID(int RequestsID) {
		this.RequestsID = RequestsID;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the group name.
	 *
	 * @return the group name
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * Sets the group name.
	 *
	 * @param groupName the new group name
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * Gets the request type.
	 *
	 * @return the request type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the request type.
	 *
	 * @param type the new request type
	 */
	public void setType(String type) {
		this.type = type;
	}

}
