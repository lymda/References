package entity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * The Class File define a file entity in the MyBox system.
 */
public class File implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The file id. */
	private int fileID;
	
	/** The folder id. */
	private int folderID;
	
	/** The path. */
	private String path;
	
	/** The file name. */
	private String fileName;
	
	/** The file description. */
	private String description;
	
	/** The permission rate. */
	private String permissionRate;
	
	/** The file owner. */
	private String fileOwner;
	
	/** The file status. */
	private boolean status;
	
	/** The file byte array. */
	private byte[] myByteArray;
	
	/** The file size. */
	private int size = 0;
	
	/** The file permission list. */
	private ArrayList<String> permissionList;

	/**
	 * Instantiates a new file.
	 *
	 * @param fileID the file id
	 * @param fileName the file name
	 * @param description the file description
	 * @param permissionRate the file permission rate
	 * @param fileOwner the file owner
	 * @param status the file status
	 * @param folderID the folder id
	 */
	public File(int fileID, String fileName, String description,
			String permissionRate, String fileOwner, boolean status, int folderID) {

		super();
		this.fileID = fileID;
		this.folderID=folderID;
		this.fileName = fileName;
		this.description = description;
		this.permissionRate = permissionRate;
		this.fileOwner = fileOwner;
		this.status = status;
	}
	

	/**
	 * Instantiates a new file.
	 *
	 * @param fileOwner the file owner
	 * @param path the file path
	 * @param fileName the file name
	 * @param description the file description
	 * @param permissionRate the file permission rate
	 * @param folderID the folder id
	 */
	public File(String fileOwner, String path, String fileName,
			String description, String permissionRate, int folderID) {
		super();
		this.folderID=folderID;
		this.fileOwner = fileOwner;
		this.path = path;
		this.fileName = fileName;
		this.description = description;
		this.permissionRate = permissionRate;
	}


	/**
	 * Instantiates a new file.
	 *
	 * @param fileOwner the file owner
	 * @param fileName the file name
	 * @param description the file description
	 * @param permissionRate the file permission rate
	 * @param folderID the folder id
	 */
	public File(String fileOwner, String fileName, String description,
			String permissionRate, int folderID) {
		
		super();
		this.folderID=folderID;
		this.fileOwner = fileOwner;
		this.fileName = fileName;
		this.description = description;
		this.permissionRate = permissionRate;
	}

	/**
	 * Instantiates a new file.
	 *
	 * @param fileOwner the file owner
	 * @param path the file path
	 * @param fileName the file name
	 * @param description the file description
	 * @param list the permission list
	 * @param folderID the folder id
	 */
	public File(String fileOwner, String path, String fileName,
			String description, ArrayList<String> list, int folderID) {
		
		super();
		this.folderID=folderID;
		this.fileOwner = fileOwner;
		this.path = path;
		this.fileName = fileName;
		this.description = description;
		this.permissionRate = list.get(0);		// main permission (public, group, private)
		this.permissionList = list;
	}
	
	/**
	 * Gets the file permission list.
	 *
	 * @return the permission list
	 */
	public ArrayList<String> getPermissionList() {
		return permissionList;
	}

	/**
	 * Gets the file id.
	 *
	 * @return the file id
	 */
	public int getFileID() {
		return fileID;
	}

	/**
	 * Gets the folder id.
	 *
	 * @return the folder id
	 */
	public int getFolderID() {
		return folderID;
	}

	/**
	 * Sets the file id.
	 *
	 * @param fileID the new file id
	 */
	public void setFileID(int fileID) {
		this.fileID = fileID;
	}

	/**
	 * Gets the file name.
	 *
	 * @return the file name
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * Sets the file name.
	 *
	 * @param fileName the new file name
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * Gets the file description.
	 *
	 * @return the file description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the file description.
	 *
	 * @param description the new file description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the file permission rate.
	 *
	 * @return the file permission rate
	 */
	public String getPermissionRate() {
		return permissionRate;
	}

	/**
	 * Sets the file permission rate.
	 *
	 * @param permissionRate the new file permission rate
	 */
	public void setPermissionRate(String permissionRate) {
		this.permissionRate = permissionRate;
	}

	/**
	 * Gets the file owner.
	 *
	 * @return the file owner
	 */
	public String getFileOwner() {
		return fileOwner;
	}

	/**
	 * Sets the file owner.
	 *
	 * @param fileOwner the new file owner
	 */
	public void setFileOwner(String fileOwner) {
		this.fileOwner = fileOwner;
	}

	/**
	 * Checks the file status.
	 *
	 * @return true, if status is not deleted
	 */
	public boolean isStatus() {
		return status;
	}

	/**
	 * Sets the file status.
	 *
	 * @param status the file new status
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * Byte array.
	 *
	 * @param size the size of file
	 */
	public void ByteArray(int size) {

		this.setMyByteArray(new byte[size]);
	}

	/**
	 * Gets the file  byte array.
	 *
	 * @return the file byte array
	 */
	public byte[] getMyByteArray() {
		return myByteArray;
	}

	/**
	 * Sets the file byte array.
	 *
	 * @param myByteArray the new file byte array
	 */
	public void setMyByteArray(byte[] myByteArray) {
		this.myByteArray = myByteArray;
	}

	/**
	 * Gets the file byte array at i place.
	 *
	 * @param i the i place in byte array
	 * @return the file byte array at i place
	 */
	public byte getMybytearray(int i) {
		return myByteArray[i];
	}

	/**
	 * Sets the file byte array.
	 *
	 * @param mybytearray the new file byte array
	 */
	public void setMybytearray(byte[] mybytearray) {

		for (int i = 0; i < mybytearray.length; i++)
			this.myByteArray[i] = mybytearray[i];
	}

	/**
	 * Gets the file size.
	 *
	 * @return the file size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Sets the file size.
	 *
	 * @param size the new file size
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Initial file array.
	 *
	 * @param size the file size
	 */
	public void initialArray(int size) {
		this.myByteArray = new byte[size];
	}

	/**
	 * Gets the file path.
	 *
	 * @return the file path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * Sets the file path.
	 *
	 * @param path the new file path
	 */
	public void setPath(String path) {
		this.path = path;
	}

}
