package entity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * The Class FileFolderID manage the files and folders in a folder.
 */
public class FileFolderID implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The files array. */
	private ArrayList<String> fileArr;
	
	/** The folders array. */
	private ArrayList<String> folderArr;
	
	/** The folder id. */
	private int folderID;
	
	/**
	 * Instantiates a new file folder id.
	 *
	 * @param file the file
	 * @param folder the folder
	 * @param ID the id
	 */
	public FileFolderID(ArrayList<String> file, ArrayList<String> folder, int ID  ){
		this.fileArr=file;
		this.folderArr=folder;
		this.folderID=ID;
	}
	
	/**
	 * Gets the files array.
	 *
	 * @return the files array
	 */
	public ArrayList<String> getFileArr(){
		return fileArr;
	}
	
	/**
	 * Gets the folders array.
	 *
	 * @return the folders array
	 */
	public ArrayList<String> getFolderArr(){
		return folderArr;
	}
	
	/**
	 * Gets the folder id.
	 *
	 * @return the folder id
	 */
	public int getFolderID(){
		return folderID;
	}
}
