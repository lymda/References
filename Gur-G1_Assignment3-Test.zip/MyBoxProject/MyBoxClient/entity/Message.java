package entity;

import java.io.Serializable;

/**
 * The Class Message describe a record in message table.
 */
public class Message implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The message id. */
	private int messageID;
	
	/** The to user id. */
	private String toUserID;
	
	/** The message. */
	private String message;
	
	/**
	 * Instantiates a new message.
	 *
	 * @param toUserID the to user id
	 * @param message the message
	 */
	public Message(String toUserID, String message) {
		super();
		this.toUserID = toUserID;
		this.message = message;
	}
	
	/**
	 * Instantiates a new message.
	 *
	 * @param messageID the message id
	 * @param toUserID the to user id
	 * @param message the message
	 */
	public Message(int messageID, String toUserID, String message) {
		super();
		this.messageID = messageID;
		this.toUserID = toUserID;
		this.message = message;
	}
	
	/**
	 * Gets the message id.
	 *
	 * @return the message id
	 */
	public int getMessageID() {
		return messageID;
	}
	
	/**
	 * Gets the to user id.
	 *
	 * @return the to user id
	 */
	public String getToUserID() {
		return toUserID;
	}
	
	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
}
