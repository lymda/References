package Fixtures;

import server.ServerSession;
import boundary.ManageGroupsGUI;
import client.MyBoxMain;
import controller.GroupController;
import fit.ActionFixture;

public class AddUserToGroupTest extends ActionFixture {

    private ManageGroupsGUI GroupsGUI;
    private String uName;
    private String gName;

    public void startAddUser() {
	MyBoxMain.connectClient("127.0.0.1");
	ServerSession.setIp("127.0.0.1");
	MyBoxMain.client.getGUIFlow().get(MyBoxMain.client.getGUIFlow().size()-1).hide();

	try {
	    Thread.sleep(1000);
	} catch (InterruptedException e) {
	    e.printStackTrace();
	}
	GroupsGUI = new ManageGroupsGUI();
	MyBoxMain.client.getGUIFlow().get(MyBoxMain.client.getGUIFlow().size()-1).hide();

    }

    public void userName(String name) {
	uName = name;
    }
    
    public void groupName(String name) {
   	gName = name;
       }

    public boolean addUser() {
	GroupController.AddUserToGroup(uName, gName);
	try {
	    Thread.sleep(1000);
	} catch (InterruptedException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return GroupsGUI.addUserResult;
    }
}
