package Fixtures;

import server.ServerSession;
import controller.GroupController;
import boundary.ManageGroupsGUI;
import fit.ActionFixture;
import client.Main;
import client.MyBoxMain;

public class CreateGroupTest extends ActionFixture {

    private ManageGroupsGUI GroupsGUI;
    private String gName;

    public void startGroup() {
	MyBoxMain.connectClient("127.0.0.1");
	ServerSession.setIp("127.0.0.1");
	MyBoxMain.client.getGUIFlow().get(MyBoxMain.client.getGUIFlow().size()-1).hide();

	try {
	    Thread.sleep(1000);
	} catch (InterruptedException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	GroupsGUI = new ManageGroupsGUI();
	MyBoxMain.client.getGUIFlow().get(MyBoxMain.client.getGUIFlow().size()-1).hide();

    }

    public void groupName(String name) {
	gName = name;
    }

    public boolean createGroup() {
	GroupController.CreateNewGroup(gName);
	try {
	    Thread.sleep(1000);
	} catch (InterruptedException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return GroupsGUI.addGroupResult;
    }
}
