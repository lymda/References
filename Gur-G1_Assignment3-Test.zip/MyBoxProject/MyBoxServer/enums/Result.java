package enums;

/**
 * The Enum Result is the types of result the server is returning to the
 * client, to let the client now, what happened with his request. 
 */
public enum Result {

    /** The ok. */
    OK,

    /** The failed. */
    FAILED,

    /** The error. */
    ERROR,

    /** The folderisfull. */
    FOLDERISFULL,

    /** The folderdeleted. */
    FOLDERDELETED,

    /** The idnotexist. */
    IDNOTEXIST,

    /** The idexists. */
    IDEXISTS,

    /** The foldernameexist. */
    FOLDERNAMEEXIST,

    /** The foldernamechanged. */
    FOLDERNAMECHANGED,

    /** The wronguser. */
    WRONGUSER,

    /** The wrongpass. */
    WRONGPASS,

    /** The alreadylogin. */
    ALREADYLOGIN,

    /** The isadmin. */
    ISADMIN,

    /** The isuser. */
    ISUSER,

    /** The loggedout. */
    LOGGEDOUT,

    /** The filesend. */
    FILESEND,

    /** The fileexist. */
    FILEEXIST,

    /** The filenotexist. */
    FILENOTEXIST,

    /** The useraddedtogroup. */
    USERADDEDTOGROUP,

    /** The userallreadyingroup. */
    USERALLREADYINGROUP,

    /** The usernotingroup. */
    USERNOTINGROUP,

    /** The groupadded. */
    GROUPADDED,

    /** The groupexists. */
    GROUPEXISTS,

    /** The userremovedfromgroup. */
    USERREMOVEDFROMGROUP,

    /** The wsexist. */
    WSEXIST,

    /** The wsnotexist. */
    WSNOTEXIST,

    /** The requestexists. */
    REQUESTEXISTS,

    /** The requestadded. */
    REQUESTADDED,

    /** The requestremoved. */
    REQUESTREMOVED,

    /** The requestnotexists. */
    REQUESTNOTEXISTS,

    /** The wshasbeencreated. */
    WSHASBEENCREATED,

    /** The wscreationerror. */
    WSCREATIONERROR,

    /** The pathdone. */
    PATHDONE,

    /** The authorizedfilesdata. */
    AUTHORIZEDFILESDATA,

    /** The filewiththesamename. */
    FILEWITHTHESAMENAME,

    /** The messagesent. */
    MESSAGESENT,

    /** The folderexist. */
    FOLDEREXIST,

    /** The filepermissionchanged. */
    FILEPERMISSIONCHANGED,

    /** The filehasbeenaddedtomainws. */
    FILEHASBEENADDEDTOMAINWS,

    /** The fileaddedtogroup. */
    FILEADDEDTOGROUP,

    /** The fileremovedfromgroup. */
    FILEREMOVEDFROMGROUP,

    /** The file permission in group changed. */
    FILE_PERMISSION_IN_GROUP_CHANGED,

    /** The file removed from group. */
    FILE_REMOVED_FROM_GROUP,

    /** The update approve. */
    UPDATE_APPROVE, 
    /** The update not approve. */
    UPDATE_NOT_APPROVE,

    /** The read approve. */
    READ_APPROVE, 
    /** The read not approve. */
    READ_NOT_APPROVE,

    /** The file removed from all groups. */
    FILE_REMOVED_FROM_ALL_GROUPS,
    ;
}
