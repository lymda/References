package enums;

/**
 * The Enum Command that the server is capable of doing.
 */
public enum Command {

    /** The login. */
    LOGIN,

    /** The logout. */
    LOGOUT,

    /** The recieve file from client. */
    RECIEVE_FILE_FROM_CLIENT,

    /** The send file to client. */
    SEND_FILE_TO_CLIENT,

    /** The newfile. */
    NEWFILE,

    /** The newgroup. */
    NEWGROUP,

    /** The loadfilesfoldersforworkspace. */
    LOADFILESFOLDERSFORWORKSPACE,

    /** The loadfilesfoldersforfolder. */
    LOADFILESFOLDERSFORFOLDER,

    /** The deletefilefromfolder. */
    DELETEFILEFROMFOLDER,

    /** The addfiletofolder. */
    ADDFILETOFOLDER,

    /** The deletefolder. */
    DELETEFOLDER,

    /** The usersingroup. */
    USERSINGROUP,

    /** The usersnotingroup. */
    USERSNOTINGROUP,

    /** The allgroups. */
    ALLGROUPS,

    /** The addusertogroup. */
    ADDUSERTOGROUP,

    /** The removeuserfromgroup. */
    REMOVEUSERFROMGROUP,

    /** The getauthorizedfiles. */
    GETAUTHORIZEDFILES,

    /** The error. */
    ERROR,

    /** The checkws. */
    CHECKWS,

    /** The loadgroupsuserin. */
    LOADGROUPSUSERIN,

    /** The loadgroupsusernotin. */
    LOADGROUPSUSERNOTIN,

    /** The createws. */
    CREATEWS,

    /** The addtogroup. */
    ADDTOGROUP,

    /** The leavegroup. */
    LEAVEGROUP,

    /** The addrequest. */
    ADDREQUEST,

    /** The deleterequest. */
    DELETEREQUEST,

    /** The getallrequests. */
    GETALLREQUESTS,

    /** The show file details. */
    SHOW_FILE_DETAILS, 

    /** The edit file details. */
    EDIT_FILE_DETAILS,

    /** The check file existence. */
    CHECK_FILE_EXISTENCE,

    /** The check file owner. */
    CHECK_FILE_OWNER,

    /** The createpath. */
    CREATEPATH,

    /** The addfromauthorized. */
    ADDFROMAUTHORIZED,

    /** The sendmessage. */
    SENDMESSAGE,

    /** The getmessagesforuser. */
    GETMESSAGESFORUSER,

    /** The newfolder. */
    NEWFOLDER,

    /** The get groups file in. */
    GET_GROUPS_FILE_IN,

    /** The get groups file not in. */
    GET_GROUPS_FILE_NOT_IN,

    /** The get file permission. */
    GET_FILE_PERMISSION,

    /** The get root client path. */
    GET_ROOT_CLIENT_PATH,

    /** The change file permission. */
    CHANGE_FILE_PERMISSION,

    /** The changefoldername. */
    CHANGEFOLDERNAME,

    /** The addfiletogroup. */
    ADDFILETOGROUP,

    /** The removefilefromgroup. */
    REMOVEFILEFROMGROUP,

    /** The change file permission for group. */
    CHANGE_FILE_PERMISSION_FOR_GROUP,

    /** The get users authorized for file. */
    GET_USERS_AUTHORIZED_FOR_FILE,

    /** The update file. */
    UPDATE_FILE,

    /** The send message to user related to file. */
    SEND_MESSAGE_TO_USER_RELATED_TO_FILE,

    /** The remove file from group. */
    REMOVE_FILE_FROM_GROUP,

    /** The send message to group. */
    SEND_MESSAGE_TO_GROUP,

    /** The get file owner. */
    GET_FILE_OWNER, 

    /** The changefilestatus. */
    CHANGEFILESTATUS,

    /** The deletefilepermenantly. */
    DELETEFILEPERMENANTLY,

    /** The getdeletedfilesofusers. */
    GETDELETEDFILESOFUSERS,

    /** The check update authorization. */
    CHECK_UPDATE_AUTHORIZATION, 

    /** The check read authorization. */
    CHECK_READ_AUTHORIZATION,

    /** The deletefilefromallgroups. */
    DELETEFILEFROMALLGROUPS,

    /** The delete messages for user. */
    DELETE_MESSAGES_FOR_USER;
    ;



    /**
     * Value of.
     *
     * @param c is the command.
     * @return the command.
     */
    public static Object valueOf(Command c) {
	return Command.valueOf(c);
    }
}
