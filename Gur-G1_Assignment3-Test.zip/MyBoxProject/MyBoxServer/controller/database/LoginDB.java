package controller.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;


/**
 * The Class LoginDB runs a query to login a specified user to the system.
 */
public class LoginDB {

	/**
	 * Exe. - The method check the given user and password to match the password in DB and that the user is not already logged in.
	 *
	 * @param req the Request Object with user name and password.
	 * @param conn the current user connection to server
	 * @return the Result Object (WRONGUSER, WRONGPASS, ALREADYLOGIN, ISADMIN, ISUSER).
	 */
	public static Object exe(Request req, Connection conn) {
		ResultSet res = null;
		Statement stmt;
		
		try {
			stmt = conn.createStatement();
			res = stmt.executeQuery("SELECT * FROM myboxdb.user WHERE user.userName='"+ req.getUserID() +"'");
			
			// req.getUserID() == userName, req.getUserID() == password
			
			if (!res.next()) return Result.WRONGUSER;
			
			String user = res.getString(1);
			String pass = res.getString(2);
			int admin = res.getInt(4);
			int log = res.getInt(5);
			
			if (user.compareTo(req.getUserID())!=0) return Result.WRONGUSER;
						
			if (pass.compareTo((String)req.getEntity())!=0) return Result.WRONGPASS;
			
			else if (log == 1) return Result.ALREADYLOGIN;
			
			else 
			{
				stmt.executeUpdate("UPDATE myboxdb.user SET status=1 WHERE userName='"+req.getUserID()+"'");
				res.close();
				
				if (admin == 1) return Result.ISADMIN;
				else return Result.ISUSER;
			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
}