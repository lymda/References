package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import entity.Request;
import enums.Result;

// TODO: Auto-generated Javadoc
/**
 * The Class AddUserToGroupDB runs a query to add a user into a group.
 */
public class AddUserToGroupDB {
	
	/**
	 * Exe. - The method addes a record in usergroup table for the specified request.
	 *
	 * @param req the Request Object in Entity - User Name in Entity2 - Group Name
	 * @param con the current user connection to server
	 * @return the Result Object (USERADDEDTOGROUP or USERALLREADYINGROUP).
	 */
	public static Result exe(Request req, Connection con){
		try {
		  
			Result isUserInGroup=SearchUserInGroup.exe(req, con);
			if(isUserInGroup.equals(Result.OK))
			{
				return Result.USERALLREADYINGROUP;
			}
			PreparedStatement addusergroup;
			String updateString ="INSERT INTO myboxdb.usergroup VALUES (?,?)";
			addusergroup=con.prepareStatement(updateString);
			addusergroup.setString(1, (String)req.getEntity());
			addusergroup.setString(2, (String)req.getEntity2());
			addusergroup.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.USERADDEDTOGROUP;
	}
}
