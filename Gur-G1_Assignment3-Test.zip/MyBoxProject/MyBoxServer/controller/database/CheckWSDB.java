package controller.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class CheckWSDB runs a query to check if a specified user has a workspace.
 */
public class CheckWSDB {

	/**
	 * Exe. - The method check if the field workspaceID in table user where userName is the specified user name is Not NULL
	 *
	 * @param req the Request Object with the user name
	 * @param conn the current user connection to server
	 * @return the Result Object (WSEXIST, WSNOTEXIST).
	 */
	public static Object exe(Request req, Connection conn) {
		ResultSet res = null;
		Statement stmt;
		
		try {
			stmt = conn.createStatement();	
			res = stmt.executeQuery("SELECT * FROM myboxdb.user WHERE userName='"+ req.getUserID() +"'"
					+ "AND workspaceID IS NOT NULL");
			
			if (res.next())
			{
				return Result.WSEXIST;
			}
			else return Result.WSNOTEXIST;
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
}