package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

import entity.Request;
import enums.Result;

/**
 * The Class UpdateFileStatusDB runs a query to update a given file status.
 */
public class UpdateFileStatusDB {
    
    /**
     * Exe. - The method sets the given file status field in file table to the given status.
     *
     * @param object the Request Object with file name and status.
     * @param conn the current user connection to server
     * @return the Result Object (OK, ERROR).
     */
    public static Object exe(Object object, Connection conn) {

	Request req = (Request) object;
	String s1 = "UPDATE myboxdb.file SET status=? WHERE fileName=?";

		try {
				PreparedStatement ps = conn.prepareStatement(s1);
				ps.setInt(1,(int)req.getEntity());
				ps.setString(2,req.getUserID());
				ps.executeUpdate();
				return Result.OK;
			}
			catch (Exception e)
			{
				// TODO: handle exception
			}
			return Result.ERROR;
    }
}
