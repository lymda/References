package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mysql.jdbc.ResultSet;

import entity.Request;
import enums.Result;

/**
 * The Class CheckFilePermission runs a query to find a specified file permission.
 */
public class CheckFilePermission {
    
    /**
     * Exe. - The method search in file table a permission for a specified file.
     *
     * @param object the Request Object contain file name.
     * @param conn the current user connection to server
     * @return the specified file permission or Result Object with ERROR.
     */
    public static Object exe(Object object, Connection conn) {

	ResultSet rs = null;
	Request req = (Request) object;
	String s1 = "SELECT permission FROM myboxdb.file WHERE fileName = ?";

			try {
				    PreparedStatement ps = conn.prepareStatement(s1);
				    ps.setString(1, (String) req.getEntity());
				    rs = (ResultSet) ps.executeQuery();
			
				    if (rs.next()) 
				    {
				    	String per=rs.getString(1);
				    	return per;
				    } 
			    else 
			    {
					rs.close();
					return Result.ERROR;
			    }
			} 
			catch (Exception e)
			{
				// TODO: handle exception
			}
			return Result.ERROR;
    }
}
