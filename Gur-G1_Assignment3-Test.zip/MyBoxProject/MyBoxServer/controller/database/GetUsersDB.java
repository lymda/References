package controller.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import entity.Request;

/**
 * The Class GetUsersDB runs a query to resolve all users in the system.
 */
public class GetUsersDB {
	
	/**
	 * Exe. - The method search for all records in user table.
	 *
	 * @param req the Request Object (Unused).
	 * @param con the current user connection to server
	 * @return the String ArrayList of all users in the system.
	 */
	public static ArrayList<String> exe(Request req, Connection con){
		Statement stmt;
		ArrayList<String> users=new ArrayList<String>();
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT userName FROM myboxdb.user;");
			while(rs.next())
				users.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

}
