package controller.database;

import java.sql.Connection;

import entity.Request;
import enums.Command;
import enums.Result;

/**
 * The Class DBController handle requests from client.
 */
public class DBController {

	/**
	 * Handle request. - The method runs a query according to the Command the client sent.
	 *
	 * @param req the Request Object with the desired Command and parameters
	 * @param conn the the current user connection to server
	 * @return the object alter from query to query.
	 */
	public static Object handleRequest(Request req, Connection conn) {

		if (req.getCommand().equals(Command.RECIEVE_FILE_FROM_CLIENT)) 
		{
			return RecieveFileFromClientDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.SEND_FILE_TO_CLIENT)) 
		{
			return FileSendDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.NEWFILE))
		{
			return CreateNewFileDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.NEWGROUP))
		{
			return NewGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.LOGIN))
		{
			return LoginDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.LOGOUT))
		{
			return LogoutDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETEFILEFROMFOLDER))
		{
			return DeleteFileFromFolderDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ADDFILETOFOLDER))
		{
			return AddFileToFolderDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETEFOLDER))
		{
			return DeleteFolderDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHANGEFOLDERNAME))
		{
			return ChangeFolderNameDB.exe(req, conn);
		}
		
		else if (req.getCommand().equals(Command.LOADFILESFOLDERSFORWORKSPACE)){
			return LoadFilesFoldersForWorkspaceDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.LOADFILESFOLDERSFORFOLDER)){
			return LoadFilesFoldersForFolderDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.USERSINGROUP)){
			return GetUsersInGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.USERSNOTINGROUP)){
			return GetUsersNotInGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ALLGROUPS)){
			return GetAllGroups.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ADDUSERTOGROUP)){
			return AddUserToGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.REMOVEUSERFROMGROUP)){
			return RemoveUserFromGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GETAUTHORIZEDFILES)){
			return ViewAuthorizedFilesDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ADDFROMAUTHORIZED)){ 
			return CheckAndAddFromAuthorizedDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHECKWS)){
			return CheckWSDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CREATEWS)){
			return CreateWSDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CREATEPATH)){
			return CreatePathDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.LOADGROUPSUSERNOTIN)){
			return GetGroupsUserIsNotInDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.SHOW_FILE_DETAILS)){
			return ShowFileDetailsDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.LOADGROUPSUSERIN)){
			return GetGroupsUserInDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ADDREQUEST)){
			return AddRequestDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETEREQUEST)){
			return DeleteRequestDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GETALLREQUESTS)){
			return GetAllRequestsDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHECK_FILE_EXISTENCE)){
			return CheckFileExistenceDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.EDIT_FILE_DETAILS)){
			return EditFileDetailsDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHECK_FILE_OWNER)){
			return FileOwnerCheckDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_ROOT_CLIENT_PATH)){
			return GetRootFilePathDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.SENDMESSAGE)){
			return SendMessageDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GETMESSAGESFORUSER)){
			return GetMessagesForUser.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.NEWFOLDER))
		{
			return CreateNewFolderDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_GROUPS_FILE_IN))
		{
			return GetGroupsFileIsIn.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_GROUPS_FILE_NOT_IN))
		{
			return GetGroupsFileNotIn.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_FILE_PERMISSION))
		{
			return CheckFilePermission.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHANGE_FILE_PERMISSION))
		{
			return ChangeFilePermissionDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.ADDFILETOGROUP))
		{
			return AddFileToGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHANGE_FILE_PERMISSION_FOR_GROUP))
		{
			return ChangeFilePermissionForGroup.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_USERS_AUTHORIZED_FOR_FILE))
		{
			return GetUserAuthorizedForFile.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.UPDATE_FILE))
		{
			return RecieveFileFromClientDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.SEND_MESSAGE_TO_USER_RELATED_TO_FILE))
		{
			return SendMessageToUserRelatedToFileDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.REMOVE_FILE_FROM_GROUP))
		{
			return RemoveFileFromGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.SEND_MESSAGE_TO_GROUP))
		{
			return SendMessageToGroupDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GET_FILE_OWNER))
		{
			return GetFileOwnerDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHECK_UPDATE_AUTHORIZATION))
		{
			return CheckIfUserAuthorizedUpdateDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHANGEFILESTATUS))
		{
			return UpdateFileStatusDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETEFILEPERMENANTLY))
		{
			return DeleteFilePermenantlyDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.GETDELETEDFILESOFUSERS))
		{
			return GetDeletetdFilesOfUserDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.CHECK_READ_AUTHORIZATION))
		{
			return CheckIfUserAuthorizedReadDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETEFILEFROMALLGROUPS))
		{
			return RemoveFileFromALLGroupsDB.exe(req, conn);
		}
		else if (req.getCommand().equals(Command.DELETE_MESSAGES_FOR_USER))
		{
			return DeleteMessagesForUser.exe(req, conn);
		}
		else 
		{
			System.out.println("Unknown Command");
			return Result.ERROR;
		}
	}
		
}