package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.FileGroup;
import entity.Request;
import enums.Result;

/**
 * The Class AddFileToGroupDB runs a query to add a file to a group.
 */
public class AddFileToGroupDB {
	
	/**
	 * Exe. - The method added a record in filegroup table for the specified file name and group name.
	 *
	 * @param req the Request Object contains an entity FileGroup (FileName,GroupName,Permission).
	 * @param con the current user connection to server
	 * @return the Result Object (FILEADDEDTOGROUP or ERROR).
	 */
	public static Result exe(Request req, Connection con){
		
		ResultSet rs = null;
		
		try {
			
			FileGroup fg = (FileGroup)req.getEntity();
			
			PreparedStatement checkinfo;
			PreparedStatement updateinfo;
			PreparedStatement addrequest;

			String checkString = "SELECT * FROM myboxdb.filegroup WHERE fileName = ? AND groupName = ?";
			String updateString = "UPDATE myboxdb.filegroup SET permission = ? WHERE fileName = ? AND groupName = ?";
			String insertString = "INSERT INTO myboxdb.filegroup VALUES (?,?,?)";
			
			checkinfo = con.prepareStatement(checkString);
			checkinfo.setString(1, fg.getfileName());
			checkinfo.setString(2, fg.getGroupName());
			rs = checkinfo.executeQuery();
			
			if (rs.next())
			{
				updateinfo = con.prepareStatement(updateString);
				updateinfo.setString(1, fg.getPermission());
				updateinfo.setString(2, fg.getfileName());
				updateinfo.setString(3, fg.getGroupName());
				updateinfo.executeUpdate();
			}
			else
			{
				addrequest=con.prepareStatement(insertString);
				addrequest.setString(1, fg.getfileName());
				addrequest.setString(2, fg.getGroupName());
				addrequest.setString(3, fg.getPermission());
				addrequest.execute();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
		return Result.FILEADDEDTOGROUP;
	}

}
