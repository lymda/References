package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Folder;
import entity.Request;
import enums.Result;


/**
 * The Class CreateNewFolderDB runs a query to create a new folder in a specified folder.
 */
public class CreateNewFolderDB {
	
	/**
	 * Exe. - The method add a record in folder table for the specified new folder and parent folder
	 *
	 * @param object the Request Object with an entity of Folder
	 * @param conn the current user connection to server
	 * @return the Result Object (FOLDEREXIST, ERROR).
	 */
	public static Object exe(Object object, Connection conn) {
		ResultSet res = null;
		Request req = (Request) object;
		Folder f = (Folder) req.getEntity();
		String s1 = "SELECT * FROM myboxdb.folder WHERE folderName=? AND parent=?";
		String s2 = "INSERT INTO myboxdb.folder (folderName, parent) VALUES (?,?)";
		try {
		    PreparedStatement preparedStatement1 = conn.prepareStatement(s1);
		    preparedStatement1.setString(1, f.getFolderName());
		    preparedStatement1.setInt(2, f.getParent());
		    res = preparedStatement1.executeQuery();
		    if (res.next()) {
		    	res.close();
		    	return Result.FOLDEREXIST;
		    }
		    else{
		    	PreparedStatement preparedStatement2 = conn.prepareStatement(s2);
		    	preparedStatement2.setString(1, f.getFolderName());
			    preparedStatement2.setInt(2, f.getParent());
			    preparedStatement2.executeUpdate();
			    return f;
		    }
		    
		} catch (SQLException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		    return Result.ERROR;
		}
	   }
}
