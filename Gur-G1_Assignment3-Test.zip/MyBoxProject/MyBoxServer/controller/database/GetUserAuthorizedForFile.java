package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entity.Request;

/**
 * The Class GetUserAuthorizedForFile runs a query to find all users authorized for a specified file..
 */
public class GetUserAuthorizedForFile {
	
	/**
	 * Exe. - The method search for all users that are member of a group that has permission to the specified file union with the file owner.
	 *
	 * @param req the Request with the file name
	 * @param con the current user connection to server
	 * @return the String ArrayList with users authorized to the specified file.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<String> users=new ArrayList<String>();
		try {
			PreparedStatement searchUsers;
			String searchString ="SELECT DISTINCT userName FROM myboxdb.usergroup WHERE groupName IN (SELECT groupName FROM myboxdb.filegroup WHERE fileName=?) UNION (SELECT fileOwner FROM myboxdb.file WHERE fileName=?)";
			searchUsers=con.prepareStatement(searchString);
			searchUsers.setString(1, req.getUserID());
			searchUsers.setString(2, req.getUserID());
			ResultSet rs=searchUsers.executeQuery();
			while(rs.next())
				users.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

}
