package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import entity.Request;
import enums.Result;

// TODO: Auto-generated Javadoc
/**
 * The Class ChangeFilePermissionDB runs a query to change specified file permission.
 */
public class ChangeFilePermissionDB {
    
    /**
     * Exe. - The method sets a file permission in file table to the specified permission.
     *
     * @param object the Request Object contains UserID-fileName and Entity-permission.
     * @param conn the current user connection to server
     * @return the Result Object (FILEPERMISSIONCHANGED or ERROR).
     */
    public static Object exe(Object object, Connection conn) {

	Request req = (Request) object;
	String s1 = "UPDATE myboxdb.file SET permission=? WHERE fileName=?";

		try {
				PreparedStatement ps = conn.prepareStatement(s1);
				ps.setString(1,(String)req.getEntity());
				ps.setString(2,req.getUserID());
				ps.executeUpdate();
				return Result.FILEPERMISSIONCHANGED;
			}
			catch (Exception e)
			{
				// TODO: handle exception
			}
			return Result.ERROR;
    }
}
