package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

import entity.FileGroup;
import entity.Request;
import enums.Result;

/**
 * The Class ChangeFilePermissionForGroup runs a method to set a new permission for a specified file in group.
 */
public class ChangeFilePermissionForGroup {
    
    /**
     * Exe.- The method update the permission field in filegroup table for the specified file name and group name.
     *
     * @param object the Request Object contains a FileGroup entity for the desired file group and permission.
     * @param conn the current user connection to server
     * @return the Result Object (FILEPERMISSIONCHANGED or ERROR).
     */
    public static Object exe(Object object, Connection conn) {

	Request req = (Request) object;
	String s1 = "UPDATE myboxdb.filegroup SET permission=? WHERE fileName=? AND groupName=?";

		try {
				FileGroup fg=(FileGroup)req.getEntity();
				PreparedStatement ps = conn.prepareStatement(s1);
				ps.setString(1,fg.getPermission());
				ps.setString(2,fg.getfileName());
				ps.setString(3,fg.getGroupName());
				ps.executeUpdate();
				return Result.FILEPERMISSIONCHANGED;
			}
			catch (Exception e)
			{
				// TODO: handle exception
			}
			return Result.ERROR;
    }
}
