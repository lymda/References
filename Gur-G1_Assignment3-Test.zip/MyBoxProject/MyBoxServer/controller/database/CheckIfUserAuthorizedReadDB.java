package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import entity.Request;
import enums.Result;

/**
 * The Class CheckIfUserAuthorizedReadDB runs a query to check if a specified user is authorized to read a specified file.
 */
public class CheckIfUserAuthorizedReadDB {
	
	/**
	 * Exe. - The method checks if the specified user is owner of the specified file or file permission is public or the file is authorized for one of the groups the user is a member of.
	 *
	 * @param req the Request Object with file name and user name.
	 * @param con the current user connection to server
	 * @return the Result Object (READ_APPROVE, READ_NOT_APPROVE).
	 */
	public static Object exe(Request req, Connection con){
		ResultSet rs;
		int approveFlag=0;
		try {
			PreparedStatement searchGroups;
			String searchString ="SELECT fileName FROM myboxdb.file WHERE fileName=? AND (permission='public' OR fileName IN (SELECT fileName FROM myboxdb.filegroup WHERE groupName IN (SELECT groupName FROM myboxdb.usergroup WHERE userName=?)))";
			searchGroups=con.prepareStatement(searchString);
			searchGroups.setString(1, (String)req.getEntity());
			searchGroups.setString(2, req.getUserID());
			rs=searchGroups.executeQuery();
			
			if(rs.next())
			{
				rs.close();
				approveFlag++;
			}

			if((boolean)FileOwnerCheckDB.exe(req, con)==true) {
			    approveFlag++;
			}
			
			if(approveFlag>0) {
			    return Result.READ_APPROVE;
			} else return Result.READ_NOT_APPROVE;
			    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return false;
		return Result.READ_NOT_APPROVE;
	}

}
