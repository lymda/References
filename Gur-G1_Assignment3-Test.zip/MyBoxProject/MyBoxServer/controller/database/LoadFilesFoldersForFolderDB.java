package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.FileFolderID;
import entity.Request;
import enums.Result;

/**
 * The Class LoadFilesFoldersForFolderDB runs a query to resolve all files and folders in a specified folder.
 */
public class LoadFilesFoldersForFolderDB {
	
	/**
	 * Exe. - The method search for the folderID for the specified folder and resolve from filefolder and folder tables all the files and folder in the specified folder.
	 *
	 * @param object the Request Object with the folders array from GUI and the clicked folder.
	 * @param conn the current user connection to server
	 * @return the FileFOlderID object with all folders and files in the specified folder.
	 */
	public static Object exe(Object object, Connection conn){
		ArrayList <String> fileArr= new ArrayList<String>();
		ArrayList <String> folderArr= new ArrayList<String>();
		int folderID;
		ResultSet res1 = null;
		ResultSet res2 = null;	
		ResultSet res3 = null;	
		Request req = (Request) object;	
		String buttonName = req.getUserID();
		ArrayList<Integer> arrInt=(ArrayList<Integer>) req.getEntity();
		int parentID=arrInt.get(arrInt.size()-1);
		
		String query1="SELECT folderID FROM myboxdb.folder WHERE folderName=? AND parent=?;";
		String query2="SELECT fileName FROM  myboxdb.file, myboxdb.filefolder  WHERE myboxdb.file.fileID=myboxdb.filefolder.fileID AND myboxdb.filefolder.folderID=?";
		String query3="SELECT folderName FROM myboxdb.folder WHERE parent=?";
		try{
			PreparedStatement preparedStatement = conn.prepareStatement(query1);
			preparedStatement.setString(1, buttonName);
			preparedStatement.setInt(2, parentID);
			res1=preparedStatement.executeQuery();
			if(res1.next() && res1.getInt(1)!=0){
				folderID=res1.getInt(1);
				res1.close();
				PreparedStatement preparedStatement2 = conn.prepareStatement(query2);
				preparedStatement2.setInt(1, folderID);
				res2=preparedStatement2.executeQuery();
				while(res2.next()){
					fileArr.add(res2.getString(1));
				}
				res2.close();
				PreparedStatement preparedStatement3 = conn.prepareStatement(query3);
				preparedStatement3.setInt(1, folderID);
				res3=preparedStatement3.executeQuery();
				while(res3.next()){
					folderArr.add(res3.getString(1));
				}
				res3.close();
				
				FileFolderID ffid= new FileFolderID(fileArr,folderArr,folderID);
				return ffid;
			}
			else return Result.ERROR;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
		

	}
}
