package controller.database;

import java.sql.Connection;
import java.util.ArrayList;

import entity.Message;
import entity.Request;
import enums.Command;
import enums.Result;

/**
 * The Class SendMessageToUserRelatedToFileDB runs a query to send message to all users related to file.
 */
public class SendMessageToUserRelatedToFileDB {
	
	/**
	 * Exe. - The method search for all users related to file and send them the goven message.
	 *
	 * @param req the Request Object with the file name and Message entity.
	 * @param con the current user connection to server
	 * @return the null.
	 */
	public static Result exe(Request req, Connection con){
			ArrayList<String> users=(ArrayList<String>)GetUserAuthorizedForFile.exe(req, con);
			String message=(String)req.getEntity();
			for(int i=0;i<users.size();i++)
			{
				Message m=new Message(users.get(i),message);
				Request reqMessage=new Request(Command.SENDMESSAGE,users.get(i),m);
				SendMessageDB.exe(reqMessage, con);
			}
			return null;		
	}
}
