	package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import entity.Request;
import enums.Result;

/**
 * The Class CreatePathDB runs a query to set a specified user path for downloaded files.
 */
public class CreatePathDB {

	/**
	 * Exe. - The method update the path field in file table for the specified user
	 *
	 * @param req the Request Object with user name and new path
	 * @param conn the current user connection to server
	 * @return the Result Object (PATHDONE, null)
	 */
	public static Object exe(Request req, Connection conn) {
		
		PreparedStatement ps = null;
		String setpath = "UPDATE myboxdb.user SET path = ? WHERE userName = ?";
		
		try {
			// set path for this user
			ps = conn.prepareStatement(setpath);
			ps.setString(2, req.getUserID());
			ps.setString(1, (String)req.getEntity());
			ps.executeUpdate();
			ps.close();

			return Result.PATHDONE;
			

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
}