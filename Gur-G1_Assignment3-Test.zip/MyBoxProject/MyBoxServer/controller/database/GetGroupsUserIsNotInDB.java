package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entity.Request;

/**
 * The Class GetGroupsUserIsNotInDB runs a query to resolve all groups a specified user is not in.
 */
public class GetGroupsUserIsNotInDB {
	
	/**
	 * Exe. - The method search in group table for all group names that not in the group that the specified user is in.
	 *
	 * @param req the Request Object with user name
	 * @param con the current user connection to server
	 * @return the String ArrayList with the groups names
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<String> groups=new ArrayList<String>();
		try {
			PreparedStatement searchGroups;
			String searchString ="SELECT groupName FROM myboxdb.group WHERE groupName NOT IN (SELECT groupName from myboxdb.usergroup WHERE userName=?)";
			searchGroups=con.prepareStatement(searchString);
			searchGroups.setString(1, req.getUserID());
			ResultSet rs=searchGroups.executeQuery();
			while(rs.next())
				groups.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return groups;
	}

}
