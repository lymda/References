package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.FileGroup;
import entity.Request;
import enums.Result;

/**
 * The Class RemoveFileFromGroupDB runs a query to remove a specified file from a specified group.
 */
public class RemoveFileFromGroupDB {
	
	/**
	 * Exe. - The method delete the record from filegroup where file name and group name is as given.
	 *
	 * @param req the Request Object with file name and group name.
	 * @param con the current user connection to server
	 * @return the Result Object (ERROR, FILE_REMOVED_FROM_GROUP).
	 */
	public static Result exe(Request req, Connection con){
		try {
			FileGroup fg=(FileGroup)req.getEntity();
			PreparedStatement deletefilegroup;
			String updateString ="DELETE FROM myboxdb.filegroup WHERE fileName=? AND groupName=?";
			deletefilegroup=con.prepareStatement(updateString);
			deletefilegroup.setString(1, fg.getfileName());
			deletefilegroup.setString(2, fg.getGroupName());
			deletefilegroup.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
		return Result.FILE_REMOVED_FROM_GROUP;
	}
}
