package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Request;
import enums.Result;

/**
 * The Class RemoveUserFromGroupDB runs a query to remove a specified user from a specified group.
 */
public class RemoveUserFromGroupDB {
	
	/**
	 * Exe. - The method delete from usergroup the record for the given user name and group name.
	 *
	 * @param req the Request Object with user name and group Name.
	 * @param con the current user connection to server
	 * @return the Result Object (ERROR, USERNOTINGROUP, USERREMOVEDFROMGROUP).
	 */
	public static Result exe(Request req, Connection con){
		try {
			Result isUserInGroup=SearchUserInGroup.exe(req, con);
			if(isUserInGroup.equals(Result.ERROR))
			{
				return Result.USERNOTINGROUP;
			}
			PreparedStatement deleteusergroup;
			String updateString ="DELETE FROM myboxdb.usergroup WHERE userName=? AND groupName=?";
			deleteusergroup=con.prepareStatement(updateString);
			deleteusergroup.setString(1, (String)req.getEntity());
			deleteusergroup.setString(2, (String)req.getEntity2());
			deleteusergroup.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.USERREMOVEDFROMGROUP;
	}
}
