package controller.database;

import java.sql.Connection;
import java.util.ArrayList;

import entity.Message;
import entity.Request;
import enums.Command;
import enums.Result;

/**
 * The Class SendMessageToGroupDB run a query to send message to all users in a specified group..
 */
public class SendMessageToGroupDB {
	
	/**
	 * Exe.- The method search for all users in the specified group and add a record for them with a message in message table.
	 *
	 * @param req the Request Object with the group name and a Message entity.
	 * @param con the the current user connection to server
	 * @return the null.
	 */
	public static Result exe(Request req, Connection con){
		ArrayList<String> users=(ArrayList<String>)GetUsersInGroupDB.exe(req, con);
		String message=(String)req.getEntity();
		for(int i=0;i<users.size();i++)
		{
			Message m=new Message(users.get(i),message);
			Request reqMessage=new Request(Command.SENDMESSAGE,users.get(i),m);
			SendMessageDB.exe(reqMessage, con);
		}
		return null;		
}
}
