package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Request;
import entity.Requests;
import enums.Result;

/**
 * The Class DeleteRequestDB runs a query to delete a specified user request.
 */
public class DeleteRequestDB {
	
	/**
	 * Exe. - The method delete the specified request from request table
	 *
	 * @param req the The request Object with requests entity of the specified request to delete
	 * @param con the current user connection to server
	 * @return the Result Object (REQUESTNOTEXISTS, REQUESTREMOVED).
	 */
	public static Result exe(Request req, Connection con){
		Requests request=(Requests)req.getEntity();
		try {
			Result isUserInGroup=CheckRequestExistenceDB.exe(req, con);
			if(isUserInGroup.equals(Result.ERROR))
			{
				return Result.REQUESTNOTEXISTS;
			}
			PreparedStatement deleteuserRequest;
			String deleteString ="DELETE FROM myboxdb.request WHERE userName=? AND groupName=?";
			deleteuserRequest=con.prepareStatement(deleteString);
			deleteuserRequest.setString(1, request.getUserName());
			deleteuserRequest.setString(2, request.getGroupName());
			deleteuserRequest.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.REQUESTREMOVED;
	}
}
