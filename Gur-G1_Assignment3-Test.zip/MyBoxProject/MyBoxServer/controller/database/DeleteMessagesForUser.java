package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import entity.Request;
import enums.Result;

/**
 * The Class DeleteMessagesForUser runs a query to delete all messages for user.
 */
public class DeleteMessagesForUser {
	
	/**
	 * Exe. - The methods delete all records from message table where use is the specified user
	 *
	 * @param object the Request Object with user name
	 * @param conn the current user connection to server
	 * @return the Result Object (OK, ERROR).
	 */
	public static Object exe(Object object, Connection conn){
		Request req = (Request) object;
		try {
			String s1 = "DELETE FROM myboxdb.message WHERE toUserID=?";
			PreparedStatement preparedStatement = conn.prepareStatement(s1);
			preparedStatement.setString(1, req.getUserID());
			preparedStatement.execute();
			return Result.OK;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
	}
}
