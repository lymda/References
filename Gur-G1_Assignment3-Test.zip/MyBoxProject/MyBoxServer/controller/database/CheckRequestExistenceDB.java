package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Request;
import entity.Requests;
import enums.Result;

/**
 * The Class CheckRequestExistenceDB runs a query to check if a specified request already exists.
 */
public class CheckRequestExistenceDB {
	
	/**
	 * Exe. - The method search in request table for the specified Request
	 *
	 * @param req the Requests Object contains the user name and group name.
	 * @param con the current user connection to server
	 * @return the Result Object (IDEXISTS, IDNOTEXIST).
	 */
	public static Result exe(Request req, Connection con){
		ResultSet res = null;
		Requests request=(Requests)req.getEntity();
		try {
			PreparedStatement searchRequest;
			String checkRequestExistence="SELECT requestID FROM myboxdb.request WHERE userName=? AND groupName=?";
			searchRequest=con.prepareStatement(checkRequestExistence);
			searchRequest.setString(1, request.getUserName());
			searchRequest.setString(2, request.getGroupName());
			res=searchRequest.executeQuery();
			if(res.next())
				return Result.IDEXISTS;			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.IDNOTEXIST;
	}
}
