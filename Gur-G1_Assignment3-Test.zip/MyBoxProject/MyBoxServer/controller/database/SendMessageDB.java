package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Message;
import entity.Request;
import enums.Result;

/**
 * The Class SendMessageDB runs a query to send a message from an admin to a specified user.
 */
public class SendMessageDB {
	
	/**
	 * Exe. - The method add a record in message table with the given user and message
	 *
	 * @param req the Request Object with a Message entity.
	 * @param con the current user connection to server
	 * @return the Result Object (ERROR, MESSAGESENT).
	 */
	public static Result exe(Request req, Connection con){
		try {
			PreparedStatement addMessage;
			Message m=(Message)req.getEntity();
			String insertString ="INSERT INTO myboxdb.message VALUES (null,?,?)";
			addMessage=con.prepareStatement(insertString);
			addMessage.setString(1, m.getToUserID());
			addMessage.setString(2, m.getMessage());
			addMessage.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
		return Result.MESSAGESENT;
	}

}
