package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.ResultSet;

import entity.Request;
import enums.Result;

/**
 * The Class GetDeletetdFilesOfUserDB runs a query to resolve all files that has been deleted NOT permanently by a specified user.
 */
public class GetDeletetdFilesOfUserDB
{
    
    /**
     * Exe. - The method resolves all files from file table where the specified user is the owner and status is 0 (Deleted).
     *
     * @param req the Request Object with the user name
     * @param conn the current user connection to server
     * @return the String ArrayList with file names or an ERROR
     */
    public static Object exe(Request req, Connection conn)
    {
		// TODO Auto-generated method stub
    	ArrayList<String> files=new ArrayList<String>();
		ResultSet rs = null;
		String s1 = "SELECT fileName FROM myboxdb.file WHERE fileOwner = ? AND status=0";
		try 
		{
		    PreparedStatement ps = conn.prepareStatement(s1);
		    ps.setString(1, (String) req.getUserID());
		    rs = (ResultSet) ps.executeQuery();
		    while(rs.next())
		    	files.add(rs.getString(1));
		    return files;
	    }
		catch (SQLException e)
		{
		// TODO Auto-generated catch block
		e.printStackTrace();
		return Result.ERROR;
		}
    }
}
