package controller.database;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;

import server.ServerSession;
import entity.Request;

/**
 * The Class FileSendDB runs a set of operations to send a file.
 */
public class FileSendDB {

    /**
     * Exe. - The method converts the specified file from the server files root to bytes array.
     *
     * @param req the Request Object with file name
     * @param conn the current user connection to server
     * @return the File Object
     */
    public static Object exe(Request req, Connection conn) {
	// TODO Auto-generated method stub

	String fileName = (String) req.getEntity();
	entity.File msg = new entity.File("", fileName, "",  "", 0);  

	try {

	    final File newFile = new File(ServerSession.getFilesRoot() + "\\"+ fileName);
	    synchronized (newFile) {

		byte[] myByteArray = new byte[(int) newFile.length()];
		System.out.println((int) newFile.length());

		FileInputStream fis = new FileInputStream(newFile);
		BufferedInputStream bis = new BufferedInputStream(fis);

		msg.initialArray(myByteArray.length);
		msg.setSize(myByteArray.length);
		bis.read(msg.getMyByteArray(), 0, myByteArray.length);

		fis.close();
		bis.close();
	    }

	    System.out.println(ServerSession.getFilesRoot() + "\\"
		    + fileName);
	    System.out.println("File "+newFile+" sent");

	    return msg;

	} catch (Exception e) {
	    System.out.println("Error send (Files)msg) from Server");
	}
	return null;


    }

}
