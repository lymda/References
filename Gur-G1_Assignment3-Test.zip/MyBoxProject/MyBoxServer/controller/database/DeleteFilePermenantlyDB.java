package controller.database;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import server.ServerSession;
import entity.Request;
import enums.Result;

/**
 * The Class DeleteFilePermenantlyDB runs a query to delete a specified file permanently.
 */
public class DeleteFilePermenantlyDB {
	
	/**
	 * Exe. - The method deletes a specified file from all groups' all folders and from file table
	 *
	 * @param object the Request Object with file name
	 * @param conn the current user connection to server
	 * @return the Result Object (OK, ERROR).
	 */
	public static Object exe(Object object, Connection conn){
		ResultSet res1 = null;
		Statement stmt;
		Request req = (Request) object;
		int fileID;
		try {
			String s1 = "SELECT fileID FROM myboxdb.file WHERE fileName = ?";
			String s2 = "DELETE FROM myboxdb.filefolder WHERE fileID=?";
			String s3 = "DELETE FROM myboxdb.filegroup WHERE fileName=?";
			String s4 = "DELETE FROM myboxdb.file WHERE fileName=?";
			PreparedStatement preparedStatement = conn.prepareStatement(s1);
			preparedStatement.setString(1, req.getUserID());
			res1=preparedStatement.executeQuery();
			if(res1.next()){
				fileID=res1.getInt(1);
				res1.close();
				PreparedStatement preparedStatement2 = conn.prepareStatement(s2);
				preparedStatement2.setInt(1, fileID);
				preparedStatement2.executeUpdate();
				
				PreparedStatement preparedStatement3 = conn.prepareStatement(s3);
				preparedStatement3.setString(1, req.getUserID());
				preparedStatement3.executeUpdate();
				
				PreparedStatement preparedStatement4 = conn.prepareStatement(s4);
				preparedStatement4.setString(1, req.getUserID());
				preparedStatement4.executeUpdate();  			

    			String serverRootPath = ServerSession.getFilesRoot() + "\\" + req.getUserID();
				File f=new File(serverRootPath);
				f.delete();
				
				return Result.OK;
			}
				return Result.ERROR;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
	}
}
