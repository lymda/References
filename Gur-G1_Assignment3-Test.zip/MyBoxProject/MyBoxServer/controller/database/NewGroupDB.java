package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class NewGroupDB runs a query to add a new group to the system.
 */
public class NewGroupDB {
	
	/**
	 * Exe. - The method check that the given group dosnt already exists and add a record in group table for the specified group name.
	 *
	 * @param req the Request Object with the group name.
	 * @param con the current user connection to server
	 * @return the Result Object (GROUPEXISTS, GROUPADDED).
	 */
	public static Result exe(Request req, Connection con){
		try {
			Statement stmt;
			if(req.getUserID().isEmpty())
		    	    return Result.ERROR;
			if(CheckGroupExistenceDB.exe(req, con)==Result.IDEXISTS)
			{
				return Result.GROUPEXISTS;
			}
			PreparedStatement addgroup;
			String updateString ="INSERT INTO myboxdb.group VALUES (?)";
			addgroup=con.prepareStatement(updateString);
			stmt = con.createStatement();
			addgroup.setString(1, req.getUserID());
			addgroup.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.GROUPADDED;
	}
}
