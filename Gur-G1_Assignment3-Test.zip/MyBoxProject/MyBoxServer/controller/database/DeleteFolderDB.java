package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import entity.Folder;
import entity.Request;
import enums.Result;

/**
 * The Class DeleteFolderDB runs a query to delete an empty folder.
 */
public class DeleteFolderDB {
	
	/**
	 * Exe. - The method search for the specified folder ID, checks that the folder is empty and delete the folder from folder table.
	 *
	 * @param object the Request Object with folder entity
	 * @param conn the current user connection to server
	 * @return the Result Object (ERROR, FOLDERISFULL, FOLDERDELETED).
	 */
	public static Object exe(Object object, Connection conn){
		ResultSet res = null, res1 = null, res2=null;
		Request req = (Request) object;
		Folder folder = (Folder) req.getEntity();
		try {
			String s = "SELECT folderID FROM myboxdb.folder WHERE folderName=? AND parent=?";
			String s1 = "SELECT * FROM myboxdb.filefolder WHERE folderID = ?";
			String s2 = "SELECT * FROM myboxdb.folder WHERE parent=?";
			
			PreparedStatement preparedStatement = conn.prepareStatement(s);
			preparedStatement.setString(1, folder.getFolderName());
			preparedStatement.setInt(2, folder.getParent());
			res=preparedStatement.executeQuery();
			if(res.next())
				folder.setFolderID(res.getInt(1));
			else return Result.ERROR;
			PreparedStatement preparedStatement1 = conn.prepareStatement(s1);
			preparedStatement1.setInt(1, folder.getFolderID());
			res1=preparedStatement1.executeQuery();
			
			PreparedStatement preparedStatement2 = conn.prepareStatement(s2);
			preparedStatement2.setInt(1, folder.getFolderID());
			res2=preparedStatement2.executeQuery();
			if(res1.next() || res2.next()){
				res1.close();
				res2.close();
				return Result.FOLDERISFULL;
			}
			else{
				String s3 = "DELETE FROM myboxdb.folder WHERE folderID=?";
				
				PreparedStatement preparedStatement3 = conn.prepareStatement(s3);
				preparedStatement3.setInt(1, folder.getFolderID());
				preparedStatement3.executeUpdate();
				
				return Result.FOLDERDELETED;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
	}
}
