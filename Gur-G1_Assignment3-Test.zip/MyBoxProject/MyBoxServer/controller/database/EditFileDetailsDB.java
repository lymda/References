package controller.database;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import server.ServerSession;
import entity.FileDetails;
import entity.Request;
import enums.Result;

/**
 * The Class EditFileDetailsDB runs a query to update file details.
 */
public class EditFileDetailsDB {

    /**
     * Exe. - The method runs a set of queries to update a file's details by the specified FileDetails Object
     *
     * @param object the Request Object with an entity of FileDetails
     * @param conn the current user connection to server
     * @return the Result Object (OK, ERROR).
     */
    public static Object exe(Object object, Connection conn) {

	Statement stmt = null;
	ResultSet rs = null;
	String s1 = "", s2;
	Request req = (Request) object;
	FileDetails details = (FileDetails) req.getEntity();
	int fileId = 0;
	s2 = "SELECT * FROM myboxdb.file WHERE fileName='"
		+ details.oldFileName + "';";

	try {
	    stmt = conn.createStatement();
	    rs = stmt.executeQuery(s2);
	    if (rs.next()) {
		fileId = rs.getInt(1);
		System.out.println(fileId);
	    }
	    rs.close();
	    if (details.nameFlag == 1 && details.discriptionFlag == 1) {

		s1 = "UPDATE myboxdb.file SET fileName='" + details.fileName
			+ "', description='" + details.description + "'"
			+ " WHERE fileID='" + fileId + "';";

	    } else if (details.nameFlag == 1 && details.discriptionFlag == 0) {

		s1 = "UPDATE myboxdb.file SET fileName='" + details.fileName
			+ "' WHERE fileID='" + fileId + "';";
		;

	    } else if (details.nameFlag == 0 && details.discriptionFlag == 1) {

		s1 = "UPDATE myboxdb.file SET description='"
			+ details.description + "'" + " WHERE fileID='"
			+ fileId + "';";
	    }

	    stmt = conn.createStatement();
	    stmt.executeUpdate(s1);
	    
	    String oldFilePath = ServerSession.getFilesRoot()+"\\"+details.oldFileName;
	    File newFilePath = new File(ServerSession.getFilesRoot()+"\\"+details.fileName);

	    File oldFile = new File(oldFilePath);
	    
	    oldFile.renameTo(newFilePath);
	    
	    
	    
	    
	    return Result.OK;
	} catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	    return Result.ERROR;
	}
    }
}
