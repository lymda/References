package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Request;

/**
 * The Class GetGroupsFileNotIn runs a query to resolve all the groups a specified file is not in.
 */
public class GetGroupsFileNotIn {
	
	/**
	 * Exe. - The method search form all the groups in group table that not in the groups the specified file is in.
	 *
	 * @param req the Request Object with the file name
	 * @param con the current user connection to server
	 * @return the Group ArrayList of all the groups the specified file is not in.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<String> groups=new ArrayList<String>();
		try {
			PreparedStatement searchGroups;
			String searchString ="SELECT groupName from myboxdb.group WHERE groupName NOT IN (SELECT groupName FROM myboxdb.filegroup WHERE fileName=?)";
			searchGroups=con.prepareStatement(searchString);
			searchGroups.setString(1, (String)req.getEntity());
			ResultSet rs=searchGroups.executeQuery();
			while(rs.next())
				groups.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return groups;
	}

}
