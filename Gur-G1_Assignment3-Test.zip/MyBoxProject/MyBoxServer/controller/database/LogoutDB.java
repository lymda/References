package controller.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class LogoutDB runs a query to logout a specified user.
 */
public class LogoutDB {

	/**
	 * Exe. - The method sets the status of the given user in user table to 0.
	 *
	 * @param req the Request Object with user name.
	 * @param conn the current user connection to server
	 * @return the Result Object (LOOGEDOUT or null).
	 */
	public static Object exe(Request req, Connection conn) {
		Statement stmt;
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate("UPDATE myboxdb.user SET status=0 WHERE userName='"+req.getUserID()+"'");
			return Result.LOGGEDOUT;

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
}