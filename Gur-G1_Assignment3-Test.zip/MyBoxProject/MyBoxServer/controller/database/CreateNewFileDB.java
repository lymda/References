package controller.database;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import server.ServerSession;
import client.MyBoxMain;
import entity.File;
import entity.Request;
import enums.Result;

/**
 * The Class CreateNewFileDB runs a set of queries to add file to a folder and group.
 */
public class CreateNewFileDB {
	
    /**
     * Exe. - The method checks if the file already exists and if not add him to the specified folder and group
     *
     * @param object the Request Object with File Object and user name
     * @param conn the current user connection to server
     * @return the Result Object (FILEEXIST, FILENOTEXIST, ERROR).
     */
    public static Object exe(Object object, Connection conn) {

    	ResultSet res = null;
    	ResultSet res2 = null;
    	Request req = (Request) object;
    	File f = (File) req.getEntity();
	
    	String insert_details = "INSERT INTO myboxdb.file (fileName, description, permission, fileOwner) VALUES (?,?,?,?)";
    	String file_exist = "SELECT * FROM myboxdb.file WHERE fileName = ?";
    	String insert_filefolder = "INSERT INTO myboxdb.filefolder (fileID, folderID) VALUES (?,?)";
    	String get_file_id = "SELECT fileID FROM myboxdb.file WHERE fileName = ?";
    	String insert_filegroup = "INSERT INTO myboxdb.filegroup (fileName, groupName, permission) VALUES (?,?,?)";

    	try {
    		
    		PreparedStatement preparedStatement = conn.prepareStatement(file_exist);
    		preparedStatement.setString(1, f.getFileName());
    		res = preparedStatement.executeQuery();
    		
    		if (res.next())
    		{
    			return Result.FILEEXIST;
    		}

    		PreparedStatement preparedStatement2 = conn.prepareStatement(insert_details);
    		preparedStatement2.setString(1, f.getFileName());
    		preparedStatement2.setString(2, f.getDescription());
    		preparedStatement2.setString(3, f.getPermissionRate());		// insert main permissiom
    		preparedStatement2.setString(4, f.getFileOwner());
    		preparedStatement2.executeUpdate();

    		PreparedStatement preparedStatement3 = conn.prepareStatement(get_file_id);
    		preparedStatement3.setString(1, f.getFileName());
    		res2 = preparedStatement3.executeQuery();
    		
    		if (res2.next())
    		{
    			f.setFileID(res2.getInt(1));
    			PreparedStatement preparedStatement4 = conn.prepareStatement(insert_filefolder);
    			preparedStatement4.setInt(1, f.getFileID());
    			preparedStatement4.setInt(2, f.getFolderID());
    			preparedStatement4.executeUpdate();
    			res.close();
    			res2.close();

    			if (f.getPermissionList().get(0).equalsIgnoreCase("group"))
    			{
    				PreparedStatement searchGroups;
    				String searchString = "SELECT groupName FROM myboxdb.usergroup WHERE userName = ?";
    				searchGroups = conn.prepareStatement(searchString);
    				searchGroups.setString(1, req.getUserID());
    				ResultSet rs3 = searchGroups.executeQuery();
    				while(rs3.next())									// insert groups to the list
    				{
    					f.getPermissionList().add(rs3.getString(1));
    					f.getPermissionList().add("read");
    				}
    				rs3.close();

    				for (int i=1; i<f.getPermissionList().size(); i=i+2)	// insert filegroup details from list
    				{
    					PreparedStatement preparedStatement5 = conn.prepareStatement(insert_filegroup);
    					preparedStatement5.setString(1, f.getFileName());
    					preparedStatement5.setString(2, f.getPermissionList().get(i));
    					preparedStatement5.setString(3, f.getPermissionList().get(i+1));
    					preparedStatement5.executeUpdate();    			
    				}
    			}

    			FileOutputStream fos = null;
    			entity.File file = (entity.File) req.getEntity();

    			try {

    				String serverRootPath = ServerSession.getFilesRoot() + "\\" + file.getFileName();

    				fos = new FileOutputStream(serverRootPath);
    				fos.write(file.getMyByteArray());
    				fos.close();

    			} catch (IOException ex) {
    				ex.printStackTrace();
    				System.err.println("Client error. Connection closed.");
    			}

    			System.out.println("Message received: " + object + " from " + MyBoxMain.client);
    			System.out.println(file.getFileName() + " in lentgh of" + file.getSize());
    		}
    		return Result.FILENOTEXIST;

    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    		return Result.ERROR;
    	}
    }
}
