package controller.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;

/**
 * The Class GetRootFilePathDB runs a query to resolve a specified user root path.
 */
public class GetRootFilePathDB {
    
    /**
     * Exe. - The method search in user table for the specified user record to resolve his root file path
     *
     * @param req the Request Object with the user name.
     * @param con the current user connection to server
     * @return the String with the specified user's root file path or null.
     */
    public static Object exe(Request req, Connection con){
	
	Statement stmt;
	try {
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT path FROM myboxdb.user WHERE userName='"+req.getUserID()+"';");
		if(rs.next()) {
		    String path=rs.getString(1);
		    return path;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return null;
	
    }
}
