package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Reply;
import entity.Request;
import enums.Command;
import enums.Result;

/**
 * The Class GetUsersInGroupDB runs a query to resolve all users member of a specified group.
 */
public class GetUsersInGroupDB {

	/**
	 * Exe. - The method search on usergroup table for all users that has record for the specified group name.
	 *
	 * @param req the Request Object with group name.
	 * @param con the current user connection to server
	 * @return the String ArrayList of all users that are member pf the specified group.
	 */
	public static Object exe(Request req, Connection con){
		Reply rep;
		ArrayList<String> users=new ArrayList<String>();
		try {
			if(CheckGroupExistenceDB.exe(req, con)!=Result.IDEXISTS)
			{
				rep=new Reply(null,Command.ERROR);
				return rep;
			}
			PreparedStatement searchUsers;
			String searchString ="SELECT userName FROM myboxdb.usergroup WHERE groupName=?";
			searchUsers=con.prepareStatement(searchString);
			searchUsers.setString(1, req.getUserID());
			ResultSet rs=searchUsers.executeQuery();
			while(rs.next())
				users.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}
	
}
