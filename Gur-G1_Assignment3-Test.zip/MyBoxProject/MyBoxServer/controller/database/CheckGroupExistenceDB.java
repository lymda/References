package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class CheckGroupExistenceDB runs a query to check if a specified group name exists.
 */
public class CheckGroupExistenceDB {
	
	/**
	 * Exe. - The method search in group table for the specified group name.
	 *
	 * @param req the Request Object with the group name.
	 * @param con the current user connection to server
	 * @return the Result Object (IDEXISTS or IDNOTEXIST).
	 */
	public static Result exe(Request req, Connection con){
		ResultSet res = null;
		Statement stmt;
		try {
			PreparedStatement searchGroup;
			String checkFileExistence="SELECT groupName FROM myboxdb.group WHERE groupName=?";
			searchGroup=con.prepareStatement(checkFileExistence);
			stmt = con.createStatement();
			searchGroup.setString(1, req.getUserID());
			res=searchGroup.executeQuery();
			if(res.next())
				return Result.IDEXISTS;			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.IDNOTEXIST;
	}
	
}
