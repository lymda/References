package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Request;

/**
 * The Class GetAllGroups - runs a query to resolve all groups in the system.
 */
public class GetAllGroups {
	
	/**
	 * Exe. - The method resolves all group names from group table
	 *
	 * @param req the Request Object (Unused)
	 * @param con the current user connection to server
	 * @return the String ArrayList of groups in the system.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<String> groups=new ArrayList<String>();
		try {
			PreparedStatement searchUsers;
			String searchString ="SELECT groupName FROM myboxdb.group";
			searchUsers=con.prepareStatement(searchString);
			ResultSet rs=searchUsers.executeQuery();
			while(rs.next())
				groups.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return groups;
	}

}
