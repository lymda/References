package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import entity.Request;
import enums.Result;

/**
 * The Class CheckAndAddFromAuthorizedDB runs a query to add an authorized file to the user's workspace.
 */
public class CheckAndAddFromAuthorizedDB {

	/**
	 * Exe. - The method add the file to the user's workspace and add's a record in filefolder table.
	 *
	 * @param req the Request Object contain the userID and the fileID.
	 * @param conn the current user connection to server
	 * @return the Result Object (FILEWITHTHESAMENAME, FILEHASBEENADDEDTOMAINWS or ERROR).
	 */
	public static Object exe(Request req, Connection conn) {

		ResultSet rs1 = null;
		ResultSet rs2 = null;

		try {

			PreparedStatement searchWSofUser;
			String searchstr1 = "SELECT user.workspaceID FROM myboxdb.user WHERE userName = ?";
			searchWSofUser = conn.prepareStatement(searchstr1);
			searchWSofUser.setString(1, req.getUserID());
			rs1 = searchWSofUser.executeQuery();
			if (rs1.next()){
				int ws = rs1.getInt(1);
				rs1.close();
				
				PreparedStatement searchfiles;
				String searchstr2 = "SELECT * FROM myboxdb.filefolder WHERE fileID = ? AND folderID = ?";
				searchfiles = conn.prepareStatement(searchstr2);
				int id= (int) req.getEntity();
				searchfiles.setInt(1, id);
				searchfiles.setInt(2, ws);
				rs2 = searchfiles.executeQuery();
				
				if (rs2.next()) 
				{
					rs2.close();
					return Result.FILEWITHTHESAMENAME;
				}
				else
				{
					PreparedStatement insertfiletofolder;
					String searchstr3 = "INSERT INTO myboxdb.filefolder (fileID, folderID) VALUES (?,?)";
					insertfiletofolder = conn.prepareStatement(searchstr3);
					insertfiletofolder.setInt(1, (int) req.getEntity());
					insertfiletofolder.setInt(2, ws);
					insertfiletofolder.executeUpdate();
					return Result.FILEHASBEENADDEDTOMAINWS;
				}

			}
			else return Result.ERROR;
			

		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
}
