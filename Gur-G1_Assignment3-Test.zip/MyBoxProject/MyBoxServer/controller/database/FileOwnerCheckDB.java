package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mysql.jdbc.ResultSet;

import entity.Request;

/**
 * The Class FileOwnerCheckDB runs a query to check if a specified user is the owner of a specified file.
 */
public class FileOwnerCheckDB {

    /**
     * Exe. - The method search for the specified file owner in file table and checks if it equals to the specified user.
     *
     * @param req the Request Object with file name and user name
     * @param conn the current user connection to server
     * @return true or false
     */
    public static Object exe(Request req, Connection conn) {
	// TODO Auto-generated method stub
	ResultSet rs = null;
	String s1 = "SELECT * FROM myboxdb.file WHERE fileName = ?";
	String fileOwner = "";
	try {
	    PreparedStatement ps = conn.prepareStatement(s1);
	    ps.setString(1, (String) req.getEntity());
	    rs = (ResultSet) ps.executeQuery();

	    if (rs.next()) {
		fileOwner = rs.getString(5);
		rs.close();
		if (fileOwner.compareTo(req.getUserID()) == 0)
		    return true;
		else
		    return false;
	    }

	} catch (Exception e) {
	    // TODO: handle exception
	}
	return false;
    }

}
