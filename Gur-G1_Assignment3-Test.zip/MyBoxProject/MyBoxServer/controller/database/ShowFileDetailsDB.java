package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Request;
import enums.Result;

/**
 * The Class ShowFileDetailsDB runs a query to resolve all given file details.
 */
public class ShowFileDetailsDB {

    /**
     * Exe. - the method resolve all data of the given file name from file table.
     *
     * @param object the Request Object with the file name.
     * @param conn the current user connection to server
     * @return the String ArrayList with all given file details or FAILED.
     */
    public static Object exe(Object object, Connection conn) {

	Request req = (Request) object;
	ArrayList<String> details = new ArrayList<String>();
	try {
	    PreparedStatement ps;
	    String str = "SELECT * FROM myboxdb.file WHERE fileName=?;";
	    ps = conn.prepareStatement(str);
	    ps.setString(1, req.getUserID());
	    ResultSet rs = null;
	    rs= ps.executeQuery();
	    if (rs.next()) {

		details.add(rs.getString(2));
		details.add(rs.getString(3));
		details.add(rs.getString(4));
		details.add(rs.getString(5));

		rs.close();
		return details;
	    }

	} catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return Result.FAILED;

    }
}
