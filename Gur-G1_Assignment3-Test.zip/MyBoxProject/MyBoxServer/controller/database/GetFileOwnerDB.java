package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mysql.jdbc.ResultSet;

import entity.Request;

/**
 * The Class GetFileOwnerDB runs a query to resolve a specified file owner.
 */
public class GetFileOwnerDB {
    
    /**
     * Exe. - The method search in file table the owner of the specified file.
     *
     * @param req the Request Object with file name.
     * @param conn the current user connection to server
     * @return the owner user name.
     */
    public static Object exe(Request req, Connection conn) {
		// TODO Auto-generated method stub
		ResultSet rs = null;
		String s1 = "SELECT fileOwner FROM myboxdb.file WHERE fileName = ?";
		String fileOwner = "";
		try {
		    PreparedStatement ps = conn.prepareStatement(s1);
		    ps.setString(1, (String) req.getUserID());
		    rs = (ResultSet) ps.executeQuery();
	
		    if (rs.next()) {
		    	fileOwner = rs.getString(1);
			rs.close();
			return fileOwner;
		    }
	
		} catch (Exception e) {
		    // TODO: handle exception
		}
		return fileOwner;
    }
}
