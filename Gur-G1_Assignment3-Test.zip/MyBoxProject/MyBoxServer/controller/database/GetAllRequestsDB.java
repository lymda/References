package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import entity.Request;
import entity.Requests;

/**
 * The Class GetAllRequestsDB runs a query to resolve all the requests in the system.
 */
public class GetAllRequestsDB {
	
	/**
	 * Exe. - The method resolves all the requests details from request table.
	 *
	 * @param req the Request Object (Unused).
	 * @param con the current user connection to server
	 * @return the Requests ArrayList with all requests details in the system.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<Requests> requests_arr=new ArrayList<Requests>();
		try {
			PreparedStatement searchRequests;
			String searchString ="SELECT * FROM myboxdb.request";
			searchRequests=con.prepareStatement(searchString);
			ResultSet rs=searchRequests.executeQuery();
			while(rs.next())
			{
				Requests req1=new Requests(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
				requests_arr.add(req1);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return requests_arr;
	}
}
