package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.mysql.jdbc.ResultSet;

import entity.Request;

/**
 * The Class CheckFileExistenceDB runs a query to check if a specified file name exists.
 */
public class CheckFileExistenceDB {

    /**
     * Exe. - The method runs a query to retrive a file name from file table.
     *
     * @param object the Request Object contain the file name.
     * @param conn the current user connection to server
     * @return the Result Object (true or false).
     */
    public static Object exe(Object object, Connection conn) {

	ResultSet rs = null;
	Request req = (Request) object;
	String s1 = "SELECT * FROM myboxdb.file WHERE fileName = ?";

	try {
	    PreparedStatement ps = conn.prepareStatement(s1);
	    ps.setString(1, (String) req.getEntity());
	    rs = (ResultSet) ps.executeQuery();

	    if (rs.next()) {
		rs.close();
		return true;
	    } else {
		rs.close();
		return false;
	    }

	} catch (Exception e) {
	    // TODO: handle exception
	}
	return false;
    }
}
