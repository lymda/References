package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import entity.Request;
import enums.Result;

/**
 * The Class CheckIfUserAuthorizedUpdateDB runs a query to check if a specified user is authorized to update a specified file.
 */
public class CheckIfUserAuthorizedUpdateDB {
	
	/**
	 * Exe. - The method check if the specified user is file owner or the specified user is in a group that has an update permission to the specified file.
	 *
	 * @param req the Request entity contain the user name and file name.
	 * @param con the current user connection to server
	 * @return the Result object (UPDATE_APPROVE, UPDATE_NOT_APPROVE);
	 */
	public static Object exe(Request req, Connection con){
		ResultSet rs;
		int approveFlag=0;
		try {
			PreparedStatement searchGroups;
			String searchString ="SELECT fileName FROM myboxdb.file WHERE fileName=? AND (fileOwner=? OR fileName IN (SELECT fileName FROM myboxdb.filegroup WHERE permission='update' AND groupName IN (SELECT groupName FROM myboxdb.usergroup WHERE userName=?)))";
			searchGroups=con.prepareStatement(searchString);
			searchGroups.setString(1, (String)req.getEntity());
			searchGroups.setString(2, req.getUserID());
			searchGroups.setString(3, req.getUserID());
			rs=searchGroups.executeQuery();
			
			if(rs.next())
			{
				rs.close();
				approveFlag++;
			}

			if((boolean)FileOwnerCheckDB.exe(req, con)==true) {
			    approveFlag++;
			}
			
			if(approveFlag>0) {
			    return Result.UPDATE_APPROVE;
			} else return Result.UPDATE_NOT_APPROVE;
			    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.UPDATE_NOT_APPROVE;
	}

}
