package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.File;
import entity.Request;
import enums.Result;

/**
 * The Class ViewAuthorizedFilesDB runs a query to resolve all files a specified user is authorized to watch.
 */
public class ViewAuthorizedFilesDB
{

	/**
	 * Exe. - The method search for all files that the given user own or their permission is public or the given user is a member of a group that has permission to the file.
	 *
	 * @param req the Request Object with user name.
	 * @param conn the current user connection to server
	 * @return the File ArrayList with all details of the authorized files or ERROR.
	 */
	public static Object exe(Request req, Connection conn)
	{

		ArrayList<File> filesar = new ArrayList<File>();
		String user = req.getUserID();
		
		try
		{
			PreparedStatement searchdetails;
			String searchString3 = "SELECT fileID, fileName, description, permission, fileOwner FROM myboxdb.file WHERE permission='public' OR fileOwner=? OR fileName IN (SELECT fileName FROM myboxdb.filegroup WHERE groupName IN (SELECT groupName FROM myboxdb.usergroup WHERE userName=?))";
			searchdetails = conn.prepareStatement(searchString3);
			searchdetails.setString(1, user);
			searchdetails.setString(2, user);
			ResultSet rs3 = searchdetails.executeQuery();

			while(rs3.next())
			{
				entity.File newfile = new entity.File (rs3.getInt(1), rs3.getString(2), rs3.getString(3), rs3.getString(4), rs3.getString(5), true, 0);
				filesar.add(newfile);
			}
		}
		catch (SQLException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return Result.ERROR;
		}
		return filesar;
	}
}