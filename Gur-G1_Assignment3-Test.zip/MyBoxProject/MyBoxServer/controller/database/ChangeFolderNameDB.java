package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Folder;
import entity.Request;
import enums.Result;

/**
 * The Class ChangeFolderNameDB runs a query to change a specified folder's name.
 */
public class ChangeFolderNameDB {
	
	/**
	 * Exe.- The method update the folder name in folder table.
	 *
	 * @param object the Request Object contains the Folder entity, the new Name String and the folder's GUI button.
	 * @param conn the current user connection to server
	 * @return the Result Object (FOLDERNAMEEXIST or FOLDERNAMECHANGED or ERROR).
	 */
	public static Object exe(Object object, Connection conn) {
		ResultSet res = null;
		Request req = (Request) object;
		Folder f = (Folder) req.getEntity();
		String newName=req.getUserID();

		String s = "UPDATE myboxdb.folder SET folderName=? WHERE folderName=? AND parent=?";
		String s2= "SELECT * FROM myboxdb.folder WHERE folderName=? AND parent=?";
		try {
			
			PreparedStatement preparedStatement2 = conn.prepareStatement(s2);
		    preparedStatement2.setString(1, newName);
		    preparedStatement2.setInt(2, f.getParent());
		    res= preparedStatement2.executeQuery();
		    if(res.next()){
		    	res.close();
		    	return Result.FOLDERNAMEEXIST;
		    }
		    else{
		        res.close();
			    
			    PreparedStatement preparedStatement = conn.prepareStatement(s);
			    preparedStatement.setString(1, newName);
			    preparedStatement.setString(2, f.getFolderName());
			    preparedStatement.setInt(3, f.getParent());
			    preparedStatement.executeUpdate();
			    return Result.FOLDERNAMECHANGED;
		    }
		

		} catch (SQLException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		    return Result.ERROR;
		}
	    }
}
