package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class DeleteFileFromFolderDB runs a query to delete a specified file from a specified folder.
 */
public class DeleteFileFromFolderDB {
		
		/**
		 * Exe. - The method delete a record from filefolder table for the specified file and folder
		 *
		 * @param object the Request Object with file name and folder id
		 * @param conn the current user connection to server
		 * @return the Result Object (OK, ERROR).
		 */
		public static Object exe(Object object, Connection conn){
			ResultSet res1 = null;
			Statement stmt;
			Request req = (Request) object;
			int fileID;
			try {
				String s1 = "SELECT fileID FROM myboxdb.file WHERE fileName = ?";
				String s2 = "DELETE FROM myboxdb.filefolder WHERE fileID=? AND folderID=?";
				PreparedStatement preparedStatement = conn.prepareStatement(s1);
				preparedStatement.setString(1, req.getUserID());
				res1=preparedStatement.executeQuery();
				if(res1.next()){
					fileID=res1.getInt(1);
					res1.close();
					PreparedStatement preparedStatement2 = conn.prepareStatement(s2);
					preparedStatement2.setInt(1, fileID);
					preparedStatement2.setInt(2, (int)req.getEntity());
					preparedStatement2.executeUpdate();
					return Result.OK;
				}
					return Result.ERROR;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return Result.ERROR;
			}
		}
	
}


