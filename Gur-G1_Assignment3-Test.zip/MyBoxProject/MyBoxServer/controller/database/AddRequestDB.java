package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import entity.Request;
import entity.Requests;
import enums.Result;

/**
 * The Class AddRequestDB runs a query to add a request from user to join\leave a group.
 */
public class AddRequestDB {
	
	/**
	 * Exe. - The method adds a record in request table for the desired request.
	 *
	 * @param req the Request Object contains the request details (userName, groupName, type).
	 * @param con the current user connection to server
	 * @return the Result Object (REQUESTADDED or ERROR).
	 */
	public static Result exe(Request req, Connection con){
		Requests request=(Requests)req.getEntity();
		try {
			if(CheckRequestExistenceDB.exe(req, con)==Result.IDEXISTS)
			{
				return Result.REQUESTEXISTS;
			}
			PreparedStatement addrequest;
			String updateString ="INSERT INTO myboxdb.request VALUES (NULL,?,?,?)";
			addrequest=con.prepareStatement(updateString);
			addrequest.setString(1, request.getUserName());
			addrequest.setString(2, request.getGroupName());
			addrequest.setString(3, request.getType());
			addrequest.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return Result.ERROR;
		}
		return Result.REQUESTADDED;
	}
}
