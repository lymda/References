	package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Request;
import enums.Result;

/**
 * The Class CreateWSDB runs a query to create a new workspace for a specified user..
 */
public class CreateWSDB {

	/**
	 * Exe. - The method add a new workspace root folder for the specified user and update workspaceID filed for this user in user table to the new folder id.
	 *
	 * @param req the Request Object with user name
	 * @param conn the current user connection to server
	 * @return the Result Object (WSHASBEENCREATED, WSCREATIONERROR).
	 */
	public static Object exe(Request req, Connection conn) {
		
		ResultSet res_getFolderID = null;
		PreparedStatement ps1 = null, ps2 = null;
		int folID;
		
		String setFolder = "INSERT INTO myboxdb.folder (folderName, parent) VALUES (?, ?)";
		String setWS = "UPDATE myboxdb.user SET workspaceID = ? WHERE userName = ?";
		
		Statement stmt;
		
		try {
			// set folder name for this user
			ps1 = conn.prepareStatement(setFolder);
			ps1.setString(1, "WS" + req.getUserID());
			ps1.setInt(2, -1);
			ps1.executeUpdate();
			ps1.close();

			// pull folder id from folder table for insert wsID to users table
			stmt = conn.createStatement();
			res_getFolderID = stmt.executeQuery("SELECT folderID FROM myboxdb.folder WHERE folderName='WS" + req.getUserID() +" '");
			if (res_getFolderID.next())
			{
				folID = res_getFolderID.getInt(1);

				res_getFolderID.close();


				// insert to user table the wsID
				ps2 = conn.prepareStatement(setWS);
				ps2.setInt(1, folID);
				ps2.setString(2, req.getUserID());
				ps2.executeUpdate();
				return Result.WSHASBEENCREATED;
			}
			return Result.WSCREATIONERROR;


		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
}