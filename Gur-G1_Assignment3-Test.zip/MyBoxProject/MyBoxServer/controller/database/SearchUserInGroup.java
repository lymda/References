package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entity.Request;
import enums.Result;

/**
 * The Class SearchUserInGroup run a query to search if a given user is in a given group.
 */
public class SearchUserInGroup {
	
	/**
	 * Exe. - The method seacrh in usergroup table for a record with the given user name and group name.
	 *
	 * @param req the Request Object with the user name and group name.
	 * @param con the current user connection to server
	 * @return the Result Object (OK, ERROR).
	 */
	public static Result exe(Request req, Connection con){
		try {
			PreparedStatement searchUserInGroup;
			String searchString ="SELECT * FROM myboxdb.usergroup WHERE userName=? AND groupName=?";
			searchUserInGroup=con.prepareStatement(searchString);
			searchUserInGroup.setString(1, (String)req.getEntity());
			searchUserInGroup.setString(2, (String)req.getEntity2());
			ResultSet rs=searchUserInGroup.executeQuery();
			if(rs.next())
			{
				rs.close();
				return Result.OK;
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Result.ERROR;
	}
}
