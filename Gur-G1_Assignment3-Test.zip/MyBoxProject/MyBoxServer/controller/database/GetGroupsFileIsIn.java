package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.FileGroup;
import entity.Request;

/**
 * The Class GetGroupsFileIsIn runs a query to resolve all groups authorized for a specified file.
 */
public class GetGroupsFileIsIn {
	
	/**
	 * Exe.
	 *
	 * @param req the Request Object with an entity of file name
	 * @param con the current user connection to server
	 * @return the FileGroup ArrayList of all groups file is in and their permission.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<FileGroup> groups=new ArrayList<FileGroup>();
		try {
			PreparedStatement searchGroups;
			String searchString ="SELECT * FROM myboxdb.filegroup WHERE fileName=?";
			searchGroups=con.prepareStatement(searchString);
			searchGroups.setString(1, (String)req.getEntity());
			ResultSet rs=searchGroups.executeQuery();
			while(rs.next())
			{
				FileGroup temp=new FileGroup(rs.getString(2),rs.getString(1),rs.getString(3));
				groups.add(temp);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return groups;
	}
}
