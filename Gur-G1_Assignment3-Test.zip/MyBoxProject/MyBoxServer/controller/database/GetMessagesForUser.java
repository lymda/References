package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Message;
import entity.Request;

/**
 * The Class GetMessagesForUser runs a query to resolve all messages for a specified user.
 */
public class GetMessagesForUser {
	
	/**
	 * Exe. - The method search in message table for all messages for the specified user.
	 *
	 * @param req the Request Object with the user name
	 * @param con the current user connection to server
	 * @return the Message ArrayList with all the specified user's messages
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<Message> messages=new ArrayList<Message>();
		try {
			PreparedStatement searchMessages;
			String searchString ="SELECT messageID,message FROM myboxdb.message WHERE toUserID=?";
			searchMessages=con.prepareStatement(searchString);
			searchMessages.setString(1, req.getUserID());
			ResultSet rs=searchMessages.executeQuery();
			while(rs.next())
				messages.add(new Message(rs.getInt(1),req.getUserID(),rs.getString(2)));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return messages;
	}
}
