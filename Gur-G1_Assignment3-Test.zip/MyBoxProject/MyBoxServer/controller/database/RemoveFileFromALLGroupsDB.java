package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Request;
import enums.Result;

/**
 * The Class RemoveFileFromALLGroupsDB runs a query to remove file authorization from all groups.
 */
public class RemoveFileFromALLGroupsDB {
	
	/**
	 * Exe. - The method delete all records in filegroup table where file name is the specified file.
	 *
	 * @param req the Request Object with file name.
	 * @param con the current user connection to server
	 * @return the Result Object (ERROR, FILE_REMOVED_FROM_ALL_GROUPS).
	 */
	public static Result exe(Request req, Connection con)
	{
		try 
		{
			String file = req.getUserID();
			PreparedStatement deletefile;
			
			String deleteString = "DELETE FROM myboxdb.filegroup WHERE fileName = ?";
			deletefile = con.prepareStatement(deleteString);
			deletefile.setString(1, file);
			deletefile.execute();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			return Result.ERROR;
		}
		
		return Result.FILE_REMOVED_FROM_ALL_GROUPS;
	}
}
