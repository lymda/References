package controller.database;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;

import server.ServerSession;
import client.MyBoxMain;
import entity.Request;
import enums.Result;

/**
 * The Class RecieveFileFromClientDB runs operation to receive a file from a client..
 */
public class RecieveFileFromClientDB {

    /**
     * Exe. - The method gets a file and send it to the server files root.
     *
     * @param msg the Request Object with a File Entity
     * @param conn the current user connection to server
     * @return the Result Object (OK).
     */
    public static Result exe(Request msg, Connection conn) {

	FileOutputStream fos = null;
	final entity.File file = (entity.File) msg.getEntity();
	
	try {

	    String serverRootPath = ServerSession.getFilesRoot()+"\\"+file.getFileName();
	    synchronized (file) {
		
		fos = new FileOutputStream(serverRootPath);
		fos.write(file.getMyByteArray());
		fos.close();
	    }

	} catch (IOException ex) {
	    ex.printStackTrace();
	    System.err.println("Client error. Connection closed.");
	}
	
	System.out.println("Message of file update received: " + msg + " from "+ MyBoxMain.client);
	System.out.println(file.getFileName() + " in lentgh of" + file.getSize());
	
	return Result.OK;
    }
}
