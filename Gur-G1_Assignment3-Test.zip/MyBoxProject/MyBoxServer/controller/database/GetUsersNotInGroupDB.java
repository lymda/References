package controller.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Request;

/**
 * The Class GetUsersNotInGroupDB runs a query to resolve all users that are not in a specified group.
 */
public class GetUsersNotInGroupDB {
	
	/**
	 * Exe. - The method search for all non admin users that doesn't has a record for the specified group in usergroup table.
	 *
	 * @param req the Request Object with the group name.
	 * @param con the current user connection to server
	 * @return the String ArrayList of all users not in the specified group.
	 */
	public static Object exe(Request req, Connection con){
		ArrayList<String> users=new ArrayList<String>();
		try {
			PreparedStatement searchUsers;
			String searchString ="SELECT userName FROM myboxdb.user WHERE isAdmin=0 AND userName NOT IN (SELECT userName from myboxdb.usergroup WHERE groupName=?)";
			searchUsers=con.prepareStatement(searchString);
			searchUsers.setString(1, req.getUserID());
			ResultSet rs=searchUsers.executeQuery();
			while(rs.next())
				users.add(rs.getString(1));
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

}
