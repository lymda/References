package common;

/**
 * Generic UI for output.
 * 
 * 
 *
 */
public interface UI {

    /**
     * Abstract function for info message. Can be shown by a boundary, in a
     * different way (console, swing etc.).
     * 
     * @param message
     *            - output message
     */
    public abstract void display(String message);

    /**
     * Abstract function for error message. Can be shown by a boundary, in a
     * different way (console, swing etc.).
     * 
     * @param message
     *            - output message
     */
    public abstract void displayError(String message);
}
