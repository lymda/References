package entity;

import java.io.Serializable;

import enums.Command;

/**
 * The Class Reply is responsible for the reply of the server to the client. 
 */
public class Reply implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The result the server is returning to the server */
    private Object result;

    /** The command the server was asked to do by the client. */
    private Command command;

    /**
     * Instantiates a new reply.
     *
     * @param result the result object of the server.
     * @param command the server was asked to do.
     */
    public Reply(Object result, Command command) {
	this.result = result;
	this.command = command;
    }

    /**
     * Gets the result.
     *
     * @return the result returned by the server.
     */
    public Object getResult() {
	return this.result;
    }

    /**
     * Gets the command.
     *
     * @return the command the server was asked to do.
     */
    public Command getCommand() {
	return this.command;
    }
}
