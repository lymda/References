package entity;

import java.io.Serializable;

import enums.*;

/**
 * The Class Request is responsible for the request of the client from the server. 
 */
public class Request implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The command the client asked the server to do. */
    private final Command command; 

    /** The user id of the requesting client */
    private  String userID; 

    /** The entitys the client is sending to the server. */
    private Object entity = null, entity2 = null; 


    /**
     * Instantiates a new request.
     *
     * @param command the client asked the server to do.
     * @param userID of the client.
     */
    public Request(Command command, String userID) {
	this.command = command;
	this.userID = userID;
    }

    /**
     * Instantiates a new request.
     *
     * @param command the client asked the server to do.
     * @param userID of the client.
     * @param entity the client send to the server.
     */
    public Request(Command command, String userID, Object entity) {
	this.command = command;
	this.userID = userID;
	this.entity = entity;
    }

    /**
     * Instantiates a new request.
     *
     * @param command the client asked the server to do.
     * @param entity the client send to the server.
     */
    public Request(Command command, Object entity) {
	this.command = command;
	this.entity = entity;
    }

    /**
     * Instantiates a new request.
     *
     * @param command the client asked the server to do.
     * @param userID of the client.
     * @param entity the client send to the server.
     * @param entity2 the client send to the server.
     */
    public Request(Command command, String userID, Object entity, Object entity2) {
	this.command = command;
	this.userID = userID;
	this.entity = entity;
	this.entity2 = entity2;

    }

    /**
     * Gets the entity.
     *
     * @return entity the client send to the server.
     */
    public Object getEntity() {
	return entity;
    }

    /**
     * Sets the entity.
     *
     * @param entity the client send to the server.
     */
    public void setEntity(Object entity) {
	this.entity = entity;
    }

    /**
     * Gets the entity2.
     *
     * @return the second entity the client send to the server.
     */
    public Object getEntity2() {
	return entity2;
    }

    /**
     * Sets the entity2.
     *
     * @param entity2 the new entity2
     */
    public void setEntity2(Object entity2) {
	this.entity2 = entity2;
    }

    /**
     * Gets the command.
     *
     * @return the command the client asked the server to do.
     */
    public Command getCommand() {
	return command;
    }

    /**
     * Gets the user id.
     *
     * @return the userID of the client.
     */
    public String getUserID() {
	return userID;
    }

}
