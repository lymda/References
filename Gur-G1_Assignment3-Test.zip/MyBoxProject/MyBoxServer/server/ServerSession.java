package server;


/**
 * The Class ServerSession is saving the server details.
 */
public class ServerSession {

    /** The IP of the server computer.*/
    private static String ip = "localhost";

    /** The port of the server computer. */
    private static int port = -1;

    /** The DB name. */
    private static String DBName = null;

    /** The DB username. */
    private static String DBUsername = null;

    /** The DB password. */
    private static String DBPassword = null;

    /** The files root folder. */
    private static String filesRoot;

    /**
     * Gets the ip.
     *
     * @return the ip
     */
    synchronized public static String getIp() {
	return ip;
    }

    /**
     * Sets the ip.
     *
     * @param ip the new ip
     */
    synchronized public static void setIp(String ip) {
	ServerSession.ip = ip;
    }

    /**
     * Gets the port.
     *
     * @return the port
     */
    synchronized public static int getPort() {
	return port;
    }

    /**
     * Sets the port.
     *
     * @param port the new port
     */
    synchronized public static void setPort(int port) {
	ServerSession.port = port;
    }

    /**
     * Gets the DB password.
     *
     * @return the DB password
     */
    synchronized public static String getDBPassword() {
	return DBPassword;
    }

    /**
     * Sets the DB password.
     *
     * @param DBPassword the new DB password
     */
    synchronized public static void setDBPassword(String DBPassword) {
	ServerSession.DBPassword = DBPassword;
    }

    /**
     * Gets the DB username.
     *
     * @return the DB username
     */
    synchronized public static String getDBUsername() {
	return DBUsername;
    }

    /**
     * Sets the DB username.
     *
     * @param DBUsername the new DB username
     */
    synchronized public static void setDBUsername(String DBUsername) {
	ServerSession.DBUsername = DBUsername;
    }


    /**
     * Gets the files root.
     *
     * @return the files root folder.
     */
    public static String getFilesRoot() {
	return filesRoot;
    }

    /**
     * Sets the files root.
     *
     * @param filesRoot the new files root
     */
    public static void setFilesRoot(String filesRoot) {
	ServerSession.filesRoot = filesRoot;
    }

    /**
     * Gets the DB name.
     *
     * @return the DB name
     */
    public static String getDBName() {
	return DBName;
    }

    /**
     * Sets the DB name.
     *
     * @param dBName the new DB name
     */
    public static void setDBName(String dBName) {
	DBName = dBName;
    }


}
