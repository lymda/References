package server;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;
import controller.database.DBController;
import entity.Reply;
import entity.Request;

/**
 * The Class ServerController is the server controller of MyBox System.
 */
public class ServerController extends AbstractServer {

    /**
     * Instantiates a new server controller.
     *
     * @param port the port number the server is listening on.
     */
    public ServerController(int port) {
	super(port);
    }

    /* (non-Javadoc)
     * @see ocsf.server.AbstractServer#handleMessageFromClient(java.lang.Object, ocsf.server.ConnectionToClient)
     */
    @Override
    protected void handleMessageFromClient(Object msg, ConnectionToClient client) {

	Request requset = (Request) msg;
	Reply reply = null;

	/* DB connection */
	try {
	    Class.forName("com.mysql.jdbc.Driver").newInstance();
	} catch (Exception ex) {
	    System.out.println("Failed to connect DB.");
	}/* handle the error */

	try {
	    Connection conn = DriverManager.getConnection(
		    "jdbc:mysql://localhost:3306/myboxdb",
		    ServerSession.getDBUsername(),
		    ServerSession.getDBPassword());
	    System.out.println("SQL connection succeed");

	    reply = new Reply(DBController.handleRequest(requset, conn), requset.getCommand());

	    conn.close();

	} catch (SQLException ex) {/* handle any errors */
	    System.out.println("SQLException: " + ex.getMessage());
	    System.out.println("SQLState: " + ex.getSQLState());
	    System.out.println("VendorError: " + ex.getErrorCode());
	}

	try {
	    client.sendToClient(reply);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

    /* (non-Javadoc)
     * @see ocsf.server.AbstractServer#serverStarted()
     */
    @Override
    protected void serverStarted() {
	System.out.println("Server listening for connections on port "
		+ getPort());
    }

    /* (non-Javadoc)
     * @see ocsf.server.AbstractServer#serverStopped()
     */
    @Override
    protected void serverStopped() {
	System.out.println("Server has stopped listening for connections.");
    }

    /**
     * Connect to the server by listen().
     *
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void connect() throws IOException {
	this.listen(); // Start listening for connections
    }

}