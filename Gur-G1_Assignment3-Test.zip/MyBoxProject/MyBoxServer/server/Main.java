package server;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;

/**
 * The Class Main is the entry point to the server application.
 */
public class Main {

    /** The Server frame. */
    private JFrame ServerFrame;

    /** The port text field. */
    private JTextField portTextField;

    /** The password field. */
    private JPasswordField passwordField;

    /** The username text field. */
    private JTextField usernameTextField;

    /** The lbl online if the server is online. */
    private JLabel lblOnline;

    /** The label. */
    private JLabel DBPasswardLabel;

    /** The files root text field. */
    private JTextField filesRootTextField;

    /** The background. */
    private JLabel background;

    /**
     * Launch the application.
     *
     * @param args the arguments from the console.
     */
    public static void main(String[] args) {
	EventQueue.invokeLater(new Runnable() {
	    public void run() {
		try {
		    Main window = new Main();
		    window.ServerFrame.setVisible(true);
		} catch (Exception e) {
		    e.printStackTrace();
		}
	    }
	});
    }

    /**
     * Create the application.
     */
    public Main() {
	initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
	ServerFrame = new JFrame();
	ServerFrame.getContentPane().setBackground(new Color(240, 240, 240));
	ServerFrame.setResizable(false);
	ServerFrame.setTitle("MyBoxServer");
	ServerFrame.setBounds(500, 500, 292, 267);
	ServerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	ServerFrame.getContentPane().setLayout(null);
	portTextField = new JTextField();
	portTextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
	portTextField.setBounds(140, 20, 139, 20);
	portTextField.setText("5551");
	ServerFrame.getContentPane().add(portTextField);
	portTextField.setColumns(10);

	JLabel lblPort = new JLabel("Port:");
	lblPort.setFont(new Font("Tahoma", Font.PLAIN, 18));
	lblPort.setBounds(15, 20, 110, 14);
	ServerFrame.getContentPane().add(lblPort);

	final JButton btnStartListening = new JButton("Start Listening");
	btnStartListening.setFont(new Font("Tahoma", Font.PLAIN, 18));
	btnStartListening.setBounds(62, 197, 166, 23);
	ServerFrame.getContentPane().add(btnStartListening);

	JLabel lblDbPassword = new JLabel("Files root:");
	lblDbPassword.setFont(new Font("Tahoma", Font.PLAIN, 18));
	lblDbPassword.setBounds(15, 123, 110, 14);
	ServerFrame.getContentPane().add(lblDbPassword);

	passwordField = new JPasswordField();
	passwordField.setFont(new Font("Tahoma", Font.PLAIN, 18));
	passwordField.setBounds(140, 90, 139, 20);
	passwordField.setText("root");
	ServerFrame.getContentPane().add(passwordField);

	JLabel lblDbUsername = new JLabel("DB username:");
	lblDbUsername.setFont(new Font("Tahoma", Font.PLAIN, 18));
	lblDbUsername.setBounds(15, 55, 121, 14);
	ServerFrame.getContentPane().add(lblDbUsername);

	usernameTextField = new JTextField();
	usernameTextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
	usernameTextField.setBounds(140, 55, 139, 20);
	usernameTextField.setText("root");
	ServerFrame.getContentPane().add(usernameTextField);
	usernameTextField.setColumns(10);

	lblOnline = new JLabel("O N L I N E");
	lblOnline.setBounds(107, 169, 79, 14);
	lblOnline.setFont(new Font("Tahoma", Font.BOLD, 13));
	ServerFrame.getContentPane().add(lblOnline);

	DBPasswardLabel = new JLabel("DB password:");
	DBPasswardLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
	DBPasswardLabel.setBounds(15, 90, 110, 14);
	ServerFrame.getContentPane().add(DBPasswardLabel);

	filesRootTextField = new JTextField();
	filesRootTextField.setText("C:\\MyBoxFilesRoot");
	filesRootTextField.setBounds(140, 123, 139, 20);
	filesRootTextField.setColumns(10);
	ServerFrame.getContentPane().add(filesRootTextField);

	background = new JLabel("");
	background.setIcon(new ImageIcon(Main.class.getResource("/boundary/images/server UI.jpg")));
	background.setBounds(0, 0, 286, 262);
	ServerFrame.getContentPane().add(background);
	lblOnline.setVisible(false);

	btnStartListening.addActionListener(new ActionListener() {
	    @SuppressWarnings("deprecation")
	    public void actionPerformed(ActionEvent arg0) {

		ServerSession.setPort(Integer.parseInt(portTextField.getText()));
		ServerSession.setDBPassword(passwordField.getText());
		ServerSession.setDBUsername(usernameTextField.getText());
		ServerSession.setFilesRoot(filesRootTextField.getText());
		while (ServerSession.getDBPassword() == null
			|| ServerSession.getDBUsername() == null
			|| ServerSession.getPort() == -1
			|| ServerSession.getFilesRoot() == null);

		ServerController server = new ServerController(Integer.parseInt(portTextField.getText()));
		try {
		    server.connect();
		    lblOnline.setVisible(true);
		    lblOnline.setForeground(Color.BLUE);
		    btnStartListening.setEnabled(false);
		    portTextField.setEditable(false);
		    usernameTextField.setEditable(false);
		    passwordField.setEditable(false);
		} catch (Exception ex) {
		    System.out.println("ERROR - Could not listen for clients!");
		}

	    }
	    /* listener */
	});

	/* initialize */
    }
}
